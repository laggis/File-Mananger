Config = {}

Config.TimeBetweenPress = 20 -- Sekunder

Config.JobList = {

    {
        label = "polisen",
        job = "police",
        pos = {
            vector3(442.46496582031, -984.52258300781, 30.724321365356),
        }
    },
    
    {
        label = "sjukvården",
        job = "ambulance",
        pos = {
            vector3(306.78530883789, -595.04833984375, 43.283977508545),
        }
    },

}