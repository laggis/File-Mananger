/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `penguin` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `penguin`;

CREATE TABLE IF NOT EXISTS `addon_account` (
  `name` varchar(60) NOT NULL,
  `label` varchar(255) NOT NULL,
  `shared` int NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `addon_account` (`name`, `label`, `shared`) VALUES
	('bank_savings', 'Bank Savings', 0),
	('caution', 'caution', 0),
	('motell_black_money', 'Svarta pengar Motell', 0),
	('property_black_money', 'Pengar smutsig egendom', 0),
	('society_ambulance', 'Ambulance', 1),
	('society_autoexperten', 'Autoexperten', 1),
	('society_ballas', 'ballas', 1),
	('society_banker', 'Banker', 1),
	('society_bennys', 'Bennys', 1),
	('society_biker', 'Biker', 1),
	('society_cardealer', 'Cardealer', 1),
	('society_cartel', 'cartel', 1),
	('society_farmen', 'Farmen', 1),
	('society_gang', 'gang', 1),
	('society_kronofogden', 'kronofogden', 1),
	('society_mafia', 'Mafia', 1),
	('society_mecano', 'Mekaniker', 1),
	('society_mekonomen', 'Mekonomen', 1),
	('society_police', 'Polisen', 1),
	('society_qpark', 'Qpark', 1),
	('society_realestateagent', 'MÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤klare', 1),
	('society_Securitas', 'Securitas', 1),
	('society_taxi', 'Taxi', 1),
	('society_thelostmc', 'TheLostMC', 1),
	('society_unicorn', 'Unicorn', 1),
	('society_unicorn2', 'unicorn2', 1),
	('society_unicorn3', 'unicorn3', 1),
	('society_vianor', 'Vianor', 1);

CREATE TABLE IF NOT EXISTS `addon_account_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) DEFAULT NULL,
  `money` double NOT NULL,
  `owner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1439 DEFAULT CHARSET=latin1;

REPLACE INTO `addon_account_data` (`id`, `account_name`, `money`, `owner`) VALUES
	(1, 'society_ambulance', 0, NULL),
	(2, 'society_banker', 0, NULL),
	(5, 'society_cardealer', 0, NULL),
	(6, 'society_farmen', 0, NULL),
	(7, 'society_mecano', 0, NULL),
	(9, 'society_taxi', 0, NULL),
	(10, 'society_bennys', 0, NULL),
	(11, 'society_unicorn', 0, NULL),
	(12, 'society_unicorn2', 0, NULL),
	(13, 'society_unicorn3', 0, NULL),
	(14, 'society_police', 0, NULL),
	(1361, 'society_autoexperten', 0, NULL),
	(1366, 'society_mekonomen', 0, NULL),
	(1367, 'society_realestateagent', 0, NULL),
	(1368, 'society_thelostmc', 0, NULL),
	(1369, 'society_vianor', 0, NULL),
	(1403, 'society_ballas', 0, NULL),
	(1404, 'society_biker', 0, NULL),
	(1405, 'society_cartel', 0, NULL),
	(1406, 'society_gang', 0, NULL),
	(1407, 'society_kronofogden', 0, NULL),
	(1408, 'society_mafia', 0, NULL),
	(1409, 'society_qpark', 0, NULL),
	(1410, 'society_Securitas', 0, NULL);

CREATE TABLE IF NOT EXISTS `addon_inventory` (
  `name` varchar(60) NOT NULL,
  `label` varchar(255) NOT NULL,
  `shared` int NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `addon_inventory` (`name`, `label`, `shared`) VALUES
	('housing', 'Housing', 0),
	('motell', 'Motell', 0),
	('property', 'Fast egendom', 0),
	('society_ambulance', 'Ambulance', 1),
	('society_autoexperten', 'Autoexperten', 1),
	('society_ballas', 'ballas', 1),
	('society_bennys', 'Bennys', 1),
	('society_biker', 'Biker', 1),
	('society_cardealer', 'Cardealer', 1),
	('society_cartel', 'Cartel', 1),
	('society_gang', 'Gang', 1),
	('society_kronofogden', 'kronofogden', 1),
	('society_mafia', 'Mafia', 1),
	('society_mecano', 'Mekaniker', 1),
	('society_mechanic', 'Mechanic', 1),
	('society_pilot', 'Pilot', 1),
	('society_police', 'Polisen', 1),
	('society_qpark', 'Qpark', 1),
	('society_realestateagent', 'Realestateagent', 1),
	('society_Securitas', 'Securitas', 1),
	('society_taxi', 'Taxi', 1),
	('society_thelostmc', 'TheLostMC', 1),
	('society_unicorn', 'Unicorn', 1),
	('society_unicorn2', 'unicorn2', 1),
	('society_unicorn2_fridge', 'unicorn2 (frigo)', 1),
	('society_unicorn3', 'unicorn3', 1),
	('society_unicorn3_fridge', 'unicorn3 (frigo)', 1),
	('society_unicorn_fridge', 'Unicorn (fridge)', 1);

CREATE TABLE IF NOT EXISTS `addon_inventory_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inventory_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `count` int NOT NULL,
  `owner` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

REPLACE INTO `addon_inventory_items` (`id`, `inventory_name`, `name`, `count`, `owner`) VALUES
	(25, 'society_police', 'phone', 0, NULL),
	(32, 'society_bennys', 'turbo', 4, NULL),
	(33, 'society_bennys', 'fargpatron', 6, NULL),
	(34, 'society_bennys', 'metalldel', 14, NULL),
	(36, 'society_bennys', 'mic', 0, NULL),
	(37, 'society_bennys', 'sonyalpha', 0, NULL),
	(43, 'society_police', 'handcuffs', 4, NULL),
	(44, 'society_police', 'dyrkset', 3, NULL),
	(61, 'society_police', 'policecard', 0, NULL);

CREATE TABLE IF NOT EXISTS `adminmode_bans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receiver` text NOT NULL,
  `sender` varchar(60) NOT NULL,
  `length` datetime DEFAULT NULL,
  `reason` text NOT NULL,
  `unbanned` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `adminmode_identifiers` (
  `steam` varchar(60) NOT NULL,
  `license` varchar(60) NOT NULL,
  `ip` varchar(60) NOT NULL,
  `name` varchar(128) NOT NULL,
  `xbl` varchar(60) DEFAULT NULL,
  `live` varchar(60) DEFAULT NULL,
  `discord` varchar(60) DEFAULT NULL,
  `fivem` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`steam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `adminmode_warnings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receiver` text NOT NULL,
  `sender` varchar(60) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `baninfo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `license` varchar(50) DEFAULT NULL,
  `identifier` varchar(25) DEFAULT NULL,
  `liveid` varchar(21) DEFAULT NULL,
  `xblid` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `playerip` varchar(25) DEFAULT NULL,
  `playername` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `banlist` (
  `license` varchar(50) NOT NULL,
  `identifier` varchar(25) DEFAULT NULL,
  `liveid` varchar(21) DEFAULT NULL,
  `xblid` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `playerip` varchar(25) DEFAULT NULL,
  `targetplayername` varchar(32) DEFAULT NULL,
  `sourceplayername` varchar(32) DEFAULT NULL,
  `reason` varchar(255) NOT NULL,
  `timeat` varchar(50) NOT NULL,
  `expiration` varchar(50) NOT NULL,
  `permanent` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`license`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `banlisthistory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `license` varchar(50) DEFAULT NULL,
  `identifier` varchar(25) DEFAULT NULL,
  `liveid` varchar(21) DEFAULT NULL,
  `xblid` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `playerip` varchar(25) DEFAULT NULL,
  `targetplayername` varchar(32) DEFAULT NULL,
  `sourceplayername` varchar(32) DEFAULT NULL,
  `reason` varchar(255) NOT NULL,
  `timeat` int NOT NULL,
  `added` varchar(40) NOT NULL,
  `expiration` int NOT NULL,
  `permanent` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `beroenden` (
  `drog` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `beroende` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `billing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `target_type` varchar(50) NOT NULL,
  `target` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `amount` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `bought_houses` (
  `houseid` int NOT NULL,
  PRIMARY KEY (`houseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `bought_houses` (`houseid`) VALUES
	(5);

CREATE TABLE IF NOT EXISTS `bought_vehicles` (
  `data` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `cardealer_vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vehicle` varchar(255) NOT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `dateofbirth` varchar(255) NOT NULL,
  `sex` varchar(1) NOT NULL DEFAULT 'M',
  `height` varchar(128) NOT NULL,
  `lastdigits` varchar(255) DEFAULT NULL,
  `jail` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=678 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_accessories` (
  `identifier` varchar(22) NOT NULL,
  `data` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_animations` (
  `identifier` varchar(22) NOT NULL,
  `data` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_invoices` (
  `invoiceId` int NOT NULL AUTO_INCREMENT,
  `cid` varchar(50) NOT NULL,
  `invoiceSender` varchar(50) NOT NULL,
  `invoiceAmount` int NOT NULL DEFAULT '0',
  `invoiceText` varchar(500) NOT NULL,
  PRIMARY KEY (`invoiceId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_skills` (
  `cid` varchar(50) NOT NULL,
  `skills` longtext NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_stress` (
  `characterId` varchar(50) NOT NULL,
  `stressPercent` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`characterId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `communityservice` (
  `identifier` varchar(100) NOT NULL,
  `actions_remaining` int NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `datastore` (
  `name` varchar(60) NOT NULL,
  `label` varchar(100) NOT NULL,
  `shared` int NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `datastore` (`name`, `label`, `shared`) VALUES
	('housing', 'Housing', 0),
	('property', 'property', 0),
	('society_ambulance', 'Ambulance', 1),
	('society_ballas', 'ballas', 1),
	('society_bennys', 'Bennys', 1),
	('society_biker', 'Biker', 1),
	('society_cartel', 'Cartel', 1),
	('society_gang', 'Gang', 1),
	('society_kronofogden', 'kronofogden', 1),
	('society_mafia', 'Mafia', 1),
	('society_police', 'Polisen', 1),
	('society_qpark', 'Qpark', 1),
	('society_Securitas', 'Securitas', 1),
	('society_unicorn', 'Unicorn', 1);

CREATE TABLE IF NOT EXISTS `datastore_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `owner` varchar(60) DEFAULT NULL,
  `data` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_datastore_data_name_owner` (`name`,`owner`),
  KEY `index_datastore_data_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=384 DEFAULT CHARSET=latin1;

REPLACE INTO `datastore_data` (`id`, `name`, `owner`, `data`) VALUES
	(358, 'society_ambulance', NULL, '{}'),
	(359, 'society_ballas', NULL, '{}'),
	(360, 'society_bennys', NULL, '{}'),
	(361, 'society_biker', NULL, '{}'),
	(362, 'society_cartel', NULL, '{}'),
	(363, 'society_gang', NULL, '{}'),
	(364, 'society_kronofogden', NULL, '{}'),
	(365, 'society_mafia', NULL, '{}'),
	(366, 'society_police', NULL, '{}'),
	(367, 'society_qpark', NULL, '{}'),
	(368, 'society_Securitas', NULL, '{}'),
	(369, 'society_unicorn', NULL, '{}');

CREATE TABLE IF NOT EXISTS `fine_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Missbruk av tutan', 1250, 0),
	(2, 'Korsa en kontinuerlig linje', 1750, 0),
	(3, 'Cirkulationen strider mot', 1250, 0),
	(4, 'OtillÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥tet U-svÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ng', 2350, 0),
	(5, 'Offroadtrafik', 1750, 0),
	(7, 'Farligt / FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rbjudet Stopp', 1750, 0),
	(8, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rbjuden Parkering', 1500, 0),
	(9, 'Respekterar inte lagen om hÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ger kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsida', 3500, 0),
	(11, 'Smitning', 2850, 0),
	(12, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r mot RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶dljus', 1500, 0),
	(13, 'Farlig KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rning', 3650, 0),
	(14, 'Ej registrerat Fordon', 3500, 0),
	(15, 'Olovlig kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rning', 2500, 0),
	(16, 'Hit and Run', 3500, 0),
	(17, 'Hastighet <5 km / h', 1000, 0),
	(18, 'Hastighet 5-15 kmh', 2000, 0),
	(19, 'Hastighet 15-30 km / h', 3000, 0),
	(20, 'Hastighet> 30 km / h', 4000, 0),
	(21, 'SkadegÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶relse', 3500, 0),
	(22, 'Grov skadegÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶relse', 5500, 0),
	(23, 'Misslyckad kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rriktningsvisning', 2500, 0),
	(70, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rhindrande av trafik', 2500, 1),
	(71, 'Nedbrytning av den allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nna vÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤gen', 1250, 1),
	(72, 'Problem med allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n ordning', 2500, 1),
	(73, 'Hindrar polisens verksamhet', 1500, 1),
	(74, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rolÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤mpning mot / mellan civila', 1250, 1),
	(75, 'Hot mot polis', 3500, 1),
	(76, 'Verbalt hot eller hot mot civila', 3000, 1),
	(77, 'Verbalt hot eller hot mot en polis', 3000, 1),
	(78, 'Olagligt protest', 2500, 1),
	(79, 'DÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶dligt vapen utanfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r i stan', 3500, 2),
	(80, 'DÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶dlig vapen ute i stan', 4500, 2),
	(81, 'Vapeninnehav (Klass 1)', 8500, 2),
	(82, 'Grovt vapeninnehav (Klass 1)', 11500, 2),
	(83, 'Vapeninnehav (Klass 2)', 11500, 2),
	(84, 'Grovt vapeninnehav (Klass 2)', 13500, 2),
	(85, 'BilstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ld', 7500, 2),
	(86, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ljning av droger', 3500, 2),
	(87, 'Drogtillverkning', 7500, 2),
	(88, 'Narkotikainnehav', 4500, 2),
	(89, 'Misshandel pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ civil', 5000, 2),
	(90, 'Grov misshandel pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ civil', 7500, 2),
	(91, 'Misshandel pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 8000, 2),
	(92, 'Grov misshandel pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 9500, 2),
	(95, 'ButiksrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n', 30000, 3),
	(96, 'BankrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n', 100000, 3),
	(97, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶k pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ mord pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ Civil', 12500, 3),
	(98, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶k pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ mord pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ TjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 27500, 3),
	(99, 'Mord pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ Civil', 25000, 3),
	(100, 'Mord pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ TjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 35000, 3);

CREATE TABLE IF NOT EXISTS `fine_types_ballas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types_ballas` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Raket', 3000, 0),
	(2, 'Raket', 5000, 0),
	(3, 'Raket', 10000, 1),
	(4, 'Raket', 20000, 1),
	(5, 'Raket', 50000, 2),
	(6, 'Raket', 150000, 3),
	(7, 'Raket', 350000, 3);

CREATE TABLE IF NOT EXISTS `fine_types_biker` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types_biker` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Raket', 3000, 0),
	(2, 'Raket', 5000, 0),
	(3, 'Raket', 10000, 1),
	(4, 'Raket', 20000, 1),
	(5, 'Raket', 50000, 2),
	(6, 'Raket', 150000, 3),
	(7, 'Raket', 350000, 3);

CREATE TABLE IF NOT EXISTS `fine_types_cartel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types_cartel` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Raket', 3000, 0),
	(2, 'Raket', 5000, 0),
	(3, 'Raket', 10000, 1),
	(4, 'Raket', 20000, 1),
	(5, 'Raket', 50000, 2),
	(6, 'Raket', 150000, 3),
	(7, 'Raket', 350000, 3);

CREATE TABLE IF NOT EXISTS `fine_types_gang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types_gang` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Raket', 3000, 0),
	(2, 'Raket', 5000, 0),
	(3, 'Raket', 10000, 1),
	(4, 'Raket', 20000, 1),
	(5, 'Raket', 50000, 2),
	(6, 'Raket', 150000, 3),
	(7, 'Raket', 350000, 3);

CREATE TABLE IF NOT EXISTS `fine_types_kronofogden` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types_kronofogden` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Missbruk av tuta', 30, 0),
	(2, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ra ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ver heldragen linje', 40, 0),
	(3, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt i motsatt riktning i rondell', 250, 0),
	(4, 'Olaglig u-svÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ng', 250, 0),
	(5, 'Olovlig kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rning i terrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ng', 170, 0),
	(6, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r nÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ra bil framfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r', 30, 0),
	(7, 'Trafikfarlig stopp', 150, 0),
	(8, 'Olaglig parkering', 70, 0),
	(9, 'AnvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nder inte hÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶gerregeln', 70, 0),
	(10, 'Aktar sig inte fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nstefordon i utryckning', 90, 0),
	(11, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rbi stoppskylt', 105, 0),
	(12, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt mot rÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶tt', 130, 0),
	(13, 'Farlig omkÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rning', 100, 0),
	(14, 'Fordon i dÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ligt skick', 100, 0),
	(15, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt utan kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rkort', 1500, 0),
	(16, 'Smitning frÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n olycka', 800, 0),
	(17, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r fort < 5 kmh', 90, 0),
	(18, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r fort 5-15 kmh', 120, 0),
	(19, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r fort 15-30 kmh', 180, 0),
	(20, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r fort > 30 kmh', 300, 0),
	(21, 'Blockerar trafiken', 110, 1),
	(22, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n egendom', 90, 1),
	(23, 'Olaga diskriminering', 90, 1),
	(24, 'fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rhindrar polisens verksamhet', 130, 1),
	(25, 'Hets mot folkgrupp', 75, 1),
	(26, 'DÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ligt beteende mot tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 110, 1),
	(27, 'Verbalt hot mot annan person', 90, 1),
	(28, 'Verbalt hot mot en tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 150, 1),
	(29, 'Olaglig protest', 250, 1),
	(30, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶k till mutning', 1500, 1),
	(31, 'Icke livshotande vapen pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n plats ex. Hammare', 120, 2),
	(32, 'DÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶dligt vapen pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n plats', 300, 2),
	(33, 'Vapen pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n plats med licens (Licens Fel)', 600, 2),
	(34, 'Innehaft olaga vapen', 700, 2),
	(35, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶kt bryta sig in', 300, 2),
	(36, 'BilstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ld', 1800, 2),
	(37, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ljning av droger', 1500, 2),
	(38, 'Tillverkning av droger', 1500, 2),
	(39, 'Innehav av droger', 650, 2),
	(40, 'HÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥lla gisslan/HÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥lla person mot dess vilja', 1500, 2),
	(41, 'Kidnappa en tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 2000, 2),
	(42, 'RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n', 650, 2),
	(43, 'ButiksrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n', 650, 2),
	(44, 'BankrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n', 1500, 2),
	(45, 'Skjutit en person', 2000, 3),
	(46, 'Skjutit en tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 2500, 3),
	(47, 'MordfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶k', 3000, 3),
	(48, 'MordfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶k pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 6000, 3),
	(49, 'Mord', 10000, 3),
	(50, 'Mord pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 30000, 3),
	(51, 'DrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥p', 1800, 3),
	(52, 'Olagliga aktiviteter inom ett fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶retag', 2000, 2);

CREATE TABLE IF NOT EXISTS `fine_types_mafia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types_mafia` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Raket', 3000, 0),
	(2, 'Raket', 5000, 0),
	(3, 'Raket', 10000, 1),
	(4, 'Raket', 20000, 1),
	(5, 'Raket', 50000, 2),
	(6, 'Raket', 150000, 3),
	(7, 'Raket', 350000, 3);

CREATE TABLE IF NOT EXISTS `fine_types_securitas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types_securitas` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Missbruk av tuta', 30, 0),
	(2, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ra ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ver heldragen linje', 40, 0),
	(3, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt i motsatt riktning i rondell', 250, 0),
	(4, 'Olaglig u-svÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ng', 250, 0),
	(5, 'Olovlig kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rning i terrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ng', 170, 0),
	(6, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r nÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ra bil framfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r', 30, 0),
	(7, 'Trafikfarlig stopp', 150, 0),
	(8, 'Olaglig parkering', 70, 0),
	(9, 'AnvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nder inte hÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶gerregeln', 70, 0),
	(10, 'Aktar sig inte fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nstefordon i utryckning', 90, 0),
	(11, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rbi stoppskylt', 105, 0),
	(12, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt mot rÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶tt', 130, 0),
	(13, 'Farlig omkÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rning', 100, 0),
	(14, 'Fordon i dÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ligt skick', 100, 0),
	(15, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt utan kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rkort', 1500, 0),
	(16, 'Smitning frÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n olycka', 800, 0),
	(17, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r fort < 5 kmh', 90, 0),
	(18, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r fort 5-15 kmh', 120, 0),
	(19, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r fort 15-30 kmh', 180, 0),
	(20, 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r fort > 30 kmh', 300, 0),
	(21, 'Blockerar trafiken', 110, 1),
	(22, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rt allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n egendom', 90, 1),
	(23, 'Olaga diskriminering', 90, 1),
	(24, 'fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rhindrar polisens verksamhet', 130, 1),
	(25, 'Hets mot folkgrupp', 75, 1),
	(26, 'DÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ligt beteende mot tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 110, 1),
	(27, 'Verbalt hot mot annan person', 90, 1),
	(28, 'Verbalt hot mot en tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 150, 1),
	(29, 'Olaglig protest', 250, 1),
	(30, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶k till mutning', 1500, 1),
	(31, 'Icke livshotande vapen pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n plats ex. Hammare', 120, 2),
	(32, 'DÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶dligt vapen pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n plats', 300, 2),
	(33, 'Vapen pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ allmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤n plats med licens (Licens Fel)', 600, 2),
	(34, 'Innehaft olaga vapen', 700, 2),
	(35, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶kt bryta sig in', 300, 2),
	(36, 'BilstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ld', 1800, 2),
	(37, 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ljning av droger', 1500, 2),
	(38, 'Tillverkning av droger', 1500, 2),
	(39, 'Innehav av droger', 650, 2),
	(40, 'HÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥lla gisslan/HÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥lla person mot dess vilja', 1500, 2),
	(41, 'Kidnappa en tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 2000, 2),
	(42, 'RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n', 650, 2),
	(43, 'ButiksrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n', 650, 2),
	(44, 'BankrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥n', 1500, 2),
	(45, 'Skjutit en person', 2000, 3),
	(46, 'Skjutit en tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 2500, 3),
	(47, 'MordfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶k', 3000, 3),
	(48, 'MordfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶k pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 6000, 3),
	(49, 'Mord', 10000, 3),
	(50, 'Mord pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥ tjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nsteman', 30000, 3),
	(51, 'DrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥p', 1800, 3),
	(52, 'Olagliga aktiviteter inom ett fÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶retag', 2000, 2);

CREATE TABLE IF NOT EXISTS `gangs` (
  `gang` varchar(50) DEFAULT NULL,
  `orders` varchar(555) DEFAULT NULL,
  `sentOrders` varchar(555) DEFAULT NULL,
  `money` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `glovebox_inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plate` varchar(8) NOT NULL,
  `data` text NOT NULL,
  `owned` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plate` (`plate`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `godzilla` (
  `identifier` varchar(50) NOT NULL,
  `license` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `discord` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `liveid` varchar(255) DEFAULT NULL,
  `xbl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `items` (
  `name` varchar(50) NOT NULL,
  `label` varchar(50) NOT NULL,
  `limit` int NOT NULL DEFAULT '-1',
  `rare` int NOT NULL DEFAULT '0',
  `can_remove` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
	('accesscard', 'Access Card', 10, 0, 1),
	('acetone', 'Acetone', 5, 0, 1),
	('acetoningrediens', 'Acetoningredienser', 10, 0, 1),
	('adrenalinpenna', 'Adrenalinpenna', -1, 0, 1),
	('airpods', 'Apple AirPods', -1, 0, 1),
	('alive_chicken', 'Levande Kyckling', 20, 0, 1),
	('aluminium', 'Aluminium', -1, 0, 1),
	('alvedon', 'Alvedon 400mg', -1, 0, 1),
	('ambulanskey', 'Ambulans Nyckel', -1, 0, 1),
	('ammo_lmg', 'LMG Ammunition', -1, 0, 1),
	('ammo_pistol', 'Pistol Ammunition', -1, 0, 1),
	('ammo_rifle', 'Rifle Ammunition', -1, 0, 1),
	('ammo_smg', 'SMG Ammunition', -1, 0, 1),
	('ammo_sniperrifle', 'Sniper Ammunition', -1, 0, 1),
	('anna', 'Annanas', -1, 0, 1),
	('anteckning', 'Antecknings Block', -1, 0, 1),
	('apel', 'Apelsin', -1, 0, 1),
	('apelj', 'Apelsin Juice', -1, 0, 1),
	('apelpaj', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾pp', -1, 0, 1),
	('apple', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾pp', -1, 0, 1),
	('applemos', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾pp', -1, 0, 1),
	('assaultrifle', 'Assault Rifle', -1, 0, 1),
	('assaultsmg', 'Assault SMG', -1, 0, 1),
	('ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤gg', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾gg', -1, 0, 1),
	('ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤pple', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾pp', -1, 0, 1),
	('bahamnycklar', 'Bahama Nycklar', 5, 0, 1),
	('bait', 'Bete', 20, 0, 1),
	('banan', 'Banan', -1, 0, 1),
	('bandage', 'Bandage', -1, 0, 1),
	('bat', 'Baseball bat', -1, 0, 1),
	('batteri', 'Batteri', -1, 0, 1),
	('battleaxe', 'Battle Axe', -1, 0, 1),
	('beer', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ¢Ã¢Â‚Â¬', 5, 0, 1),
	('binoculars', 'Kikare', -1, 0, 1),
	('blackdevilblack', 'Black Devil Black', 5, 0, 1),
	('blackdevilblack2', 'Black Devil Black', 40, 0, 1),
	('blindfold', 'Blindfold', -1, 0, 1),
	('blowpipe', 'BlÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥srÃƒÂƒÃ†Â’Ãƒ', -1, 0, 1),
	('book', 'Bok', -1, 0, 1),
	('borrmaskin', 'Borrmaskin', -1, 0, 1),
	('bottle', '50cl Flaska-Tom', -1, 0, 1),
	('bread', 'BrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶d', -1, 0, 1),
	('bread2', 'Egengjort BrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶d', 10, 0, 1),
	('broken_parts', 'Trasiga saker', -1, 0, 1),
	('bromsdel', 'Bromsdel', -1, 0, 1),
	('bulletproof', 'SkottsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ker VÃƒÂ', 2, 0, 1),
	('bulletproofpolisinsatsf', 'SkottsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ker VÃƒÂ', 2, 0, 1),
	('bulletproofpolisinsatsm', 'SkottsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ker VÃƒÂ', 2, 0, 1),
	('bulletproofpolisskyddf', 'SkottsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ker VÃƒÂ', -1, 0, 1),
	('bulletproofpolisskyddm', 'SkottsÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ker VÃƒÂ', -1, 0, 1),
	('bulletproofpolistrafikbefalf', 'TrafikVÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st (Pol', 5, 0, 1),
	('bulletproofpolistrafikbefalm', 'TrafikVÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st (Pol', 5, 0, 1),
	('bulletproofpolistrafikcheff', 'PolisvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st-Insat', 5, 0, 1),
	('bulletproofpolistrafikchefm', 'PolisvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st-Insat', 5, 0, 1),
	('bulletproofpolistrafikf', 'TrafikVÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st (Pol', 5, 0, 1),
	('bulletproofpolistrafikm', 'TrafikVÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st (Pol', 5, 0, 1),
	('bulletproofpolisutbf', 'PolisvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st-UTB (', 5, 0, 1),
	('bulletproofpolisutbm', 'PolisvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st-UTB (', 5, 0, 1),
	('bullpuprifle', 'Bullpup Rifle', -1, 0, 1),
	('buntband', 'Buntband', -1, 0, 1),
	('burger', 'Billys Hamburgare', 5, 0, 1),
	('bzgas', 'BZ Gas', -1, 0, 1),
	('cannabis', 'Cannabis', -1, 0, 1),
	('carbinerifle', 'Carbine Rifle', -1, 0, 1),
	('caribbean', 'Nocco Caribbean 33cl', -1, 0, 1),
	('carokit', 'Body Kit', -1, 0, 1),
	('carotool', 'Karossverktyg', -1, 0, 1),
	('chemicals', 'Kemikalier', -1, 0, 1),
	('chips', 'Chips', -1, 0, 1),
	('cigg', 'Cigarette', -1, 0, 1),
	('clip', 'AmmunitionslÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥da', 6, 0, 1),
	('coca_leaf', 'Coca LÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶v', -1, 0, 1),
	('coke', 'Kokain', -1, 0, 1),
	('coke_pooch', 'PÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥se med kokain', -1, 0, 1),
	('cola', 'Coca Cola 33cl', -1, 0, 1),
	('combatmg', 'Combat MG', -1, 0, 1),
	('combatpdw', 'Combat PDW', -1, 0, 1),
	('combatpistol', 'Combat Pistol', -1, 0, 1),
	('combatshotgun', 'Combat Shotgun', -1, 0, 1),
	('compactrifle', 'Compact Rifle', -1, 0, 1),
	('copper', 'Koppar', 56, 0, 1),
	('coupon', 'Kupong', -1, 0, 1),
	('creditcard', 'Kredit Kort', -1, 0, 1),
	('cutted_wood', 'SÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥gat TrÃƒÂƒÃ†Â', 20, 0, 1),
	('darknet', 'Dark Net', 1, 0, 1),
	('diamond', 'Diamant', 50, 0, 1),
	('diamond10ct', 'Diamant (10 ct)', 20, 0, 1),
	('drill', 'Borrmaskin', 1, 0, 1),
	('drpepper', 'Dr. Pepper', 5, 0, 1),
	('drumclip', 'AmmunitionslÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥da', 2, 0, 1),
	('drummag', 'Trummagasin (100 skott)', 2, 0, 1),
	('dyrkset', 'Dyrkset', -1, 0, 1),
	('electronickit', 'Electronic Kit', 1, 0, 1),
	('emptybeer', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ¢Ã¢Â‚Â¬', 5, 0, 1),
	('energy', 'Energy Drink', 5, 0, 1),
	('essence', 'Essence', 24, 0, 1),
	('esx_phone3', 'Telefon', 10, 0, 1),
	('extendedclip', 'AmmunitionslÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥da', 4, 0, 1),
	('extendedmag', 'UtÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶kat Magasin ', 5, 0, 1),
	('fabric', 'Tyg', 80, 0, 1),
	('falg', 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lgar', -1, 0, 1),
	('fanta', 'Fanta 33cl', -1, 0, 1),
	('fargpatron', 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤rgpatron', -1, 0, 1),
	('farmennyckel', 'Nyckel', -1, 0, 1),
	('fbrod', 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤rdigt BrÃƒÂƒÃ', -1, 0, 1),
	('firstaidkit', 'First Aid Kit', -1, 0, 1),
	('fish', 'Fisk', 100, 0, 1),
	('fishingrod', 'Fiske SpÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶', 2, 0, 1),
	('fiskespo', 'FiskespÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶', -1, 0, 1),
	('fiskp', 'Fiskpinnar', -1, 0, 1),
	('fixkit', 'Repareringskit', -1, 0, 1),
	('fixtool', 'Reparationsverktyg', -1, 0, 1),
	('flashlight', 'Ficklampa (Vapen)', 10, 0, 1),
	('flaska', 'Tom flaska', 6, 0, 1),
	('focalpen', 'BrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nnpenna', 5, 0, 1),
	('gasmask', 'Gasmask', 4, 0, 1),
	('gazbottle', 'gascylinder', -1, 0, 1),
	('general', 'General Onyx Portionssnus', -1, 0, 1),
	('glass', 'Glass', -1, 0, 1),
	('gold', 'Guld', 21, 0, 1),
	('goldbar', 'Gold Bar', 250, 0, 1),
	('goldnecklace', 'Gold Necklace', 150, 0, 1),
	('goldwatch', 'Gold Watch', 2500, 0, 1),
	('golem', 'Golem', 5, 0, 1),
	('grenade', 'Grenade', -1, 0, 1),
	('grip', 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ste', 10, 0, 1),
	('gslush', 'Gul Slush', -1, 0, 1),
	('guld', 'Guld', 30, 0, 1),
	('guldklimp', 'Guldklimp (1g)', 200, 0, 1),
	('gusenberg', 'Gusenberg Sweeper', -1, 0, 1),
	('gym_membership', 'Gym Medlemskap', -1, 0, 1),
	('hackerDevice', 'Hacking Device', 5, 0, 1),
	('hackkit', 'Hackningskit', -1, 0, 1),
	('hammerwirecutter', 'Hammer And Wire Cutter', 10, 0, 1),
	('handcuffs', 'Handborgar', 1, 0, 1),
	('hane', 'Hane', 15, 0, 1),
	('hat', 'MÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ssa', -1, 0, 1),
	('hatchet', 'Hatchet', -1, 0, 1),
	('heavybarrel', 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rstÃƒÂƒÃ†Â’Ãƒ', 10, 0, 1),
	('heavypistol', 'Heavy Pistol', -1, 0, 1),
	('heavysniper', 'Heavy Sniper', -1, 0, 1),
	('hembrant', 'HembrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤nt', 3, 0, 1),
	('heroin', 'Heroin', -1, 0, 1),
	('heroin_pooch', 'Burk med heroin', 10, 0, 1),
	('hotdog', 'Korv med brÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶d', -1, 0, 1),
	('humanecard', 'Humane Labs Passerkort', 10, 0, 1),
	('hydrochloric_acid', 'Saltsyra', -1, 0, 1),
	('ice', 'GlaÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â§on', 5, 0, 1),
	('icetea', 'Ice Tea', 5, 0, 1),
	('idcard', 'Id kort', 1, 0, 1),
	('implantat', 'Implantat', 2, 0, 1),
	('ipadpro', 'Apple iPad Pro 11 64GB', -1, 0, 1),
	('iphone', 'iPhone XR', 10, 0, 1),
	('ipren', 'Ipren 500mg', -1, 0, 1),
	('iron', 'JÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤rn', 42, 0, 1),
	('jager', 'JÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤germeister', 5, 0, 1),
	('jagerbomb', 'JÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤gerbomb', 5, 0, 1),
	('jagercerbere', 'JÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ger CerbÃƒÂƒÃ', 3, 0, 1),
	('jewels', 'Juveler', 100, 0, 1),
	('joint', 'Marijuana Joint', -1, 0, 1),
	('jusfruit', 'Jus de fruits', 5, 0, 1),
	('kartellnyckel', 'Nyckel', -1, 0, 1),
	('ket', 'Ketchup', -1, 0, 1),
	('knife', 'Knife', -1, 0, 1),
	('knuckle', 'Brass Knuckles', -1, 0, 1),
	('komponent', 'Komponent', 10, 0, 1),
	('komradio', 'Komradio', 1, 0, 1),
	('kondom', 'Kondom', 20, 0, 1),
	('kondompaket', 'Kondompaket', 4, 0, 1),
	('kondomused', 'Kondom', 20, 0, 1),
	('korg', 'Korg', 1, 0, 1),
	('korgfull', 'Korg (Apelsiner)', 1, 0, 1),
	('korv', 'Korv', -1, 0, 1),
	('korvmk', 'Korv med ketchup', -1, 0, 1),
	('laddare', 'Apple Laddare', -1, 0, 1),
	('laminering', 'Lamineringsplast', 100, 0, 1),
	('laptop', 'Laptop', -1, 0, 1),
	('leather', 'LÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤der', -1, 0, 1),
	('levelred', 'Level Red', 5, 0, 1),
	('levelred2', 'Level Red', 40, 0, 1),
	('lighter', 'TÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ndare', -1, 0, 1),
	('limonade', 'Limonade', 5, 0, 1),
	('lithium', 'Lithium Batteries', 10, 0, 1),
	('lmredlabel', 'L&M Red Label', 5, 0, 1),
	('lmredlabel2', 'L&M Red Label', 40, 0, 1),
	('lockpick', 'Dyrk', -1, 0, 1),
	('lotteryticket', 'Trisslott', -1, 0, 1),
	('lsa', 'LSA', -1, 0, 1),
	('lsd', 'LSD', -1, 0, 1),
	('machete', 'Machete', -1, 0, 1),
	('machinepistol', 'Machine Pistol', -1, 0, 1),
	('magasinutlosare', 'MagasinutlÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶sare', 15, 0, 1),
	('magasinutlosare2', 'Avancerad MagasinutlÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒ', 15, 0, 1),
	('magnetremsa', 'Magnetremsa', 100, 0, 1),
	('magnetremsa2', 'Modifierad Magnetremsa', 100, 0, 1),
	('marabou', 'Marabou MjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶lkch', -1, 0, 1),
	('marijuana', 'Marijuana', -1, 0, 1),
	('marlborogold', 'Marlboro Gold', 5, 0, 1),
	('marlborogold2', 'Marlboro Gold', 40, 0, 1),
	('martini', 'Martini blanc', 5, 0, 1),
	('mastercard', 'Mastercard', 1, 0, 1),
	('meat', 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶tt', -1, 0, 1),
	('medikit', 'FÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rsta hjÃƒÂƒÃ†', -1, 0, 1),
	('menthe', 'Feuille de menthe', 10, 0, 1),
	('metall', 'Metall', -1, 0, 1),
	('metalldel', 'Metalldel', -1, 0, 1),
	('metalscrap', 'PlÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥t', 25, 0, 1),
	('meth', 'Meth', -1, 0, 1),
	('methlab', 'Portable Methlab', 1, 0, 1),
	('meth_pooch', 'VÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ska med meth', -1, 0, 1),
	('metreshooter', 'MÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¨tre de shoote', 3, 0, 1),
	('mg', 'MG', -1, 0, 1),
	('microsmg', 'Micro SMG', -1, 0, 1),
	('milk', '???????', 20, 0, 1),
	('milk_engine', '???????????????', 1, 0, 1),
	('milk_package', '??????????', 20, 0, 1),
	('minismg', 'Mini SMG', -1, 0, 1),
	('mixapero', 'Mix ApÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©ritif', 3, 0, 1),
	('mjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶lk', 'MjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶lk', -1, 0, 1),
	('mjol', 'PÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥se med mjÃƒÂƒ', 4, 0, 1),
	('mjolk', 'MjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶lk', -1, 0, 1),
	('mojito', 'Mojito', 5, 0, 1),
	('molotov', 'Molotov', -1, 0, 1),
	('monsterabsolutezero', 'Monster Absolute Zero (500 ml)', 4, 0, 1),
	('monsterjuiced', 'Monster Juiced (500 ml)', 4, 0, 1),
	('monsteroriginal', 'Monster Original (500 ml)', 4, 0, 1),
	('monsterpunch', 'Monster Pipeline Punch (500 ml)', 4, 0, 1),
	('monsterultra', 'Monster Ultra (500 ml)', 4, 0, 1),
	('motor', 'Motor', -1, 0, 1),
	('nightstick', 'Nightstick', -1, 0, 1),
	('nocco', 'Nocco Casiss', -1, 0, 1),
	('notepad', 'Notepad', -1, 0, 1),
	('olw', 'Olw Dill&grÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶slÃ', -1, 0, 1),
	('opium', 'Opium', -1, 0, 1),
	('opium_container', 'Tablettburk (LSD)', 10, 0, 1),
	('opium_pooch', 'LÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥da med opium', -1, 0, 1),
	('oslush', 'Orange Slush', -1, 0, 1),
	('ostbow', 'Ost bÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥gar', -1, 0, 1),
	('oxygen_mask', 'Oxygen Mask', -1, 0, 1),
	('packaged_chicken', 'Paketeradkyckling', 100, 0, 1),
	('packaged_plank', 'Packaterade plankor', 100, 0, 1),
	('pallmallred100s', 'Pall Mall Red 100s', 5, 0, 1),
	('pallmallred100s2', 'Pall Mall Red 100s', 40, 0, 1),
	('pan', 'Vaskpanna', -1, 0, 1),
	('pants', 'Byxor', -1, 0, 1),
	('paraply', 'Paraply', 1, 0, 1),
	('paron', 'PÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ron', -1, 0, 1),
	('patronforare', 'PatronfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rare', 15, 0, 1),
	('patronforare2', 'Avancerad PatronfÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã', 15, 0, 1),
	('pÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ron', 'PÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ron', -1, 0, 1),
	('pepparsprej', 'Pepparsprej', 1, 0, 1),
	('permis', 'Permis de conduire', 10, 0, 1),
	('petrol', 'Bensin', 24, 0, 1),
	('petrol_raffin', 'Bensin Dunk', 24, 0, 1),
	('phone', 'iPhone 11 plus', -1, 0, 1),
	('phoneoff', 'AvstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ngd Telefo', -1, 0, 1),
	('piketvestblackf', 'InsatsvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st - Sv', 5, 0, 1),
	('piketvestblackm', 'InsatsvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st - Sv', 5, 0, 1),
	('piketvestgray2f', 'InsatsvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st - Gr', 5, 0, 1),
	('piketvestgray2m', 'InsatsvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st - Gr', 5, 0, 1),
	('piketvestgrayf', 'InsatsvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st - Gr', 5, 0, 1),
	('piketvestgraym', 'InsatsvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st - Ci', 5, 0, 1),
	('pistol', 'Pistol', -1, 0, 1),
	('pistol50', 'Pistol .50', -1, 0, 1),
	('pizza', 'Billys Kebabpizza', 5, 0, 1),
	('plastic', 'Plast', 25, 0, 1),
	('policecard', 'Polisen - Passerkort', -1, 0, 1),
	('polislarm', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ¢Ã¢Â‚Â¬', 10, 0, 1),
	('poppyresin', 'Vallmo Hart', -1, 0, 1),
	('powerade', 'Powerade', -1, 0, 1),
	('ppa', 'PPA', 10, 0, 1),
	('princerichtaste', 'Prince Rich Taste', 5, 0, 1),
	('princerichtaste2', 'Prince Rich Taste', 40, 0, 1),
	('protein_shake', 'Protein Shake', -1, 0, 1),
	('pumpshotgun', 'Pump Shotgun', -1, 0, 1),
	('radio', 'radio', 1, 0, 1),
	('radiostyrdbil', 'Radiostyrd bil', -1, 0, 1),
	('raspberrypi', 'Raspberry Pi 4 Model B 4GB', 10, 0, 1),
	('raspberrypi2', 'Programmerat Raspberry Pi 4 Model B 4GB', 10, 0, 1),
	('rc', 'Radiostyrd Bil', 1, 0, 1),
	('redbull', 'Red Bull 25cl', -1, 0, 1),
	('rekylfjader', 'RekylfjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lder', 15, 0, 1),
	('rekylfjader2', 'Avancerad RekylfjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã', 15, 0, 1),
	('revolver', 'Revolver', -1, 0, 1),
	('rhum', 'Rhum', 5, 0, 1),
	('rhumcoca', 'Rhum-coca', 5, 0, 1),
	('rhumfruit', 'Rhum-jus de fruits', 5, 0, 1),
	('rizla', 'Papper', -1, 0, 1),
	('rosadildo', 'Rosa Dildo', -1, 0, 1),
	('rubber', 'Gummi', 25, 0, 1),
	('rullstol', 'Rullstol', -1, 0, 1),
	('saffron', 'Saffran', -1, 0, 1),
	('salt', 'Salt', 10, 0, 1),
	('saucisson', 'Saucisson', 5, 0, 1),
	('sawnoffshotgun', 'Sawed-Off Shotgun', -1, 0, 1),
	('scope', 'Sikte', 10, 0, 1),
	('security_card_01', 'Security Card A', 1, 0, 1),
	('seed', 'FrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶', -1, 0, 1),
	('shirt', 'TrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶ja', -1, 0, 1),
	('shoes', 'Skor', -1, 0, 1),
	('sidavbitare', 'Sidavbitare', -1, 0, 1),
	('silencieux', 'Silencer', -1, 0, 1),
	('skalad_banan', 'Skalad Banan', -1, 0, 1),
	('skate', 'Skateboard', -1, 0, 1),
	('skinn', 'Skinn', -1, 0, 1),
	('skivad_annanas', 'Skivad Annanas', -1, 0, 1),
	('skruvar', 'Skruvar', -1, 0, 1),
	('skruvmejsel', 'skruvmejsel', 5, 0, 1),
	('slagfjader', 'SlagfjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤der', 15, 0, 1),
	('slagfjader2', 'Avancerad SlagfjÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚', 15, 0, 1),
	('slaughtered_chicken', 'Slaktad kyckling', 20, 0, 1),
	('slush', 'Orange/Gul Slush', -1, 0, 1),
	('smÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r', 'SmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r', -1, 0, 1),
	('smg', 'SMG', -1, 0, 1),
	('smirnoff', 'Smirnoff', -1, 0, 1),
	('smor', 'SmÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r', -1, 0, 1),
	('sniperrifle', 'Sniper Rifle', -1, 0, 1),
	('snus', 'Ettan Orginal Portion', 20, 0, 1),
	('snus2', 'GÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶teborgs RapÃƒ', 20, 0, 1),
	('snus3', 'General Classic White', 20, 0, 1),
	('snus4', 'Siberia Portion', 20, 0, 1),
	('soda', 'Soda', 5, 0, 1),
	('sodium_hydroxide', 'Natriumhydroxid', -1, 0, 1),
	('sonyalpha', 'Sony Alpha A68K', -1, 0, 1),
	('speaker', 'HÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶gtalare', -1, 0, 1),
	('specialcarbine', 'Special Carbine', -1, 0, 1),
	('sportlunch', 'Sportlunch', -1, 0, 1),
	('sprite', 'Sprite 33cl', 5, 0, 1),
	('stone', 'Sten', 7, 0, 1),
	('stungun', 'Stun Gun', -1, 0, 1),
	('sulfuric_acid', 'Svavelsyra', -1, 0, 1),
	('suppressor', 'LjuddÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤mpare', 10, 0, 1),
	('suspension', 'Suspension', -1, 0, 1),
	('teqpaf', 'Teq\'paf', 5, 0, 1),
	('tequila', 'Tequila', 5, 0, 1),
	('thermite', 'Thermite', 1, 0, 1),
	('thionyl_chloride', 'Tionylklorid', -1, 0, 1),
	('ticket', 'SJ Biljett', -1, 0, 1),
	('ties', 'DÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rr buntband', -1, 0, 1),
	('tomat', 'Tomater', 10, 0, 1),
	('toothpaste', 'TandkrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤m', -1, 0, 1),
	('tramadol', 'Tramadol', -1, 0, 1),
	('transmission', 'Transmission', -1, 0, 1),
	('trisslott', 'Trisslott', -1, 0, 1),
	('trocadero', 'Trocadero 33cl', 5, 0, 1),
	('trojan_usb', 'Trojan USB', 1, 0, 1),
	('turbo', 'Turbo', -1, 0, 1),
	('usb', 'USB Sticka (Full)', 15, 0, 1),
	('usbempty', 'USB Sticka', 15, 0, 1),
	('usbsladd', 'USB Sladd', 10, 0, 1),
	('vaskpanna', 'Vaskpanna', 1, 0, 1),
	('vaskpannafull', 'Vaskpanna (AnvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤', 1, 0, 1),
	('vastholje', 'VÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤sthÃƒÂƒÃ†Â’Ãƒ', 2, 0, 1),
	('vaxellada', 'VÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤xellÃƒÂƒÃ†Â’Ã', -1, 0, 1),
	('vete', 'Vete', 25, 0, 1),
	('vindruvor', 'Vindruvsklas', 5, 0, 1),
	('vintagepistol', 'Vintage Pistol', -1, 0, 1),
	('virusphone', 'Telefon (virus)', 1, 0, 1),
	('vodka', 'Vodka', -1, 0, 1),
	('vodkaenergy', 'Vodka-energy', 5, 0, 1),
	('vodkafruit', 'Vodka-jus de fruits', 5, 0, 1),
	('washed_stone', 'TvÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤ttat sten', 7, 0, 1),
	('water', 'Loka Naturell 33cl', -1, 0, 1),
	('weed', 'Cannabis', -1, 0, 1),
	('weed_pooch', 'joint', -1, 0, 1),
	('weed_purple', 'Purple Haze Weed Plant', -1, 0, 1),
	('weed_seed', 'Marijuana FrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶', -1, 0, 1),
	('weld', 'Svets', 1, 0, 1),
	('whisky', 'Whisky', 5, 0, 1),
	('whiskycoca', 'Whisky-coca', 5, 0, 1),
	('winstonblue', 'Winston Blue', 5, 0, 1),
	('winstonblue2', 'Winston Blue', 40, 0, 1),
	('winstonclassic', 'Winston Classic', 5, 0, 1),
	('winstonclassic2', 'Winston Classic', 40, 0, 1),
	('wood', 'TrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤', 20, 0, 1),
	('wool', 'Ull', 40, 0, 1),
	('yeast', 'JÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤st', 10, 0, 1),
	('yusuf', 'Kamouflage (Prickskytt)', 10, 0, 1);

CREATE TABLE IF NOT EXISTS `jobs` (
  `name` varchar(50) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `whitelisted` tinyint(1) NOT NULL DEFAULT '0',
  `money` int DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `jobs` (`name`, `label`, `whitelisted`, `money`) VALUES
	('ambulance', 'Ambulans', 0, 156569),
	('ballas', 'ballas', 1, 0),
	('bennys', 'Bennys', 1, 0),
	('biker', 'Biker', 1, 0),
	('cardealer', 'Bilfirma', 0, 300000),
	('cartel', 'Cartel', 1, 0),
	('forsakring', 'Trygghansa', 0, 500000),
	('gang', 'Gang', 1, 0),
	('kronofogden', 'kronofogden', 0, 0),
	('mafia', 'Mafia', 1, 0),
	('mecano', 'Mekaniker', 0, 0),
	('pilot', 'Pilot', 0, 50000),
	('police', 'Polisen', 1, 0),
	('postman', 'Post OP', 0, 500000),
	('qpark', 'Qpark', 0, 0),
	('Securitas', 'Securitas', 0, 0),
	('taxi', 'Taxi', 0, 0),
	('trygghansa', 'Trygghansa', 0, 500000),
	('unemployed', 'ArbetslÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶s', 0, 0),
	('unicorn', 'Unicorn', 1, 0),
	('vianor', 'Vianor', 0, 172862);

CREATE TABLE IF NOT EXISTS `job_grades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_name` varchar(50) DEFAULT NULL,
  `grade` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `label` varchar(50) NOT NULL,
  `salary` int NOT NULL,
  `skin_male` longtext NOT NULL,
  `skin_female` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=351 DEFAULT CHARSET=latin1;

REPLACE INTO `job_grades` (`id`, `job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
	(85, 'unemployed', 0, 'unemployed', 'ArbetslÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶s', 250, '{}', '{}'),
	(86, 'pilot', 0, 'pilot', 'Ny anstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 350, '{}', '{}'),
	(87, 'pilot', 1, 'anstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 'AnstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 450, '{}', '{}'),
	(88, 'pilot', 2, 'vicechef', 'Vice-Chef', 550, '{}', '{}'),
	(89, 'pilot', 3, 'boss', 'Boss', 650, '{}', '{}'),
	(125, 'cardealer', 0, 'recruit', 'NyanstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 300, '{}', '{}'),
	(126, 'cardealer', 1, 'novice', 'AnstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 325, '{}', '{}'),
	(127, 'cardealer', 2, 'experienced', 'Erfaren', 350, '{}', '{}'),
	(128, 'cardealer', 3, 'chief', 'BitrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤dande Chef', 375, '{}', '{}'),
	(129, 'cardealer', 4, 'boss', 'Chef', 400, '{}', '{}'),
	(155, 'postman', 0, 'employee', 'AnstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 200, '{}', '{}'),
	(156, 'bennys', 0, 'recrue', 'LÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤rling', 300, '{}', '{}'),
	(157, 'bennys', 1, 'novice', 'AnstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 500, '{}', '{}'),
	(158, 'bennys', 2, 'experimente', 'Erfaren', 700, '{}', '{}'),
	(159, 'bennys', 3, 'chief', 'Chef', 850, '{}', '{}'),
	(160, 'bennys', 4, 'boss', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾ga', 1000, '{}', '{}'),
	(185, 'taxi', 0, 'recrue', 'Rang 1', 300, '{}', '{}'),
	(186, 'taxi', 1, 'novice', 'Rang 2', 325, '{}', '{}'),
	(187, 'taxi', 2, 'experimente', 'Rang 3', 350, '{}', '{}'),
	(188, 'taxi', 3, 'chief', 'Rang 4', 375, '{}', '{}'),
	(189, 'taxi', 4, 'boss', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾ga', 400, '{}', '{}'),
	(195, 'vianor', 0, 'recrue', 'NyanstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 300, '{}', '{}'),
	(196, 'vianor', 1, 'novice', 'AnstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 325, '{}', '{}'),
	(197, 'vianor', 2, 'experimente', 'Erfaren', 350, '{}', '{}'),
	(198, 'vianor', 3, 'chief', 'Del-ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤gare', 375, '{}', '{}'),
	(199, 'vianor', 4, 'boss', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾ga', 400, '{}', '{}'),
	(200, 'trygghansa', 0, 'recrue', 'Rang 1', 300, '{}', '{}'),
	(201, 'trygghansa', 1, 'novice', 'Rang 2', 325, '{}', '{}'),
	(202, 'trygghansa', 2, 'experimente', 'Rang 3', 350, '{}', '{}'),
	(203, 'trygghansa', 3, 'kung', 'Del-ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤gare', 375, '{}', '{}'),
	(204, 'trygghansa', 4, 'boss', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾ga', 400, '{}', '{}'),
	(234, 'ambulance', 0, 'new', 'UnderskÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶terska', 300, '{}', '{}'),
	(235, 'ambulance', 1, 'sjuk', 'SjukskÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶terska', 350, '{}', '{}'),
	(236, 'ambulance', 2, 'lakare', 'LÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤kare', 400, '{}', '{}'),
	(237, 'ambulance', 3, 'over', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ¢Ã¢Â‚Â¬', 450, '{}', '{}'),
	(238, 'ambulance', 4, 'vice', 'BitrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤dande Regi', 500, '{}', '{}'),
	(239, 'ambulance', 5, 'boss', 'Regionschef', 550, '{}', '{}'),
	(256, 'mecano', 0, 'recrue', 'NyanstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 12, '', ''),
	(257, 'mecano', 1, 'novice', 'AnstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 24, '', ''),
	(258, 'mecano', 2, 'experimente', 'Erfaren', 36, '', ''),
	(259, 'mecano', 3, 'boss', 'BitrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤dande Chef', 48, '', ''),
	(260, 'mecano', 4, 'boss', 'ÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ‚Â¢ÃƒÂ¢Ã¢Â€ÂšÃ‚Â¬ÃƒÂ…Ã‚Â¾ga', 0, '', ''),
	(272, 'police', 0, 'recruit', 'Aspirant', 24500, '{}', '{}'),
	(274, 'police', 2, 'sergeant', 'InspektÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶r', 30356, '{}', '{}'),
	(275, 'police', 3, 'sergeant', 'Kommisarie', 32240, '{}', '{}'),
	(276, 'police', 4, 'lieutenant', 'BefÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤l', 35450, '{}', '{}'),
	(277, 'police', 5, 'lieutenant', 'Yttre-BefÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤l', 37330, '{}', '{}'),
	(278, 'police', 6, 'lieutenant', 'Grupp-BefÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤l', 38980, '{}', '{}'),
	(279, 'police', 7, 'lieutenant', 'BefÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤l Havare', 42560, '{}', '{}'),
	(280, 'police', 10, 'boss', 'BitrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤dande Riks', 57000, '{}', '{}'),
	(281, 'police', 11, 'boss', 'Rikspolis Chef', 64820, '{}', '{}'),
	(297, 'police', 9, 'boss', 'SÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤kerhetspolisc', 52560, '{}', '{}'),
	(298, 'police', 1, 'officer', 'Assistent', 25780, '{}', '{}'),
	(299, 'police', 8, 'boss', 'BitrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤dande-SÃƒÂ', 49665, '{}', '{}'),
	(300, 'unicorn', 0, 'barman', 'Barman', 300, '{}', '{}'),
	(301, 'unicorn', 1, 'dancer', 'Danseur', 300, '{}', '{}'),
	(302, 'unicorn', 2, 'viceboss', 'Co-gÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©rant', 500, '{}', '{}'),
	(303, 'unicorn', 3, 'boss', 'GÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©rant', 600, '{}', '{}'),
	(304, 'unicorn', 0, 'barman', 'Barman', 300, '{}', '{}'),
	(305, 'unicorn', 1, 'dancer', 'Danseur', 300, '{}', '{}'),
	(306, 'unicorn', 2, 'viceboss', 'Co-gÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©rant', 500, '{}', '{}'),
	(307, 'unicorn', 3, 'boss', 'GÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©rant', 600, '{}', '{}'),
	(308, 'qpark', 0, 'recruit', 'NyanstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 0, '{}', '{}'),
	(309, 'qpark', 1, 'officer', 'AnstÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤lld', 0, '{}', '{}'),
	(310, 'qpark', 2, 'sergeant', 'Erfaren', 0, '{}', '{}'),
	(311, 'qpark', 3, 'lieutenant', 'Vice Chef', 0, '{}', '{}'),
	(312, 'qpark', 4, 'boss', 'Chef', 0, '{}', '{}'),
	(317, 'Securitas', 0, 'recruit', 'vakt', 50, '{}', '{}'),
	(318, 'Securitas', 1, 'officer', 'BitrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤dande vete', 60, '{}', '{}'),
	(319, 'Securitas', 2, 'sergeant', 'Assistent', 70, '{}', '{}'),
	(320, 'Securitas', 3, 'lieutenant', 'vice chef', 80, '{}', '{}'),
	(321, 'Securitas', 4, 'boss', 'chef', 90, '{}', '{}'),
	(322, 'kronofogden', 0, 'recruit', 'vakt', 50, '{}', '{}'),
	(323, 'kronofogden', 1, 'officer', 'BitrÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¤dande vete', 60, '{}', '{}'),
	(324, 'kronofogden', 2, 'sergeant', 'Assistent', 70, '{}', '{}'),
	(325, 'kronofogden', 3, 'lieutenant', 'vice chef', 80, '{}', '{}'),
	(326, 'kronofogden', 4, 'boss', 'chef', 90, '{}', '{}'),
	(331, 'ballas', 0, 'soldato', 'Soldat', 1500, '{}', '{}'),
	(332, 'ballas', 1, 'capo', 'Spring pojke', 1800, '{}', '{}'),
	(333, 'ballas', 2, 'consigliere', 'RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥dgivare', 2100, '{}', '{}'),
	(334, 'ballas', 3, 'boss', 'Chef', 2700, '{}', '{}'),
	(335, 'biker', 0, 'soldato', 'Soldat', 1500, '{}', '{}'),
	(336, 'biker', 1, 'capo', 'Spring pojke', 1800, '{}', '{}'),
	(337, 'biker', 2, 'consigliere', 'RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥dgivare', 2100, '{}', '{}'),
	(338, 'biker', 3, 'boss', 'Chef', 2700, '{}', '{}'),
	(339, 'cartel', 0, 'soldato', 'Soldat', 1500, '{}', '{}'),
	(340, 'cartel', 1, 'capo', 'Spring pojke', 1800, '{}', '{}'),
	(341, 'cartel', 2, 'consigliere', 'RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥dgivare', 2100, '{}', '{}'),
	(342, 'cartel', 3, 'boss', 'Chef', 2700, '{}', '{}'),
	(343, 'gang', 0, 'soldato', 'Soldat', 1500, '{}', '{}'),
	(344, 'gang', 1, 'capo', 'Spring pojke', 1800, '{}', '{}'),
	(345, 'gang', 2, 'consigliere', 'RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥dgivare', 2100, '{}', '{}'),
	(346, 'gang', 3, 'boss', 'Chef', 2700, '{}', '{}'),
	(347, 'mafia', 0, 'soldato', 'Soldat', 1500, '{}', '{}'),
	(348, 'mafia', 1, 'capo', 'Spring pojke', 1800, '{}', '{}'),
	(349, 'mafia', 2, 'consigliere', 'RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¥dgivare', 2100, '{}', '{}'),
	(350, 'mafia', 3, 'boss', 'Chef', 2700, '{}', '{}');

CREATE TABLE IF NOT EXISTS `jsfour_atm` (
  `identifier` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `pincode` int NOT NULL DEFAULT '1111'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_cardetails` (
  `pk` int NOT NULL AUTO_INCREMENT,
  `plate` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `incident` varchar(255) NOT NULL DEFAULT '{}',
  `inspected` varchar(255) DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_criminalrecord` (
  `offense` varchar(160) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `charge` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `term` varchar(255) DEFAULT NULL,
  `classified` int NOT NULL DEFAULT '0',
  `identifier` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `warden` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`offense`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_criminaluserinfo` (
  `identifier` varchar(160) NOT NULL,
  `aliases` varchar(255) DEFAULT NULL,
  `recordid` varchar(255) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  `eyecolor` varchar(255) DEFAULT NULL,
  `haircolor` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_dna` (
  `pk` varchar(255) NOT NULL,
  `killer` varchar(255) DEFAULT NULL,
  `dead` varchar(255) DEFAULT NULL,
  `weapon` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT 'murder',
  `lastdigits` varchar(255) DEFAULT NULL,
  `uploader` varchar(255) DEFAULT NULL,
  `datum` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_efterlysningar` (
  `pk` int NOT NULL AUTO_INCREMENT,
  `wanted` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `crime` varchar(255) DEFAULT NULL,
  `uploader` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `incident` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_forum` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT 'post',
  `text` longtext,
  `username` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_incidents` (
  `pk` int NOT NULL AUTO_INCREMENT,
  `number` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `uploader` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `text` longtext,
  `title` varchar(255) DEFAULT 'Title',
  `image` varchar(255) DEFAULT 'https://via.placeholder.com/50/FFFFFFF/?text=JOB',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_logs` (
  `pk` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `remover` varchar(255) DEFAULT NULL,
  `wanted` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_mail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `from` varchar(255) DEFAULT NULL,
  `to` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `folder` varchar(255) DEFAULT 'inbox',
  `read` tinyint DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_medicalrecords` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `uploader` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `text` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `job` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT 'https://via.placeholder.com/50?text=A',
  `desktop` varchar(255) DEFAULT 'assets/images/windows.png',
  `iconslots` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

REPLACE INTO `jsfour_users` (`id`, `username`, `password`, `firstname`, `lastname`, `group`, `job`, `avatar`, `desktop`, `iconslots`) VALUES
	(1, 'admin', 'admin', 'admin', 'admin', 'admin', 'all', 'https://via.placeholder.com/50x50', 'assets/images/windows.png', NULL);

CREATE TABLE IF NOT EXISTS `licenses` (
  `type` varchar(60) NOT NULL,
  `label` varchar(60) NOT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'KÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rkortstillstÃƒÂƒÃ†Â’ÃƒÂ'),
	('drive', 'B-kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rkort'),
	('drive_bike', 'A-kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rkort'),
	('drive_truck', 'C-kÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â¶rkort');

CREATE TABLE IF NOT EXISTS `owned_properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `rented` int NOT NULL,
  `owner` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `owned_vehicles` (
  `owner` varchar(22) NOT NULL,
  `plate` varchar(12) NOT NULL,
  `vehicle` longtext,
  `forsakrad` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Etat de la voiture',
  `hasGPS` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'nxrp-mekonomen',
  `garage` varchar(200) DEFAULT '1',
  `fuel` int NOT NULL DEFAULT '100',
  `lasthouse` int DEFAULT '0',
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_blocked` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `number` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_favorites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `time` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;


CREATE TABLE IF NOT EXISTS `phone_images` (
  `cid` varchar(50) NOT NULL,
  `photos` longtext NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_latest` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `incoming` tinyint(1) NOT NULL DEFAULT '1',
  `missed` tinyint(1) NOT NULL DEFAULT '0',
  `time` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_messages` (
  `identifier` varchar(50) DEFAULT NULL,
  `receiver` varchar(50) DEFAULT NULL,
  `text` longtext,
  `date` varchar(50) DEFAULT NULL,
  `timestamp` int DEFAULT NULL,
  `anon` tinyint DEFAULT NULL,
  `self` tinyint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=188940 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_tweets` (
  `message` longtext,
  `date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `playerhousing` (
  `id` int NOT NULL,
  `owner` varchar(50) DEFAULT NULL,
  `rented` tinyint(1) DEFAULT NULL,
  `price` int DEFAULT NULL,
  `wardrobe` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `entering` varchar(255) DEFAULT NULL,
  `exit` varchar(255) DEFAULT NULL,
  `inside` varchar(255) DEFAULT NULL,
  `outside` varchar(255) DEFAULT NULL,
  `ipls` varchar(255) DEFAULT '[]',
  `gateway` varchar(255) DEFAULT NULL,
  `is_single` int DEFAULT NULL,
  `is_room` int DEFAULT NULL,
  `is_gateway` int DEFAULT NULL,
  `room_menu` varchar(255) DEFAULT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

REPLACE INTO `properties` (`id`, `name`, `label`, `entering`, `exit`, `inside`, `outside`, `ipls`, `gateway`, `is_single`, `is_room`, `is_gateway`, `room_menu`, `price`) VALUES
	(1, 'WhispymoundDrive', '2677 Whispymound Drive', '{"y":564.89,"z":182.959,"x":119.384}', '{"x":117.347,"y":559.506,"z":183.304}', '{"y":557.032,"z":183.301,"x":118.037}', '{"y":567.798,"z":182.131,"x":119.249}', '[]', NULL, 1, 1, 0, '{"x":118.748,"y":566.573,"z":175.697}', 1500000),
	(2, 'NorthConkerAvenue2045', '2045 North Conker Avenue', '{"x":372.796,"y":428.327,"z":144.685}', '{"x":373.548,"y":422.982,"z":144.907},', '{"y":420.075,"z":145.904,"x":372.161}', '{"x":372.454,"y":432.886,"z":143.443}', '[]', NULL, 1, 1, 0, '{"x":377.349,"y":429.422,"z":137.3}', 1500000),
	(3, 'RichardMajesticApt2', 'Richard Majestic, Apt 2', '{"y":-379.165,"z":37.961,"x":-936.363}', '{"y":-365.476,"z":113.274,"x":-913.097}', '{"y":-367.637,"z":113.274,"x":-918.022}', '{"y":-382.023,"z":37.961,"x":-943.626}', '[]', NULL, 1, 1, 0, '{"x":-927.554,"y":-377.744,"z":112.674}', 1700000),
	(4, 'NorthConkerAvenue2044', '2044 North Conker Avenue', '{"y":440.8,"z":146.702,"x":346.964}', '{"y":437.456,"z":148.394,"x":341.683}', '{"y":435.626,"z":148.394,"x":339.595}', '{"x":350.535,"y":443.329,"z":145.764}', '[]', NULL, 1, 1, 0, '{"x":337.726,"y":436.985,"z":140.77}', 1500000),
	(5, 'WildOatsDrive', '3655 Wild Oats Drive', '{"y":502.696,"z":136.421,"x":-176.003}', '{"y":497.817,"z":136.653,"x":-174.349}', '{"y":495.069,"z":136.666,"x":-173.331}', '{"y":506.412,"z":135.0664,"x":-177.927}', '[]', NULL, 1, 1, 0, '{"x":-174.725,"y":493.095,"z":129.043}', 1500000),
	(6, 'HillcrestAvenue2862', '2862 Hillcrest Avenue', '{"y":596.58,"z":142.641,"x":-686.554}', '{"y":591.988,"z":144.392,"x":-681.728}', '{"y":590.608,"z":144.392,"x":-680.124}', '{"y":599.019,"z":142.059,"x":-689.492}', '[]', NULL, 1, 1, 0, '{"x":-680.46,"y":588.6,"z":136.769}', 1500000),
	(7, 'LowEndApartment', 'Appartement de base', '{"y":-1078.735,"z":28.4031,"x":292.528}', '{"y":-1007.152,"z":-102.002,"x":265.845}', '{"y":-1002.802,"z":-100.008,"x":265.307}', '{"y":-1078.669,"z":28.401,"x":296.738}', '[]', NULL, 1, 1, 0, '{"x":265.916,"y":-999.38,"z":-100.008}', 562500),
	(8, 'MadWayneThunder', '2113 Mad Wayne Thunder', '{"y":454.955,"z":96.462,"x":-1294.433}', '{"x":-1289.917,"y":449.541,"z":96.902}', '{"y":446.322,"z":96.899,"x":-1289.642}', '{"y":455.453,"z":96.517,"x":-1298.851}', '[]', NULL, 1, 1, 0, '{"x":-1287.306,"y":455.901,"z":89.294}', 1500000),
	(9, 'HillcrestAvenue2874', '2874 Hillcrest Avenue', '{"x":-853.346,"y":696.678,"z":147.782}', '{"y":690.875,"z":151.86,"x":-859.961}', '{"y":688.361,"z":151.857,"x":-859.395}', '{"y":701.628,"z":147.773,"x":-855.007}', '[]', NULL, 1, 1, 0, '{"x":-858.543,"y":697.514,"z":144.253}', 1500000),
	(10, 'HillcrestAvenue2868', '2868 Hillcrest Avenue', '{"y":620.494,"z":141.588,"x":-752.82}', '{"y":618.62,"z":143.153,"x":-759.317}', '{"y":617.629,"z":143.153,"x":-760.789}', '{"y":621.281,"z":141.254,"x":-750.919}', '[]', NULL, 1, 1, 0, '{"x":-762.504,"y":618.992,"z":135.53}', 1500000),
	(11, 'TinselTowersApt12', 'Tinsel Towers, Apt 42', '{"y":37.025,"z":42.58,"x":-618.299}', '{"y":58.898,"z":97.2,"x":-603.301}', '{"y":58.941,"z":97.2,"x":-608.741}', '{"y":30.603,"z":42.524,"x":-620.017}', '[]', NULL, 1, 1, 0, '{"x":-622.173,"y":54.585,"z":96.599}', 1700000),
	(12, 'MiltonDrive', 'Milton Drive', '{"x":-775.17,"y":312.01,"z":84.658}', NULL, NULL, '{"x":-775.346,"y":306.776,"z":84.7}', '[]', NULL, 0, 0, 1, NULL, 0),
	(13, 'Modern1Apartment', 'Appartement Moderne 1', NULL, '{"x":-784.194,"y":323.636,"z":210.997}', '{"x":-779.751,"y":323.385,"z":210.997}', NULL, '["apa_v_mp_h_01_a"]', 'MiltonDrive', 0, 1, 0, '{"x":-766.661,"y":327.672,"z":210.396}', 1300000),
	(14, 'Modern2Apartment', 'Appartement Moderne 2', NULL, '{"x":-786.8663,"y":315.764,"z":186.913}', '{"x":-781.808,"y":315.866,"z":186.913}', NULL, '["apa_v_mp_h_01_c"]', 'MiltonDrive', 0, 1, 0, '{"x":-795.735,"y":326.757,"z":186.313}', 1300000),
	(15, 'Modern3Apartment', 'Appartement Moderne 3', NULL, '{"x":-774.012,"y":342.042,"z":195.686}', '{"x":-779.057,"y":342.063,"z":195.686}', NULL, '["apa_v_mp_h_01_b"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.386,"y":330.782,"z":195.08}', 1300000),
	(16, 'Mody1Apartment', 'Appartement Mode 1', NULL, '{"x":-784.194,"y":323.636,"z":210.997}', '{"x":-779.751,"y":323.385,"z":210.997}', NULL, '["apa_v_mp_h_02_a"]', 'MiltonDrive', 0, 1, 0, '{"x":-766.615,"y":327.878,"z":210.396}', 1300000),
	(17, 'Mody2Apartment', 'Appartement Mode 2', NULL, '{"x":-786.8663,"y":315.764,"z":186.913}', '{"x":-781.808,"y":315.866,"z":186.913}', NULL, '["apa_v_mp_h_02_c"]', 'MiltonDrive', 0, 1, 0, '{"x":-795.297,"y":327.092,"z":186.313}', 1300000),
	(18, 'Mody3Apartment', 'Appartement Mode 3', NULL, '{"x":-774.012,"y":342.042,"z":195.686}', '{"x":-779.057,"y":342.063,"z":195.686}', NULL, '["apa_v_mp_h_02_b"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.303,"y":330.932,"z":195.085}', 1300000),
	(19, 'Vibrant1Apartment', 'Appartement Vibrant 1', NULL, '{"x":-784.194,"y":323.636,"z":210.997}', '{"x":-779.751,"y":323.385,"z":210.997}', NULL, '["apa_v_mp_h_03_a"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.885,"y":327.641,"z":210.396}', 1300000),
	(20, 'Vibrant2Apartment', 'Appartement Vibrant 2', NULL, '{"x":-786.8663,"y":315.764,"z":186.913}', '{"x":-781.808,"y":315.866,"z":186.913}', NULL, '["apa_v_mp_h_03_c"]', 'MiltonDrive', 0, 1, 0, '{"x":-795.607,"y":327.344,"z":186.313}', 1300000),
	(21, 'Vibrant3Apartment', 'Appartement Vibrant 3', NULL, '{"x":-774.012,"y":342.042,"z":195.686}', '{"x":-779.057,"y":342.063,"z":195.686}', NULL, '["apa_v_mp_h_03_b"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.525,"y":330.851,"z":195.085}', 1300000),
	(22, 'Sharp1Apartment', 'Appartement Persan 1', NULL, '{"x":-784.194,"y":323.636,"z":210.997}', '{"x":-779.751,"y":323.385,"z":210.997}', NULL, '["apa_v_mp_h_04_a"]', 'MiltonDrive', 0, 1, 0, '{"x":-766.527,"y":327.89,"z":210.396}', 1300000),
	(23, 'Sharp2Apartment', 'Appartement Persan 2', NULL, '{"x":-786.8663,"y":315.764,"z":186.913}', '{"x":-781.808,"y":315.866,"z":186.913}', NULL, '["apa_v_mp_h_04_c"]', 'MiltonDrive', 0, 1, 0, '{"x":-795.642,"y":326.497,"z":186.313}', 1300000),
	(24, 'Sharp3Apartment', 'Appartement Persan 3', NULL, '{"x":-774.012,"y":342.042,"z":195.686}', '{"x":-779.057,"y":342.063,"z":195.686}', NULL, '["apa_v_mp_h_04_b"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.503,"y":331.318,"z":195.085}', 1300000),
	(25, 'Monochrome1Apartment', 'Appartement Monochrome 1', NULL, '{"x":-784.194,"y":323.636,"z":210.997}', '{"x":-779.751,"y":323.385,"z":210.997}', NULL, '["apa_v_mp_h_05_a"]', 'MiltonDrive', 0, 1, 0, '{"x":-766.289,"y":328.086,"z":210.396}', 1300000),
	(26, 'Monochrome2Apartment', 'Appartement Monochrome 2', NULL, '{"x":-786.8663,"y":315.764,"z":186.913}', '{"x":-781.808,"y":315.866,"z":186.913}', NULL, '["apa_v_mp_h_05_c"]', 'MiltonDrive', 0, 1, 0, '{"x":-795.692,"y":326.762,"z":186.313}', 1300000),
	(27, 'Monochrome3Apartment', 'Appartement Monochrome 3', NULL, '{"x":-774.012,"y":342.042,"z":195.686}', '{"x":-779.057,"y":342.063,"z":195.686}', NULL, '["apa_v_mp_h_05_b"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.094,"y":330.976,"z":195.085}', 1300000),
	(28, 'Seductive1Apartment', 'Appartement SÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©duisant 1', NULL, '{"x":-784.194,"y":323.636,"z":210.997}', '{"x":-779.751,"y":323.385,"z":210.997}', NULL, '["apa_v_mp_h_06_a"]', 'MiltonDrive', 0, 1, 0, '{"x":-766.263,"y":328.104,"z":210.396}', 1300000),
	(29, 'Seductive2Apartment', 'Appartement SÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©duisant 2', NULL, '{"x":-786.8663,"y":315.764,"z":186.913}', '{"x":-781.808,"y":315.866,"z":186.913}', NULL, '["apa_v_mp_h_06_c"]', 'MiltonDrive', 0, 1, 0, '{"x":-795.655,"y":326.611,"z":186.313}', 1300000),
	(30, 'Seductive3Apartment', 'Appartement SÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©duisant 3', NULL, '{"x":-774.012,"y":342.042,"z":195.686}', '{"x":-779.057,"y":342.063,"z":195.686}', NULL, '["apa_v_mp_h_06_b"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.3,"y":331.414,"z":195.085}', 1300000),
	(31, 'Regal1Apartment', 'Appartement RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©gal 1', NULL, '{"x":-784.194,"y":323.636,"z":210.997}', '{"x":-779.751,"y":323.385,"z":210.997}', NULL, '["apa_v_mp_h_07_a"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.956,"y":328.257,"z":210.396}', 1300000),
	(32, 'Regal2Apartment', 'Appartement RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©gal 2', NULL, '{"x":-786.8663,"y":315.764,"z":186.913}', '{"x":-781.808,"y":315.866,"z":186.913}', NULL, '["apa_v_mp_h_07_c"]', 'MiltonDrive', 0, 1, 0, '{"x":-795.545,"y":326.659,"z":186.313}', 1300000),
	(33, 'Regal3Apartment', 'Appartement RÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©gal 3', NULL, '{"x":-774.012,"y":342.042,"z":195.686}', '{"x":-779.057,"y":342.063,"z":195.686}', NULL, '["apa_v_mp_h_07_b"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.087,"y":331.429,"z":195.123}', 1300000),
	(34, 'Aqua1Apartment', 'Appartement Aqua 1', NULL, '{"x":-784.194,"y":323.636,"z":210.997}', '{"x":-779.751,"y":323.385,"z":210.997}', NULL, '["apa_v_mp_h_08_a"]', 'MiltonDrive', 0, 1, 0, '{"x":-766.187,"y":328.47,"z":210.396}', 1300000),
	(35, 'Aqua2Apartment', 'Appartement Aqua 2', NULL, '{"x":-786.8663,"y":315.764,"z":186.913}', '{"x":-781.808,"y":315.866,"z":186.913}', NULL, '["apa_v_mp_h_08_c"]', 'MiltonDrive', 0, 1, 0, '{"x":-795.658,"y":326.563,"z":186.313}', 1300000),
	(36, 'Aqua3Apartment', 'Appartement Aqua 3', NULL, '{"x":-774.012,"y":342.042,"z":195.686}', '{"x":-779.057,"y":342.063,"z":195.686}', NULL, '["apa_v_mp_h_08_b"]', 'MiltonDrive', 0, 1, 0, '{"x":-765.287,"y":331.084,"z":195.086}', 1300000),
	(37, 'IntegrityWay', '4 Integrity Way', '{"x":-47.804,"y":-585.867,"z":36.956}', NULL, NULL, '{"x":-54.178,"y":-583.762,"z":35.798}', '[]', NULL, 0, 0, 1, NULL, 0),
	(38, 'IntegrityWay28', '4 Integrity Way - Apt 28', NULL, '{"x":-31.409,"y":-594.927,"z":79.03}', '{"x":-26.098,"y":-596.909,"z":79.03}', NULL, '[]', 'IntegrityWay', 0, 1, 0, '{"x":-11.923,"y":-597.083,"z":78.43}', 1700000),
	(39, 'IntegrityWay30', '4 Integrity Way - Apt 30', NULL, '{"x":-17.702,"y":-588.524,"z":89.114}', '{"x":-16.21,"y":-582.569,"z":89.114}', NULL, '[]', 'IntegrityWay', 0, 1, 0, '{"x":-26.327,"y":-588.384,"z":89.123}', 1700000),
	(40, 'DellPerroHeights', 'Dell Perro Heights', '{"x":-1447.06,"y":-538.28,"z":33.74}', NULL, NULL, '{"x":-1440.022,"y":-548.696,"z":33.74}', '[]', NULL, 0, 0, 1, NULL, 0),
	(41, 'DellPerroHeightst4', 'Dell Perro Heights - Apt 28', NULL, '{"x":-1452.125,"y":-540.591,"z":73.044}', '{"x":-1455.435,"y":-535.79,"z":73.044}', NULL, '[]', 'DellPerroHeights', 0, 1, 0, '{"x":-1467.058,"y":-527.571,"z":72.443}', 1700000),
	(42, 'DellPerroHeightst7', 'Dell Perro Heights - Apt 30', NULL, '{"x":-1451.562,"y":-523.535,"z":55.928}', '{"x":-1456.02,"y":-519.209,"z":55.929}', NULL, '[]', 'DellPerroHeights', 0, 1, 0, '{"x":-1457.026,"y":-530.219,"z":55.937}', 1700000);

CREATE TABLE IF NOT EXISTS `rented_vehicles` (
  `vehicle` varchar(60) NOT NULL,
  `plate` varchar(12) NOT NULL,
  `player_name` varchar(255) NOT NULL,
  `base_price` int NOT NULL,
  `rent_price` int NOT NULL,
  `owner` varchar(46) DEFAULT NULL,
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `society_moneywash` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(60) NOT NULL,
  `society` varchar(60) NOT NULL,
  `amount` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `storages` (
  `storage` varchar(255) NOT NULL,
  `data` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `trunk_inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plate` varchar(8) NOT NULL,
  `data` text NOT NULL,
  `owned` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plate` (`plate`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `twitter_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL,
  `at` varchar(50) DEFAULT NULL,
  `message` varchar(250) NOT NULL,
  `img` varchar(50) NOT NULL,
  `time` bigint NOT NULL,
  `verified` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=464 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `twitter_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `img` varchar(50) DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `time` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;


CREATE TABLE IF NOT EXISTS `users` (
  `identifier` varchar(50) DEFAULT NULL,
  `license` varchar(50) DEFAULT NULL,
  `money` int DEFAULT NULL,
  `name` varchar(50) DEFAULT '',
  `skin` longtext,
  `job` varchar(50) DEFAULT 'unemployed',
  `job_grade` int DEFAULT '0',
  `loadout` longtext,
  `position` varchar(100) DEFAULT NULL,
  `bank` int DEFAULT NULL,
  `permission_level` int DEFAULT NULL,
  `group` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT '',
  `lastname` varchar(50) DEFAULT '',
  `dateofbirth` varchar(25) DEFAULT '',
  `sex` varchar(10) DEFAULT '',
  `height` varchar(5) DEFAULT '',
  `tattoos` longtext,
  `lastdigits` varchar(255) DEFAULT NULL,
  `status` longtext,
  `is_dead` bit(1) DEFAULT b'0',
  `ip` bigint DEFAULT NULL,
  `discord` bigint DEFAULT NULL,
  `carthiefv2` bigint NOT NULL DEFAULT '0',
  `hashuntinglicense` tinyint(1) NOT NULL DEFAULT '0',
  `huntingweapons` varchar(255) NOT NULL DEFAULT '{}',
  `phone_number` varchar(10) DEFAULT NULL,
  `jail` int NOT NULL DEFAULT '0',
  `reason` text,
  `handcuffed` tinyint(1) DEFAULT '0',
  `last_house` int DEFAULT '0',
  `last_property` varchar(255) DEFAULT NULL,
  `animations` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(22) NOT NULL,
  `name` varchar(50) NOT NULL,
  `money` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_billings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(60) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `sender` varchar(60) DEFAULT NULL,
  `receiverName` varchar(255) NOT NULL,
  `senderName` varchar(255) DEFAULT NULL,
  `jobb` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_gangs` (
  `userId` varchar(255) DEFAULT NULL,
  `gang` varchar(255) DEFAULT NULL,
  `grade` varchar(255) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(22) NOT NULL,
  `item` varchar(50) NOT NULL,
  `count` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33512 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_lastcharacter` (
  `steamid` varchar(255) NOT NULL,
  `charid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_licenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(60) NOT NULL,
  `owner` varchar(60) NOT NULL,
  `point` int NOT NULL DEFAULT '12',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_quests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `characterId` varchar(50) NOT NULL,
  `quests` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `uteknark` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `stage` int unsigned NOT NULL DEFAULT '1',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `soil` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stage` (`stage`,`time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `vcac_ban` (
  `identifier` varchar(25) NOT NULL,
  `license` varchar(50) DEFAULT NULL,
  `liveid` varchar(21) DEFAULT NULL,
  `xblid` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `playerip` varchar(25) DEFAULT NULL,
  `sourceplayername` varchar(50) DEFAULT NULL,
  `report_id` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`identifier`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `vehiclekeys` (
  `identifier` varchar(22) NOT NULL,
  `data` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `vehicles` (
  `name` varchar(60) NOT NULL,
  `model` varchar(60) NOT NULL,
  `price` int NOT NULL,
  `category` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`model`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `vehicles` (`name`, `model`, `price`, `category`) VALUES
	('Adder', 'adder', 900000, 'super'),
	('Akuma', 'AKUMA', 7500, 'motorcycles'),
	('Alpha', 'alpha', 60000, 'sports'),
	('Ardent', 'ardent', 1150000, 'sportsclassics'),
	('Asea', 'asea', 5500, 'sedans'),
	('Autarch', 'autarch', 1955000, 'super'),
	('Avarus', 'avarus', 18000, 'motorcycles'),
	('Bagger', 'bagger', 13500, 'motorcycles'),
	('Baller', 'baller2', 40000, 'suvs'),
	('Baller Sport', 'baller3', 60000, 'suvs'),
	('Banshee', 'banshee', 70000, 'sports'),
	('Banshee 900R', 'banshee2', 255000, 'super'),
	('Bati 801', 'bati', 12000, 'motorcycles'),
	('Bati 801RR', 'bati2', 19000, 'motorcycles'),
	('Bestia GTS', 'bestiagts', 55000, 'sports'),
	('BF400', 'bf400', 6500, 'motorcycles'),
	('Bf Injection', 'bfinjection', 16000, 'offroad'),
	('Bifta', 'bifta', 12000, 'offroad'),
	('Bison', 'bison', 45000, 'vans'),
	('Blade', 'blade', 15000, 'muscle'),
	('Blazer', 'blazer', 6500, 'offroad'),
	('Blazer Sport', 'blazer4', 8500, 'offroad'),
	('blazer5', 'blazer5', 1755600, 'offroad'),
	('Blista', 'blista', 8000, 'compacts'),
	('BMX (velo)', 'bmx', 160, 'motorcycles'),
	('Bobcat XL', 'bobcatxl', 32000, 'vans'),
	('Brawler', 'brawler', 45000, 'offroad'),
	('Brioso R/A', 'brioso', 18000, 'compacts'),
	('Btype', 'btype', 62000, 'sportsclassics'),
	('Btype Hotroad', 'btype2', 155000, 'sportsclassics'),
	('Btype Luxe', 'btype3', 85000, 'sportsclassics'),
	('Buccaneer', 'buccaneer', 18000, 'muscle'),
	('Buccaneer Rider', 'buccaneer2', 24000, 'muscle'),
	('Buffalo', 'buffalo', 12000, 'sports'),
	('Buffalo S', 'buffalo2', 20000, 'sports'),
	('Bullet', 'bullet', 90000, 'super'),
	('Burrito', 'burrito3', 19000, 'vans'),
	('Camper', 'camper', 42000, 'vans'),
	('Carbonizzare', 'carbonizzare', 75000, 'sports'),
	('Carbon RS', 'carbonrs', 18000, 'motorcycles'),
	('Casco', 'casco', 30000, 'sportsclassics'),
	('Cavalcade', 'cavalcade2', 55000, 'suvs'),
	('Cheetah', 'cheetah', 375000, 'super'),
	('Chimera', 'chimera', 38000, 'motorcycles'),
	('Chino', 'chino', 15000, 'muscle'),
	('Chino Luxe', 'chino2', 19000, 'muscle'),
	('Cliffhanger', 'cliffhanger', 9500, 'motorcycles'),
	('Cognoscenti Cabrio', 'cogcabrio', 55000, 'coupes'),
	('Cognoscenti', 'cognoscenti', 55000, 'sedans'),
	('Comet', 'comet2', 65000, 'sports'),
	('Comet 5', 'comet5', 1145000, 'sports'),
	('Contender', 'contender', 70000, 'suvs'),
	('Coquette', 'coquette', 65000, 'sports'),
	('Coquette Classic', 'coquette2', 40000, 'sportsclassics'),
	('Coquette BlackFin', 'coquette3', 55000, 'muscle'),
	('Cruiser (velo)', 'cruiser', 510, 'motorcycles'),
	('Cyclone', 'cyclone', 1890000, 'super'),
	('Daemon', 'daemon', 11500, 'motorcycles'),
	('Daemon High', 'daemon2', 13500, 'motorcycles'),
	('Defiler', 'defiler', 9800, 'motorcycles'),
	('Deluxo', 'deluxo', 4721500, 'sportsclassics'),
	('Dominator', 'dominator', 35000, 'muscle'),
	('Double T', 'double', 28000, 'motorcycles'),
	('Dubsta', 'dubsta', 45000, 'suvs'),
	('Dubsta Luxuary', 'dubsta2', 60000, 'suvs'),
	('Bubsta 6x6', 'dubsta3', 120000, 'offroad'),
	('Dukes', 'dukes', 28000, 'muscle'),
	('Dune Buggy', 'dune', 8000, 'offroad'),
	('Elegy', 'elegy2', 38500, 'sports'),
	('Emperor', 'emperor', 8500, 'sedans'),
	('Enduro', 'enduro', 5500, 'motorcycles'),
	('Entity XF', 'entityxf', 425000, 'super'),
	('Esskey', 'esskey', 4200, 'motorcycles'),
	('Exemplar', 'exemplar', 32000, 'coupes'),
	('F620', 'f620', 40000, 'coupes'),
	('Faction', 'faction', 20000, 'muscle'),
	('Faction Rider', 'faction2', 30000, 'muscle'),
	('Faction XL', 'faction3', 40000, 'muscle'),
	('Faggio', 'faggio', 1900, 'motorcycles'),
	('Vespa', 'faggio2', 2800, 'motorcycles'),
	('Felon', 'felon', 42000, 'coupes'),
	('Felon GT', 'felon2', 55000, 'coupes'),
	('Feltzer', 'feltzer2', 55000, 'sports'),
	('Stirling GT', 'feltzer3', 65000, 'sportsclassics'),
	('Fixter (velo)', 'fixter', 225, 'motorcycles'),
	('FMJ', 'fmj', 185000, 'super'),
	('Fhantom', 'fq2', 17000, 'suvs'),
	('Fugitive', 'fugitive', 12000, 'sedans'),
	('Furore GT', 'furoregt', 45000, 'sports'),
	('Fusilade', 'fusilade', 40000, 'sports'),
	('Gargoyle', 'gargoyle', 16500, 'motorcycles'),
	('Gauntlet', 'gauntlet', 30000, 'muscle'),
	('Gang Burrito', 'gburrito', 45000, 'vans'),
	('Burrito', 'gburrito2', 29000, 'vans'),
	('Glendale', 'glendale', 6500, 'sedans'),
	('Grabger', 'granger', 50000, 'suvs'),
	('Gresley', 'gresley', 47500, 'suvs'),
	('GT 500', 'gt500', 785000, 'sportsclassics'),
	('Guardian', 'guardian', 45000, 'offroad'),
	('Hakuchou', 'hakuchou', 31000, 'motorcycles'),
	('Hakuchou Sport', 'hakuchou2', 55000, 'motorcycles'),
	('Hermes', 'hermes', 535000, 'muscle'),
	('Hexer', 'hexer', 12000, 'motorcycles'),
	('Hotknife', 'hotknife', 125000, 'muscle'),
	('Huntley S', 'huntley', 40000, 'suvs'),
	('Hustler', 'hustler', 625000, 'muscle'),
	('Infernus', 'infernus', 180000, 'super'),
	('Innovation', 'innovation', 23500, 'motorcycles'),
	('Intruder', 'intruder', 7500, 'sedans'),
	('Issi', 'issi2', 10000, 'compacts'),
	('Jackal', 'jackal', 38000, 'coupes'),
	('Jester', 'jester', 65000, 'sports'),
	('Jester(Racecar)', 'jester2', 135000, 'sports'),
	('Journey', 'journey', 6500, 'vans'),
	('Kamacho', 'kamacho', 345000, 'offroad'),
	('Khamelion', 'khamelion', 38000, 'sports'),
	('Kuruma', 'kuruma', 30000, 'sports'),
	('Landstalker', 'landstalker', 35000, 'suvs'),
	('RE-7B', 'le7b', 325000, 'super'),
	('Lynx', 'lynx', 40000, 'sports'),
	('Mamba', 'mamba', 70000, 'sports'),
	('Manana', 'manana', 12800, 'sportsclassics'),
	('Manchez', 'manchez', 5300, 'motorcycles'),
	('Massacro', 'massacro', 65000, 'sports'),
	('Massacro(Racecar)', 'massacro2', 130000, 'sports'),
	('Mesa', 'mesa', 16000, 'suvs'),
	('Mesa Trail', 'mesa3', 40000, 'suvs'),
	('Minivan', 'minivan', 13000, 'vans'),
	('Monroe', 'monroe', 55000, 'sportsclassics'),
	('The Liberator', 'monster', 210000, 'offroad'),
	('Moonbeam', 'moonbeam', 18000, 'vans'),
	('Moonbeam Rider', 'moonbeam2', 35000, 'vans'),
	('Nemesis', 'nemesis', 5800, 'motorcycles'),
	('Neon', 'neon', 1500000, 'sports'),
	('Nightblade', 'nightblade', 35000, 'motorcycles'),
	('Nightshade', 'nightshade', 65000, 'muscle'),
	('9F', 'ninef', 65000, 'sports'),
	('9F Cabrio', 'ninef2', 80000, 'sports'),
	('Omnis', 'omnis', 35000, 'sports'),
	('Oppressor', 'oppressor', 3524500, 'super'),
	('Oracle XS', 'oracle2', 35000, 'coupes'),
	('Osiris', 'osiris', 160000, 'super'),
	('Panto', 'panto', 10000, 'compacts'),
	('Paradise', 'paradise', 19000, 'vans'),
	('Pariah', 'pariah', 1420000, 'sports'),
	('Patriot', 'patriot', 55000, 'suvs'),
	('PCJ-600', 'pcj', 6200, 'motorcycles'),
	('Penumbra', 'penumbra', 28000, 'sports'),
	('Pfister', 'pfister811', 85000, 'super'),
	('Phoenix', 'phoenix', 12500, 'muscle'),
	('Picador', 'picador', 18000, 'muscle'),
	('Pigalle', 'pigalle', 20000, 'sportsclassics'),
	('Prairie', 'prairie', 12000, 'compacts'),
	('Premier', 'premier', 8000, 'sedans'),
	('Primo Custom', 'primo2', 14000, 'sedans'),
	('X80 Proto', 'prototipo', 2500000, 'super'),
	('Radius', 'radi', 29000, 'suvs'),
	('raiden', 'raiden', 1375000, 'sports'),
	('Rapid GT', 'rapidgt', 35000, 'sports'),
	('Rapid GT Convertible', 'rapidgt2', 45000, 'sports'),
	('Rapid GT3', 'rapidgt3', 885000, 'sportsclassics'),
	('Reaper', 'reaper', 150000, 'super'),
	('Rebel', 'rebel2', 35000, 'offroad'),
	('Regina', 'regina', 5000, 'sedans'),
	('Retinue', 'retinue', 615000, 'sportsclassics'),
	('Revolter', 'revolter', 1610000, 'sports'),
	('riata', 'riata', 380000, 'offroad'),
	('Rocoto', 'rocoto', 45000, 'suvs'),
	('Ruffian', 'ruffian', 6800, 'motorcycles'),
	('Ruiner 2', 'ruiner2', 5745600, 'muscle'),
	('Rumpo', 'rumpo', 15000, 'vans'),
	('Rumpo Trail', 'rumpo3', 19500, 'vans'),
	('Sabre Turbo', 'sabregt', 20000, 'muscle'),
	('Sabre GT', 'sabregt2', 25000, 'muscle'),
	('Sanchez', 'sanchez', 5300, 'motorcycles'),
	('Sanchez Sport', 'sanchez2', 5300, 'motorcycles'),
	('Sanctus', 'sanctus', 25000, 'motorcycles'),
	('Sandking', 'sandking', 55000, 'offroad'),
	('Savestra', 'savestra', 990000, 'sportsclassics'),
	('SC 1', 'sc1', 1603000, 'super'),
	('Schafter', 'schafter2', 25000, 'sedans'),
	('Schafter V12', 'schafter3', 50000, 'sports'),
	('Scorcher (velo)', 'scorcher', 280, 'motorcycles'),
	('Seminole', 'seminole', 25000, 'suvs'),
	('Sentinel', 'sentinel', 32000, 'coupes'),
	('Sentinel XS', 'sentinel2', 40000, 'coupes'),
	('Sentinel3', 'sentinel3', 650000, 'sports'),
	('Seven 70', 'seven70', 39500, 'sports'),
	('ETR1', 'sheava', 220000, 'super'),
	('Shotaro Concept', 'shotaro', 320000, 'motorcycles'),
	('Slam Van', 'slamvan3', 11500, 'muscle'),
	('Sovereign', 'sovereign', 22000, 'motorcycles'),
	('Stinger', 'stinger', 80000, 'sportsclassics'),
	('Stinger GT', 'stingergt', 75000, 'sportsclassics'),
	('Streiter', 'streiter', 500000, 'sports'),
	('Stretch', 'stretch', 90000, 'sedans'),
	('Stromberg', 'stromberg', 3185350, 'sports'),
	('Sultan', 'sultan', 15000, 'sports'),
	('Sultan RS', 'sultanrs', 65000, 'super'),
	('Super Diamond', 'superd', 130000, 'sedans'),
	('Surano', 'surano', 50000, 'sports'),
	('Surfer', 'surfer', 12000, 'vans'),
	('T20', 't20', 300000, 'super'),
	('Tailgater', 'tailgater', 30000, 'sedans'),
	('Tampa', 'tampa', 16000, 'muscle'),
	('Drift Tampa', 'tampa2', 80000, 'sports'),
	('Thrust', 'thrust', 24000, 'motorcycles'),
	('Tri bike (velo)', 'tribike3', 520, 'motorcycles'),
	('Trophy Truck', 'trophytruck', 60000, 'offroad'),
	('Trophy Truck Limited', 'trophytruck2', 80000, 'offroad'),
	('Tropos', 'tropos', 40000, 'sports'),
	('Turismo R', 'turismor', 350000, 'super'),
	('Tyrus', 'tyrus', 600000, 'super'),
	('Vacca', 'vacca', 120000, 'super'),
	('Vader', 'vader', 7200, 'motorcycles'),
	('Verlierer', 'verlierer2', 70000, 'sports'),
	('Vigero', 'vigero', 12500, 'muscle'),
	('Virgo', 'virgo', 14000, 'muscle'),
	('Viseris', 'viseris', 875000, 'sportsclassics'),
	('Visione', 'visione', 2250000, 'super'),
	('Voltic', 'voltic', 90000, 'super'),
	('Voltic 2', 'voltic2', 3830400, 'super'),
	('Voodoo', 'voodoo', 7200, 'muscle'),
	('Vortex', 'vortex', 9800, 'motorcycles'),
	('Warrener', 'warrener', 4000, 'sedans'),
	('Washington', 'washington', 9000, 'sedans'),
	('Windsor', 'windsor', 95000, 'coupes'),
	('Windsor Drop', 'windsor2', 125000, 'coupes'),
	('Woflsbane', 'wolfsbane', 9000, 'motorcycles'),
	('XLS', 'xls', 32000, 'suvs'),
	('Yosemite', 'yosemite', 485000, 'muscle'),
	('Youga', 'youga', 10800, 'vans'),
	('Youga Luxuary', 'youga2', 14500, 'vans'),
	('Z190', 'z190', 900000, 'sportsclassics'),
	('Zentorno', 'zentorno', 1500000, 'super'),
	('Zion', 'zion', 36000, 'coupes'),
	('Zion Cabrio', 'zion2', 45000, 'coupes'),
	('Zombie', 'zombiea', 9500, 'motorcycles'),
	('Zombie Luxuary', 'zombieb', 12000, 'motorcycles'),
	('Z-Type', 'ztype', 220000, 'sportsclassics');

CREATE TABLE IF NOT EXISTS `vehicles_for_sale` (
  `id` int NOT NULL AUTO_INCREMENT,
  `seller` varchar(50) NOT NULL,
  `vehicleProps` longtext NOT NULL,
  `price` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `vehicle_categories` (
  `name` varchar(60) NOT NULL,
  `label` varchar(60) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `vehicle_categories` (`name`, `label`) VALUES
	('compacts', 'Compacts'),
	('coupes', 'CoupÃƒÂƒÃ†Â’ÃƒÂ†Ã¢Â€Â™ÃƒÂƒÃ¢Â€ÂšÃƒÂ‚Ã‚Â©s'),
	('motorcycles', 'Motos'),
	('muscle', 'Muscle'),
	('offroad', 'Off Road'),
	('sedans', 'Sedans'),
	('sports', 'Sports'),
	('sportsclassics', 'Sports Classics'),
	('super', 'Super'),
	('suvs', 'SUVs'),
	('vans', 'Vans');

CREATE TABLE IF NOT EXISTS `vehicle_sold` (
  `client` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `plate` varchar(50) NOT NULL,
  `soldby` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_furnishings` (
  `motelId` bigint NOT NULL DEFAULT '0',
  `furnishingData` longtext,
  `ownedFurnishingData` longtext,
  PRIMARY KEY (`motelId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_keys` (
  `uuid` bigint NOT NULL DEFAULT '0',
  `owner` varchar(50) NOT NULL,
  `keyData` longtext NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_motels` (
  `userIdentifier` varchar(50) NOT NULL,
  `motelData` longtext NOT NULL,
  `motelCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_storages` (
  `storageId` varchar(255) NOT NULL,
  `storageData` longtext NOT NULL,
  PRIMARY KEY (`storageId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
