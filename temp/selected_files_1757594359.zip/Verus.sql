/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `Verus` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `Verus`;

CREATE TABLE IF NOT EXISTS `addon_account` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `shared` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

REPLACE INTO `addon_account` (`id`, `name`, `label`, `shared`) VALUES
	(2, 'society_cardealer', 'Car Dealer', 1),
	(8, 'society_police', 'Police', 1),
	(12, 'society_nightclub', 'Nattklubben', 1),
	(13, 'society_mecano', 'Mechanic', 1),
	(14, 'society_ambulance', 'Ambulance', 1),
	(15, 'society_taxi', 'Taxi', 1),
	(28, 'society_realestateagent', 'Agent immobilier', 1),
	(45, 'society_customs', 'Benji Customs', 1),
	(46, 'society_forsakring', 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶rsÃ?Æ?Ã?â??Ã?â??Ã?Â¤kringsbolaget', 1),
	(47, 'society_pizza', 'Grove Pizzeria', 1),
	(48, 'society_families', 'Families', 1),
	(49, 'society_ballas', 'Ballas', 1),
	(50, 'society_lostmc', 'Lost MC', 1),
	(51, 'society_gotur', 'GÃ?Æ?Ã?â??Ã?â??Ã?Â¶tÃ?Æ?Ã?â??Ã?â??Ã?Â¼r', 1),
	(52, 'society_qpark', 'Qpark', 1),
	(54, 'society_mechanic', 'Vitality Repairs', 1),
	(55, 'society_porodcia', 'Porodcia Tuning & Styling', 1),
	(57, 'society_motorcycle', 'Northern Motorcycle', 1),
	(58, 'society_ballas', 'Ballas', 1),
	(59, 'society_dp', 'dp', 1),
	(60, 'society_kartellen', 'kartellen', 1),
	(61, 'society_lostmc', 'Lostmc', 1),
	(62, 'society_whyos', 'Whyos', 1);

CREATE TABLE IF NOT EXISTS `addon_account_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) DEFAULT NULL,
  `money` double NOT NULL,
  `owner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

REPLACE INTO `addon_account_data` (`id`, `account_name`, `money`, `owner`) VALUES
	(1, 'society_cardealer', 0, NULL),
	(2, 'society_police', 0, NULL),
	(3, 'society_mecano', 0, NULL),
	(4, 'society_ambulance', 0, NULL),
	(5, 'society_taxi', 0, NULL),
	(6, 'society_realestateagent', 0, NULL),
	(7, 'society_customs', 0, NULL),
	(8, 'society_forsakring', 0, NULL),
	(9, 'society_nightclub', 0, NULL),
	(10, 'society_pizza', 0, NULL),
	(11, 'society_families', 0, NULL),
	(12, 'society_ballas', 0, NULL),
	(13, 'society_lostmc', 0, NULL),
	(14, 'society_gotur', 0, NULL),
	(15, 'society_qpark', 0, NULL),
	(16, 'society_mechanic', 0, NULL),
	(17, 'society_porodcia', 0, NULL),
	(18, 'society_motorcycle', 0, NULL);

CREATE TABLE IF NOT EXISTS `blackmarket_accounts` (
  `username` longtext,
  `password` varchar(50) DEFAULT NULL,
  KEY `password` (`password`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `blackmarket_accounts` (`username`, `password`) VALUES
	('UiW41', 'gjNMNwEXN5');

CREATE TABLE IF NOT EXISTS `blackmarket_products` (
  `_` int NOT NULL AUTO_INCREMENT,
  `label` longtext NOT NULL,
  `price` int NOT NULL DEFAULT '0',
  `image` longtext NOT NULL,
  `seller` varchar(50) NOT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `identifier` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`_`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `cardealer_vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vehicle` varchar(255) NOT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters` (
  `id` varchar(50) NOT NULL DEFAULT '1337',
  `identifier` varchar(50) NOT NULL DEFAULT 'steam:undefined',
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `dateofbirth` varchar(20) NOT NULL DEFAULT '0000-00-00',
  `lastdigits` int NOT NULL DEFAULT '0',
  `phonenumber` char(50) NOT NULL DEFAULT '0',
  `cash` bigint NOT NULL DEFAULT '0',
  `bank` bigint NOT NULL DEFAULT '0',
  `banknumber` varchar(255) NOT NULL,
  `bankpassword` varchar(255) NOT NULL DEFAULT '',
  `dirty` bigint NOT NULL DEFAULT '0',
  `inventory` longtext NOT NULL,
  `health` int NOT NULL DEFAULT '100',
  `armor` int NOT NULL DEFAULT '0',
  `job` varchar(50) NOT NULL DEFAULT 'unemployed',
  `job_grade` varchar(50) NOT NULL DEFAULT '0',
  `status` longtext NOT NULL,
  `appearance` longtext NOT NULL,
  `position` longtext NOT NULL,
  `tattoos` longtext NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) NOT NULL DEFAULT 'current_timestamp()',
  `lastUpdated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `efterlyst` tinyint DEFAULT '0',
  `animations` longtext,
  `crafting_level` int NOT NULL,
  `gang` varchar(50) NOT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `height` varchar(50) DEFAULT NULL,
  `jail` int NOT NULL DEFAULT '0',
  `crafting_xp` int NOT NULL DEFAULT '0',
  KEY `identifier` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `characters` (`id`, `identifier`, `firstname`, `lastname`, `dateofbirth`, `lastdigits`, `phonenumber`, `cash`, `bank`, `banknumber`, `bankpassword`, `dirty`, `inventory`, `health`, `armor`, `job`, `job_grade`, `status`, `appearance`, `position`, `tattoos`, `created`, `image`, `lastUpdated`, `efterlyst`, `animations`, `crafting_level`, `gang`, `sex`, `height`, `jail`, `crafting_xp`) VALUES
	('2022-06-15-8572', 'steam:11000010588340a', 'LaGgIs', 'Dev', '2022-06-15', 8572, '0702423553', 0, 0, '829107666-1', '', 0, 'null', 200, 0, 'police', '5', '{"hunger":{"remove":500,"max":700000,"current":694000},"thirst":{"remove":500,"max":700000,"current":694000},"stress":{"remove":0.75,"max":400,"current":0},"drunk":{"remove":250,"max":450000,"current":0}}', '{"beard_3":0,"skin_2":0,"bproof_2":0,"chin_hole":0,"nose_bone_twist":0,"chain_2":0,"eyebrows_4":0,"nose_peak_height":0,"bracelets_2":0,"hair_color_1":0,"watches_2":0,"makeup_1":0,"neck_thickness":0,"mask_1":0,"nose_width":0,"bproof_1":0,"eyebrows_1":0,"helmet_1":-1,"sex":0,"nose_bone_height":0,"mask_2":0,"helmet_2":0,"jaw_bone_back_length":0,"skin":0,"eyebrows_3":0,"eyes_opening":0,"cheek_bone_width":0,"cheek_bone_height":0,"beard_4":0,"shoes_1":0,"jaw_bone_width":0,"lipstick_3":0,"age_1":0,"arms":0,"beard_2":0,"cheeks_width":0,"glasses_2":0,"chain_1":0,"hair_color_2":0,"tshirt_1":0,"hair_2":0,"lipstick_2":0,"makeup_2":0,"ears_2":0,"bags_1":0,"chin_bone_length":0,"lipstick_1":0,"hair_1":0,"arms_2":0,"nose_peak_length":0,"makeup_3":0,"decals_2":0,"pants_1":0,"pants_2":0,"decals_1":0,"shoes_2":0,"bracelets_1":-1,"makeup_4":0,"beard_1":0,"eyebrow_height":0,"lips_thickness":0,"chin_bone_lowering":0,"face":0,"skin_1":0,"torso_2":0,"ears_1":-1,"bags_2":0,"tshirt_2":0,"eyebrow_forward":0,"eyebrows_2":0,"chin_bone_width":0,"eye_color":0,"age_2":0,"watches_1":-1,"glasses_1":-1,"nose_peak_lowering":0,"torso_1":0,"lipstick_4":0}', '{"y":-996.9016723632813,"x":447.6084899902344,"z":35.06239700317383}', '', '2022-06-15 23:54:07', 'current_timestamp()', '2022-06-16 00:13:27', 0, '{}', 0, '', 'male', '158', 0, 0);

CREATE TABLE IF NOT EXISTS `characters_accounts` (
  `name` longtext,
  `money` bigint DEFAULT NULL,
  `characterId` varchar(255) DEFAULT NULL,
  `accountnumber` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_animations` (
  `cid` varchar(50) NOT NULL,
  `anims` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_contactperson` (
  `cid` varchar(50) NOT NULL,
  `timeContacted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_creditcards` (
  `cid` varchar(50) NOT NULL,
  `creditNumber` int NOT NULL DEFAULT '1337420911',
  `creditCode` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_furnishings` (
  `apartment` varchar(50) NOT NULL,
  `furnishings` longtext NOT NULL,
  PRIMARY KEY (`apartment`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_gangs` (
  `owner` varchar(50) NOT NULL DEFAULT '1337-12-12',
  `gangName` varchar(50) NOT NULL DEFAULT '',
  `ownedMarks` varchar(50) DEFAULT NULL,
  `money` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_garages` (
  `garageName` varchar(50) NOT NULL,
  `garageData` longtext NOT NULL,
  `garageCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`garageName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_invoices` (
  `invoiceId` int NOT NULL AUTO_INCREMENT,
  `cid` varchar(50) NOT NULL,
  `invoiceSender` varchar(50) NOT NULL,
  `invoiceType` varchar(50) NOT NULL,
  `invoiceAmount` int NOT NULL DEFAULT '0',
  `invoiceText` varchar(500) NOT NULL,
  `invoiceCreated` varchar(255) NOT NULL,
  `invoiceUNIX` longtext,
  PRIMARY KEY (`invoiceId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_jail` (
  `characterId` int NOT NULL,
  `jailTime` int NOT NULL DEFAULT '1',
  `jailReason` varchar(50) NOT NULL DEFAULT 'Fangslad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_keys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `keyName` varchar(50) NOT NULL,
  `keyUnit` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_licenses` (
  `characterId` varchar(50) NOT NULL,
  `licenseName` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_messages` (
  `messageHolder` varchar(50) NOT NULL,
  `messageSender` varchar(50) NOT NULL,
  `messageData` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_motels` (
  `characterId` varchar(50) NOT NULL,
  `motelNumber` int NOT NULL,
  `motelOwnerName` varchar(50) NOT NULL,
  PRIMARY KEY (`characterId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_properties` (
  `propertyName` varchar(50) NOT NULL,
  `propertyData` longtext NOT NULL,
  `propertyCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`propertyName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_shops` (
  `cidOwner` varchar(50) NOT NULL,
  `shopName` varchar(50) NOT NULL,
  `shopLabel` varchar(50) NOT NULL,
  `shopStock` longtext NOT NULL,
  `shopVault` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`shopName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_skills` (
  `cid` varchar(50) NOT NULL,
  `skills` longtext NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_storages` (
  `storageName` varchar(50) NOT NULL,
  `storageItems` longtext NOT NULL,
  PRIMARY KEY (`storageName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_stress` (
  `characterId` varchar(50) NOT NULL,
  `stressPercent` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`characterId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_vehicles` (
  `plate` varchar(12) NOT NULL,
  `vehicle` longtext NOT NULL,
  `owner` varchar(60) NOT NULL,
  `currentGarage` varchar(50) NOT NULL DEFAULT 'Torget',
  `impoundedTime` longtext,
  `insured` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'nxrp-forsakringsbolaget',
  `coating` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_vehicles_sale` (
  `characterId` varchar(50) NOT NULL,
  `vehicleProps` longtext NOT NULL,
  `price` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_vehicles_stolen` (
  `cid` varchar(50) NOT NULL,
  `stolenVehicles` longtext NOT NULL,
  `lastStolen` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_warehouses` (
  `warehouseName` varchar(50) NOT NULL,
  `warehouseOwner` varchar(50) NOT NULL,
  `warehouseStocks` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `character_jails` (
  `cid` varchar(50) DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `jailedtime` varchar(50) NOT NULL DEFAULT '24',
  `jailreason` varchar(50) DEFAULT NULL,
  `jailedwhen` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `jail` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `cooldowns` (
  `pk` int NOT NULL AUTO_INCREMENT,
  `id` text,
  `cooldown` bigint DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `identifier` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk`),
  KEY `identifier` (`identifier`),
  KEY `timestamp` (`timestamp`),
  KEY `cooldown` (`cooldown`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `datastore` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `shared` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

REPLACE INTO `datastore` (`id`, `name`, `label`, `shared`) VALUES
	(1, 'user_ears', 'Ears', 0),
	(2, 'user_glasses', 'Glasses', 0),
	(3, 'user_helmet', 'Helmet', 0),
	(4, 'user_mask', 'Mask', 0),
	(5, 'user_hat', 'Hat', 0),
	(6, 'property', 'Property', 0),
	(7, 'society_police', 'Police', 1),
	(8, 'user_watches', 'Watches', 0),
	(9, 'user_bags', 'Bags', 0),
	(10, 'society_forsakring', 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶rsÃ?Æ?Ã?â??Ã?â??Ã?Â¤kringsbolaget', 1),
	(11, 'society_ballas', 'Ballas', 1),
	(12, 'society_dp', 'dp', 1),
	(13, 'society_kartellen', 'kartellen', 1),
	(14, 'society_lostmc', 'Lostmc', 1),
	(15, 'society_whyos', 'Whyos', 1);

CREATE TABLE IF NOT EXISTS `datastore_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `owner` varchar(50) DEFAULT NULL,
  `data` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11989 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `devtoolbans` (
  `steam` varchar(25) NOT NULL,
  `rockstar` varchar(50) DEFAULT NULL,
  `live` varchar(21) DEFAULT NULL,
  `xbox` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `ip` varchar(25) DEFAULT NULL,
  `targetn` varchar(32) NOT NULL,
  `banid` int NOT NULL,
  PRIMARY KEY (`banid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `encro_chats` (
  `identifier` varchar(50) DEFAULT NULL,
  `channel` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `encro_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) DEFAULT NULL,
  `channel` varchar(50) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `messageID` int DEFAULT NULL,
  `posted` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `fine_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Missbruk av signalhorn', 750, 0),
	(2, 'P-bot', 750, 0),
	(3, 'Felaktig fordonsbelysning', 900, 0),
	(4, 'RÃ?Æ?Ã?â??Ã?â??Ã?Â¶dljus', 1250, 0),
	(5, 'Stopplikt', 1250, 0),
	(6, 'Trafikfarligt fordon', 1500, 0),
	(7, 'Olaglig omkÃ?Æ?Ã?â??Ã?â??Ã?Â¶rning', 1500, 0),
	(9, 'Olovlig kÃ?Æ?Ã?â??Ã?â??Ã?Â¶rning', 2000, 0),
	(10, 'Ej anvÃ?Æ?Ã?â??Ã?â??Ã?Â¤nt hjÃ?Æ?Ã?â??Ã?â??Ã?Â¤lm cykel/MC', 2000, 0),
	(11, 'Brott mot mobilfÃ?Æ?Ã?â??Ã?â??Ã?Â¶rbudet', 2200, 0),
	(12, 'VÃ?Æ?Ã?â??Ã?â??Ã?Â¥rdslÃ?Æ?Ã?â??Ã?â??Ã?Â¶shet i trafik', 3500, 0),
	(13, 'Smitning', 3500, 0),
	(14, 'Grov vÃ?Æ?Ã?â??Ã?â??Ã?Â¥rdslÃ?Æ?Ã?â??Ã?â??Ã?Â¶shet i trafik', 3500, 0),
	(15, 'Rattfylleri (0.2 - 1.0)', 2500, 0),
	(16, 'Rattfylleri (1.0 - <)', 5500, 0),
	(17, 'Drograttfylleri', 6500, 0),
	(18, 'HastighetsÃ?Æ?Ã?â??Ã?â??Ã?Â¶vertrÃ?Æ?Ã?â??Ã?â??Ã?Â¤delse (5-15km/h)', 1500, 0),
	(19, 'HastighetsÃ?Æ?Ã?â??Ã?â??Ã?Â¶vertrÃ?Æ?Ã?â??Ã?â??Ã?Â¤delse (15-25km/h)', 2500, 0),
	(20, 'HastighetsÃ?Æ?Ã?â??Ã?â??Ã?Â¶vertrÃ?Æ?Ã?â??Ã?â??Ã?Â¤delse (25-30km/h)', 3500, 0),
	(21, 'HastighetsÃ?Æ?Ã?â??Ã?â??Ã?Â¶vertrÃ?Æ?Ã?â??Ã?â??Ã?Â¤delse (30->km/h)', 4500, 0),
	(23, 'StÃ?Æ?Ã?â??Ã?â??Ã?Â¶rande av allmÃ?Æ?Ã?â??Ã?â??Ã?Â¤na ordningen', 1000, 1),
	(24, 'VÃ?Æ?Ã?â??Ã?â??Ã?Â¤gran av polismans order', 1250, 1),
	(25, 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶rargelsevÃ?Æ?Ã?â??Ã?â??Ã?Â¤ckande beteende', 1320, 1),
	(26, 'KrÃ?Æ?Ã?â??Ã?â??Ã?Â¤nkning', 1500, 1),
	(27, 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶regivande av allmÃ?Æ?Ã?â??Ã?â??Ã?Â¤n stÃ?Æ?Ã?â??Ã?â??Ã?Â¤llning', 2000, 1),
	(28, 'Brott mot griftefriden', 3000, 1),
	(29, 'Olaga intrÃ?Æ?Ã?â??Ã?â??Ã?Â¥ng', 3000, 1),
	(30, 'SkadegÃ?Æ?Ã?â??Ã?â??Ã?Â¶relse', 3500, 1),
	(31, 'Brott mot jaktlagen', 3500, 1),
	(32, 'Olaga hot', 3600, 2),
	(33, 'Hot mot tjÃ?Æ?Ã?â??Ã?â??Ã?Â¤nsteman', 4000, 2),
	(34, 'Narkotikabrott', 3750, 2),
	(35, 'Grovt narkotikabrott', 5500, 2),
	(36, 'Grovt olaga hot', 6500, 2),
	(37, 'Ofredande', 3500, 2),
	(38, 'Sexuellt ofredande', 4800, 2),
	(39, 'StÃ?Æ?Ã?â??Ã?â??Ã?Â¶ld', 4000, 2),
	(40, 'Grov stÃ?Æ?Ã?â??Ã?â??Ã?Â¶ld', 4500, 2),
	(42, 'Ã?Æ?Ã?â??Ã?Â¢Ã¢â??Â¬Ã¢â?¬Å?vergrepp i rÃ?Æ?Ã?â??Ã?â??Ã?Â¤ttssak', 4500, 2),
	(43, 'Olaga fÃ?Æ?Ã?â??Ã?â??Ã?Â¶rfÃ?Æ?Ã?â??Ã?â??Ã?Â¶ljelse', 4500, 2),
	(44, 'Brott mot knivlagen', 5000, 2),
	(45, 'BedrÃ?Æ?Ã?â??Ã?â??Ã?Â¤geri', 6500, 2),
	(46, 'Misshandel', 7500, 2),
	(47, 'Grov misshandel', 13500, 2),
	(48, 'VÃ?Æ?Ã?â??Ã?â??Ã?Â¥ld mot tjÃ?Æ?Ã?â??Ã?â??Ã?Â¤nsteman', 7500, 2),
	(49, 'Grovt bedrÃ?Æ?Ã?â??Ã?â??Ã?Â¤geri', 8700, 2),
	(50, 'Vapenbrott klass 1', 10000, 2),
	(51, 'Vapenbrott klass 2', 20000, 2),
	(52, 'Kidnappning', 10000, 3),
	(53, 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶rsÃ?Æ?Ã?â??Ã?â??Ã?Â¶k till rÃ?Æ?Ã?â??Ã?â??Ã?Â¥n', 12500, 3),
	(54, 'RÃ?Æ?Ã?â??Ã?â??Ã?Â¥n', 16500, 3),
	(55, 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶rsÃ?Æ?Ã?â??Ã?â??Ã?Â¶k till bankrÃ?Æ?Ã?â??Ã?â??Ã?Â¥n', 18000, 3),
	(56, 'BankrÃ?Æ?Ã?â??Ã?â??Ã?Â¥n', 25000, 3),
	(57, 'VÃ?Æ?Ã?â??Ã?â??Ã?Â¥llande till annans dÃ?Æ?Ã?â??Ã?â??Ã?Â¶d', 15000, 3),
	(58, 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶rsÃ?Æ?Ã?â??Ã?â??Ã?Â¶k till mord', 20000, 3),
	(59, 'Mord', 25000, 3);

CREATE TABLE IF NOT EXISTS `gangmarket` (
  `name` varchar(255) DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `lastrefill` bigint DEFAULT NULL,
  `price` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `gangmarket` (`name`, `stock`, `lastrefill`, `price`) VALUES
	('knife', 0, 0, 14000),
	('switchblade', 0, 0, 16000),
	('bat', 0, 0, 8000),
	('picklock', 0, 0, 6000),
	('suppressor', 0, 0, 3500),
	('pistolammo15x', 0, 0, 2000),
	('rifleammo20x', 0, 0, 2500),
	('weedseed', 25, 0, 400);

CREATE TABLE IF NOT EXISTS `hyrlager` (
  `id` int NOT NULL AUTO_INCREMENT,
  `keyIndex` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `inriktningar` (
  `characterId` varchar(50) DEFAULT NULL,
  `missions` longtext,
  `inriktning` varchar(50) NOT NULL DEFAULT 'NONE',
  `cooldown` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `inventories` (
  `name` varchar(255) DEFAULT NULL,
  `data` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `items` (
  `name` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `items` (`name`, `label`) VALUES
	('snspistolgrip', 'Makarov Grepp'),
	('guld', 'Guld'),
	('cigar', 'Cigarr'),
	('mp5', 'MP5'),
	('rusty_ring', 'Rostig ring'),
	('cokepack', 'Packeterat Kokain'),
	('rifleammo20x', '20x GevÃ?Æ?Ã?â??Ã?â??Ã?Â¤rsammunition'),
	('okrossatmeth', 'Okrossat Metamfetamin'),
	('lighter', 'TÃ?Æ?Ã?â??Ã?â??Ã?Â¤ndare'),
	('fireextinguisher', 'BrandslÃ?Æ?Ã?â??Ã?â??Ã?Â¤ckare'),
	('heavypistolgrip', 'Enterprise Grepp'),
	('clock2', 'Rolex Day-Date 40 ChampagnefÃ?Æ?Ã?â??Ã?â??Ã?Â¤rgad/18 karat gult'),
	('heavypistolmagasin', 'Enterprise Magasin'),
	('rifleammo10x', '10x GevÃ?Æ?Ã?â??Ã?â??Ã?Â¤rsammunition'),
	('snspistolkropp', 'Makarov Kropp'),
	('bigcamera', 'Sony HXR-MC2500J'),
	('musket', 'MuskÃ?Æ?Ã?â??Ã?â??Ã?Â¶t'),
	('shovel', 'Spade'),
	('scratchoff', 'Trisslott'),
	('knuckle', 'KnogjÃ?Æ?Ã?â??Ã?â??Ã?Â¤rn'),
	('chair', 'Kampstol'),
	('joint', 'Joint'),
	('broken_watch', 'Trasig klocka'),
	('kabab_p', 'Kabab Pizza'),
	('alvedon', 'Alvedon 500mg'),
	('noccomianmi', 'Nocco Miami 33cl'),
	('heavysniper', 'M107'),
	('snspistol', 'Makarov IJ70-18A'),
	('bread', 'Macka'),
	('bulletproofpolis', 'Polis SkottsÃ?Æ?Ã?â??Ã?â??Ã?Â¤kervÃ?Æ?Ã?â??Ã?â??Ã?Â¤st'),
	('assaultriflemagasin', 'AK47 Magasin'),
	('kungburk', 'Kung Ã?Æ?Ã?â??Ã?Â¢Ã¢â??Â¬Ã¢â?¬Å?l'),
	('sponge', 'TvÃ?Æ?Ã?â??Ã?â??Ã?Â¤tt svamp'),
	('microsmgkropp', 'Micro SMG Kropp'),
	('switchblade', 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¤llkniv'),
	('visivio', 'Vesuvio Pizza'),
	('meth', 'Metamfetamin'),
	('chokladboll', 'Chokladboll'),
	('pucko', 'Pucko'),
	('bowlball', 'Bowlingklot'),
	('bag', 'VÃ?Æ?Ã?â??Ã?â??Ã?Â¤ska'),
	('helmet', 'HjÃ?Æ?Ã?â??Ã?â??Ã?Â¤lm'),
	('key', 'Nyckel'),
	('stungun', 'Taser X26'),
	('creditcard', 'Kreditkort'),
	('bat', 'BasebollstrÃ?Æ?Ã?â??Ã?â??Ã?Â¤'),
	('heavypistolkropp', 'Enterprise Kropp'),
	('wrench', 'RÃ?Æ?Ã?â??Ã?â??Ã?Â¶rtÃ?Æ?Ã?â??Ã?â??Ã?Â¥ng'),
	('weedseed', 'GrÃ?Æ?Ã?â??Ã?â??Ã?Â¤s FrÃ?Æ?Ã?â??Ã?â??Ã?Â¶'),
	('knife', 'Bayonett M9 Combat Knife'),
	('assaultriflekropp', 'AK47 Kropp'),
	('hat', 'MÃ?Æ?Ã?â??Ã?â??Ã?Â¶ssa/Hatt'),
	('diamond', 'Diamant'),
	('water', 'RamlÃ?Æ?Ã?â??Ã?â??Ã?Â¶sa'),
	('kungflak', 'Kung Ã?Æ?Ã?â??Ã?Â¢Ã¢â??Â¬Ã¢â?¬Å?lflak'),
	('silverring', 'Silvering'),
	('zipties', 'Buntband'),
	('mask', 'Mask'),
	('heavypistol', 'Enterprise Widebody 1911'),
	('suppressor', 'LjuddÃ?Æ?Ã?â??Ã?â??Ã?Â¤mpare'),
	('billyspizza', 'Billys Panpizza'),
	('clock1', 'Emporio Armani klocka'),
	('pan', 'Vaskpanna'),
	('haktesklader', 'HÃ?Æ?Ã?â??Ã?â??Ã?Â¤ktesoutfit'),
	('panodil', 'Panodil 500mg'),
	('marabou5', 'Marabou Coco'),
	('hawaii_p', 'Hawaii Pizza'),
	('marlboro_red', 'Marlboro RÃ?Æ?Ã?â??Ã?â??Ã?Â¶d'),
	('trafikvastyb', 'Polis TrafikvÃ?Æ?Ã?â??Ã?â??Ã?Â¤st Yttre BefÃ?Æ?Ã?â??Ã?â??Ã?Â¤l'),
	('picklock', 'Dyrkset'),
	('weed1g', '1g Hasch'),
	('bibel', 'Bibel'),
	('paraply', 'Paraply'),
	('carkey', 'Bilnyckel'),
	('ocspray', 'Pepparsprej'),
	('crowbar', 'Kofot'),
	('bulletproofinsats', 'Insats SkottsÃ?Æ?Ã?â??Ã?â??Ã?Â¤kervÃ?Æ?Ã?â??Ã?â??Ã?Â¤st'),
	('daggerknife', 'Stickkniv'),
	('bowl', 'SkÃ?Æ?Ã?â??Ã?â??Ã?Â¥l'),
	('nightstick', 'B&T TRITON Advanced Tactical Expanderbatong 50 cm'),
	('bandage', 'Bandage'),
	('gulablend', 'Gula Blend'),
	('margerita', 'Margerrita Pizza'),
	('cokebrick', 'Kokain Block'),
	('dildo', 'Dildo'),
	('modTransmission', 'VÃ?Æ?Ã?â??Ã?â??Ã?Â¤xellÃ?Æ?Ã?â??Ã?â??Ã?Â¥da'),
	('jewels', 'Juveler'),
	('sandwich', 'Pressad macka'),
	('gymcard', 'Gymkort - Friskis & Svettis'),
	('idcard', 'Identitetskort'),
	('hammer', 'Hammare'),
	('foto', 'Bild'),
	('meth1g', 'Metamfetamin 1g'),
	('kladdkaka', 'Kladdkaka'),
	('pistolammo35x', '35x Pistolammunition'),
	('ipad', 'Ipad Pro'),
	('nocco3', 'Nocco Juicy Breeze 33cl'),
	('nocco2', 'Nocco Focus Ramonade 33cl'),
	('modBrakes', 'Bromsdel'),
	('radio', 'Sepura SC2020'),
	('giffel', 'Gifflar'),
	('clock3', 'Proshop Polar M600 Black'),
	('camera', 'Canon EOS R6'),
	('repairkit', 'Repareringskit'),
	('rifleammo15x', '15x GevÃ?Æ?Ã?â??Ã?â??Ã?Â¤rsammunition'),
	('microsmg', 'IMI Mini UZI'),
	('coffee', 'Kaffe'),
	('offphone', 'iPhone 13 Pro'),
	('rccar', 'Radiostyrd bil'),
	('blackmarket_login', 'Inlogg flugsvamp'),
	('m4a1', 'Colt M4A1'),
	('tuningcomputer', 'Rysk Dator'),
	('snspistolgrip', 'Makarov Grepp'),
	('ipren', 'Ipren 400mg'),
	('gote_snus', 'GÃ?Æ?Ã?â??Ã?â??Ã?Â¶teborgs RapÃ?Æ?Ã?â??Ã?â??Ã?Â©'),
	('diamondring', 'Diamantring'),
	('morot', 'Morot'),
	('phone', 'iPhone 13 Pro'),
	('dl', 'Dagens Lunch'),
	('redbull', 'Redbull'),
	('assaultriflegrip', 'AK47 Grepp'),
	('mer_apelsin_50cl', 'MER Apelsin'),
	('hatchet', 'Yxa'),
	('portfolj', 'PortfÃ?Æ?Ã?â??Ã?â??Ã?Â¶lj'),
	('pistolammo45x', '45x Pistolammunition'),
	('snspistolmagasin', 'Makarov Magasin'),
	('modEngine', 'Motordel'),
	('microsmgmagasin', 'Micro SMG Magasin'),
	('shotgun5x', '5x Shotgunammunition'),
	('pistolammo15x', '15x Pistolammunition'),
	('guldring', 'Guldring'),
	('flashlight', 'KLARUS XT21X 4000 LUMENTTT'),
	('ammonia', 'Ammoniak'),
	('sunglasses', 'SolglasÃ?Æ?Ã?â??Ã?â??Ã?Â¶gon'),
	('coke', 'Kokain'),
	('parachute', 'FallskÃ?Æ?Ã?â??Ã?â??Ã?Â¤rm'),
	('modTurbo', 'Turbodel'),
	('kebab', 'Kebab Rulle'),
	('microsmggrip', 'Micro SMG Grepp'),
	('necklacesilverfat', 'Tjockt Silverhalsband'),
	('systemkamera', 'Systemkamera'),
	('pepsi', 'Pepsi Max'),
	('petrolcan', 'Bensindunk'),
	('teddybear', 'TeddybjÃ?Æ?Ã?â??Ã?â??Ã?Â¶rn'),
	('aluminum', 'Aluminum'),
	('general_snus', 'General Orginal Portion'),
	('battleaxe', 'Sportsyxa'),
	('banana', 'Banan'),
	('rose', 'RÃ?Æ?Ã?â??Ã?â??Ã?Â¶d ros'),
	('binocular', 'Kikare'),
	('chips4', 'Estrella Dill Chips'),
	('weedleaves', 'GrÃ?Æ?Ã?â??Ã?â??Ã?Â¤s Blad'),
	('necklacesilver', 'Silverhalsband'),
	('coke1g', '1g Kokain'),
	('walkingstick', 'KÃ?Æ?Ã?â??Ã?â??Ã?Â¤pp'),
	('c4bombremote', 'C4 FjÃ?Æ?Ã?â??Ã?â??Ã?Â¤rrkontroll'),
	('c4bomb', 'C4'),
	('pumpshotgun', 'PumphagelgevÃ?Æ?Ã?â??Ã?â??Ã?Â¤r'),
	('pistol', 'Glock 17'),
	('hackkit', 'Hackningskit'),
	('part', 'Bildel'),
	('sig_sauer', 'Sig Sauer P226'),
	('rizla', 'Rizla'),
	('trafikvast', 'Polis TrafikvÃ?Æ?Ã?â??Ã?â??Ã?Â¤st'),
	('modSuspension', 'FjÃ?Æ?Ã?â??Ã?â??Ã?Â¤dring'),
	('hairtrimmer', 'HÃ?Æ?Ã?â??Ã?â??Ã?Â¥rtrimmer'),
	('musket15', '15x .69 kaliber'),
	('polisbricka', 'Polisbricka');

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `whitelisted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;

REPLACE INTO `jobs` (`id`, `name`, `label`, `whitelisted`) VALUES
	(1, 'unemployed', 'ArbetslÃ?Æ?Ã?â??Ã?â??Ã?Â¶s', 0),
	(2, 'ambulance', 'SjukvÃ?Æ?Ã?â??Ã?â??Ã?Â¥rdare', 1),
	(6, 'mecano', 'Mekonomen', 1),
	(7, 'police', 'Polis', 1),
	(8, 'cardealer', 'BilfÃ?Æ?Ã?â??Ã?â??Ã?Â¶rsÃ?Æ?Ã?â??Ã?â??Ã?Â¤ljare', 1),
	(12, 'taxi', 'Taxi', 1),
	(38, 'realestateagent', 'MÃ?Æ?Ã?â??Ã?â??Ã?Â¤klare', 1),
	(61, 'customs', 'Benji\'s Customs', 1),
	(65, 'nightclub', 'Nattklubben', 1),
	(68, 'pizza', 'Grove Pizzeria', 1),
	(72, 'qpark', 'Qpark', 1),
	(73, 'mechanic', 'Vitality Repairs', 1),
	(74, 'porodcia', 'Porodcia Tuning & Styling', 1),
	(75, 'motorcycle', 'Northern Motorcycle', 1),
	(79, 'ballas', 'Cosa Nostra', 1),
	(80, 'dp', 'dp', 1),
	(81, 'kartellen', 'kartellen', 1),
	(82, 'lostmc', 'Lostmc', 1),
	(83, 'whyos', 'whyos', 1);

CREATE TABLE IF NOT EXISTS `job_grades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_name` varchar(255) DEFAULT NULL,
  `grade` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `salary` int NOT NULL,
  `skin_male` longtext NOT NULL,
  `skin_female` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1060 DEFAULT CHARSET=latin1;

REPLACE INTO `job_grades` (`id`, `job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
	(1, 'unemployed', 0, 'rsa', 'ArbetslÃ?Æ?Ã?â??Ã?â??Ã?Â¶s', 150, '{}', '{}'),
	(2, 'mecano', 0, 'recrue', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 300, '{}', '{}'),
	(3, 'mecano', 1, 'novice', 'AnstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 350, '{}', '{}'),
	(4, 'mecano', 2, 'experimente', 'Erfaren', 500, '{}', '{}'),
	(5, 'mecano', 3, 'experimente', 'Gruppledare', 550, '{}', '{}'),
	(6, 'mecano', 4, 'boss', 'Personalchef', 650, '{}', '{}'),
	(7, 'mecano', 5, 'boss', 'Chef', 700, '{}', '{}'),
	(13, 'cardealer', 0, 'recruit', 'LÃ?Æ?Ã?â??Ã?â??Ã?Â¤rling', 160, '{}', '{}'),
	(14, 'cardealer', 2, 'novice', 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶rsÃ?Æ?Ã?â??Ã?â??Ã?Â¤ljare', 350, '{}', '{}'),
	(15, 'cardealer', 3, 'experienced', 'Manager', 500, '{}', '{}'),
	(16, 'cardealer', 4, 'boss', 'VD', 740, '{}', '{}'),
	(17, 'cardealer', 1, 'recruit', 'HallvÃ?Æ?Ã?â??Ã?â??Ã?Â¤rd', 190, '{}', '{}'),
	(20, 'taxi', 0, 'recrue', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 90, '{}', '{}'),
	(21, 'taxi', 1, 'novice', 'FÃ?Æ?Ã?â??Ã?â??Ã?Â¶rare', 120, '{}', '{}'),
	(22, 'taxi', 2, 'experimente', 'Uber', 130, '{}', '{}'),
	(23, 'taxi', 3, 'uber', 'Personalchef', 200, '{}', '{}'),
	(24, 'taxi', 4, 'boss', 'VD', 300, '{}', '{}'),
	(29, 'realestateagent', 0, 'recruit', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 100, '{}', '{}'),
	(30, 'realestateagent', 1, 'seller', 'SÃ?Æ?Ã?â??Ã?â??Ã?Â¤ljare', 160, '{}', '{}'),
	(31, 'realestateagent', 2, 'boss', 'Manager', 200, '{}', '{}'),
	(32, 'realestateagent', 3, 'boss', 'VD', 250, '{}', '{}'),
	(35, 'customs', 0, 'recruit', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 200, '{}', '{}'),
	(36, 'customs', 1, 'worker', 'Arbetare', 250, '{}', '{}'),
	(37, 'customs', 2, 'chef', 'Erfaren Arbetare', 400, '{}', '{}'),
	(38, 'customs', 4, 'boss', 'VD', 600, '{}', '{}'),
	(39, 'customs', 3, 'boss', 'Personalchef', 750, '{}', '{}'),
	(42, 'nightclub', 0, 'recrue', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 170, '{}', '{}'),
	(43, 'nightclub', 1, 'recrue2', 'AnstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 250, '{}', '{}'),
	(44, 'nightclub', 2, 'recrue3', 'Personal Chef', 400, '{}', '{}'),
	(45, 'nightclub', 3, 'boss', 'Manager', 600, '{}', '{}'),
	(48, 'pizza', 2, 'boss', 'Chef', 400, '{}', '{}'),
	(49, 'pizza', 1, 'novice', 'AnstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 230, '{}', '{}'),
	(52, 'ambulance', 0, 'recruit', 'Praktikan', 400, '{}', '{}'),
	(53, 'ambulance', 1, 'caretaker', 'VÃ?Æ?Ã?â??Ã?â??Ã?Â¥rdare', 600, '{}', '{}'),
	(54, 'ambulance', 2, 'assistantnurse', 'UnderskÃ?Æ?Ã?â??Ã?â??Ã?Â¶terska', 750, '{}', '{}'),
	(55, 'ambulance', 3, 'nurse', 'SjukskÃ?Æ?Ã?â??Ã?â??Ã?Â¶terska', 780, '{}', '{}'),
	(56, 'ambulance', 4, 'psychologist', 'Psykolog', 800, '{}', '{}'),
	(57, 'ambulance', 5, 'doctor', 'LÃ?Æ?Ã?â??Ã?â??Ã?Â¤kare', 900, '{}', '{}'),
	(58, 'ambulance', 6, 'overlakare', 'Ã?Æ?Ã?â??Ã?Â¢Ã¢â??Â¬Ã¢â?¬Å?verlÃ?Æ?Ã?â??Ã?â??Ã?Â¤kare', 950, '{}', '{}'),
	(59, 'ambulance', 7, 'boss', 'BitrÃ?Æ?Ã?â??Ã?â??Ã?Â¤dande Chef', 1050, '{}', '{}'),
	(60, 'ambulance', 8, 'boss', 'Chef', 1150, '{}', '{}'),
	(62, 'police', 0, 'officer', 'Assistent', 200, '{}', '{}'),
	(63, 'police', 1, 'sergeant', 'Kommisarie', 250, '{}', '{}'),
	(64, 'police', 2, 'lieutenant', 'BefÃ?Æ?Ã?â??Ã?â??Ã?Â¤l', 275, '{}', '{}'),
	(65, 'police', 3, 'lieutenant', 'BefÃ?Æ?Ã?â??Ã?â??Ã?Â¤l', 500, '{}', '{}'),
	(66, 'police', 4, 'lieutenant', 'Yttre-BefÃ?Æ?Ã?â??Ã?â??Ã?Â¤l', 500, '{}', '{}'),
	(68, 'police', 5, 'lieutenant', 'Grupp-BefÃ?Æ?Ã?â??Ã?â??Ã?Â¤l', 500, '{}', '{}'),
	(69, 'police', 6, 'lieutenant', 'BefÃ?Æ?Ã?â??Ã?â??Ã?Â¤l Havare', 500, '{}', '{}'),
	(72, 'police', 7, 'boss', 'BitrÃ?Æ?Ã?â??Ã?â??Ã?Â¤dande-SÃ?Æ?Ã?â??Ã?â??Ã?Â¤kerhetspolischef', 500, '{}', '{}'),
	(74, 'police', 8, 'boss', 'SÃ?Æ?Ã?â??Ã?â??Ã?Â¤kerhetspolischef', 650, '{}', '{}'),
	(75, 'police', 9, 'boss', 'BitrÃ?Æ?Ã?â??Ã?â??Ã?Â¤dande Rikspolis Chef', 650, '{}', '{}'),
	(76, 'police', 10, 'boss', 'Rikspolis Chef', 750, '{}', '{}'),
	(333, 'porodcia', 0, 'recruit', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 200, '{}', '{}'),
	(334, 'porodcia', 1, 'worker', 'Arbetare', 250, '{}', '{}'),
	(335, 'porodcia', 2, 'chef', 'Erfaren Arbetare', 400, '{}', '{}'),
	(336, 'porodcia', 3, 'boss', 'Personal Chef', 600, '{}', '{}'),
	(337, 'porodcia', 4, 'boss', 'Chef', 750, '{}', '{}'),
	(433, 'mechanic', 0, 'tryrecruit', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 70, '{}', '{}'),
	(434, 'mechanic', 1, 'recriut', 'AnstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 200, '{}', '{}'),
	(435, 'mechanic', 2, 'verkstadchef', 'Verkstadschef', 450, '{}', '{}'),
	(436, 'mechanic', 3, 'boss', 'Arbetsledare', 670, '{}', '{}'),
	(437, 'mechanic', 4, 'boss', 'Chef', 700, '{}', '{}'),
	(1009, 'qpark', 0, 'recrue', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 300, '{}', '{}'),
	(1010, 'qpark', 1, 'novice', 'AnstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 400, '{}', '{}'),
	(1011, 'qpark', 2, 'experimente', 'Erfaren', 500, '{}', '{}'),
	(1012, 'qpark', 3, 'boss', 'Personalchef', 600, '{}', '{}'),
	(1013, 'qpark', 4, 'boss', 'Chef', 650, '{}', '{}'),
	(1026, 'motorcycle', 0, 'slav', 'ProvanstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 200, '{}', '{}'),
	(1027, 'motorcycle', 1, 'slav2', 'AnstÃ?Æ?Ã?â??Ã?â??Ã?Â¤lld', 350, '{}', '{}'),
	(1028, 'motorcycle', 2, 'boss', 'Personal Chef', 550, '{}', '{}'),
	(1029, 'motorcycle', 3, 'boss', 'Chef', 750, '{}', '{}'),
	(1030, 'ballas', 0, 'soldato', 'Springpojke', 0, '{}', '{}'),
	(1031, 'ballas', 2, 'mafioso', 'Medlem', 0, '{}', '{}'),
	(1032, 'ballas', 3, 'capo', 'Trusted', 0, '{}', '{}'),
	(1033, 'ballas', 4, 'assassin', 'Hitman', 0, '{}', '{}'),
	(1034, 'ballas', 5, 'consigliere', 'Vice-Ledare', 0, '{}', '{}'),
	(1035, 'ballas', 6, 'boss', 'Ledare', 0, '{}', '{}'),
	(1036, 'dp', 0, 'soldato', 'Springpojke', 0, '{}', '{}'),
	(1037, 'dp', 2, 'mafioso', 'Medlem', 0, '{}', '{}'),
	(1038, 'dp', 3, 'capo', 'Trusted', 0, '{}', '{}'),
	(1039, 'dp', 4, 'assassin', 'Hitman', 0, '{}', '{}'),
	(1040, 'dp', 5, 'consigliere', 'Vice-Ledare', 0, '{}', '{}'),
	(1041, 'dp', 6, 'boss', 'Ledare', 0, '{}', '{}'),
	(1042, 'kartellen', 0, 'soldato', 'Springpojke', 0, '{}', '{}'),
	(1043, 'kartellen', 2, 'mafioso', 'Medlem', 0, '{}', '{}'),
	(1044, 'kartellen', 3, 'capo', 'Trusted', 0, '{}', '{}'),
	(1045, 'kartellen', 4, 'assassin', 'Hitman', 0, '{}', '{}'),
	(1046, 'kartellen', 5, 'consigliere', 'Vice-Ledare', 0, '{}', '{}'),
	(1047, 'kartellen', 6, 'boss', 'Ledare', 0, '{}', '{}'),
	(1048, 'lostmc', 0, 'soldato', 'Springpojke', 0, '{}', '{}'),
	(1049, 'lostmc', 2, 'mafioso', 'Medlem', 0, '{}', '{}'),
	(1050, 'lostmc', 3, 'capo', 'Trusted', 0, '{}', '{}'),
	(1051, 'lostmc', 4, 'assassin', 'Hitman', 0, '{}', '{}'),
	(1052, 'lostmc', 5, 'consigliere', 'Vice-Ledare', 0, '{}', '{}'),
	(1053, 'lostmc', 6, 'boss', 'Ledare', 0, '{}', '{}'),
	(1054, 'whyos', 0, 'soldato', 'Springpojke', 0, '{}', '{}'),
	(1055, 'whyos', 2, 'mafioso', 'Medlem', 0, '{}', '{}'),
	(1056, 'whyos', 3, 'capo', 'Trusted', 0, '{}', '{}'),
	(1057, 'whyos', 4, 'assassin', 'Hitman', 0, '{}', '{}'),
	(1058, 'whyos', 5, 'consigliere', 'Vice-Ledare', 0, '{}', '{}'),
	(1059, 'whyos', 6, 'boss', 'Ledare', 0, '{}', '{}');

CREATE TABLE IF NOT EXISTS `mark_cooldowns` (
  `owner` varchar(50) DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `place` varchar(50) DEFAULT NULL,
  `cooldown` bigint NOT NULL DEFAULT '86400'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `mc_categories` (
  `name` varchar(60) NOT NULL,
  `label` varchar(60) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `mc_categories` (`name`, `label`) VALUES
	('mc', 'Harley Davidson'),
	('sport', 'Sportmotorcyklar');

CREATE TABLE IF NOT EXISTS `mc_vehicles` (
  `name` varchar(60) NOT NULL,
  `model` varchar(60) NOT NULL,
  `price` int NOT NULL,
  `category` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`model`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `mc_vehicles` (`name`, `model`, `price`, `category`) VALUES
	('Cholo Lowbar', 'acknodlow', 40000, 'mc'),
	('Dyna Born', 'born', 42000, 'mc'),
	('Crucero', 'crucero', 58000, 'mc'),
	('Cvo', 'cvo', 50000, 'mc'),
	('Harley Davidson DarkFate', 'darkfate', 47000, 'mc'),
	('Harley Davidson darknight l l', 'darkfate2', 49000, 'mc'),
	('Dyna', 'dyna', 40000, 'mc'),
	('Dyna T bar', 'dyne', 40000, 'mc'),
	('Foxharleycustom', 'foxharley1', 35000, 'mc'),
	('Harley Roadbag', 'foxharley2', 48000, 'mc'),
	('Harley Fox', 'foxrk', 40000, 'mc'),
	('Hamster', 'hamster', 40000, 'mc'),
	('Harrier', 'harrier', 42400, 'mc'),
	('Hexer', 'hexer', 33000, 'mc'),
	('Street glide', 'hvrod', 50000, 'mc'),
	('Indian', 'indian', 45000, 'mc'),
	('Na25', 'na25', 42000, 'mc'),
	('Na252', 'na252', 43500, 'mc'),
	('Nazgul2', 'nazgul2', 40000, 'mc'),
	('Nightblade Custom', 'nightblade', 46000, 'mc'),
	('RoadGlide', 'roadglide', 52000, 'mc'),
	('Scout', 'scout', 40000, 'mc'),
	('Cholo', 'slave', 46000, 'mc'),
	('Softail', 'softail1', 49000, 'mc'),
	('Softail2', 'softail2', 52000, 'mc'),
	('Springer', 'springer', 50000, 'mc'),
	('Templar', 'templar', 45000, 'mc');

CREATE TABLE IF NOT EXISTS `motorcycle_vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vehicle` varchar(255) NOT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=801 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `owned_properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `rented` int NOT NULL,
  `owner` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_blocked` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `number` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_favorites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `time` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;


CREATE TABLE IF NOT EXISTS `phone_floppet` (
  `ownerNumber` varchar(255) DEFAULT NULL,
  `ownerPersonalnumber` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext,
  `price` int DEFAULT NULL,
  `imageData` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_images` (
  `personalnumber` varchar(255) DEFAULT NULL,
  `imageindex` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_latest` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `incoming` tinyint(1) NOT NULL DEFAULT '1',
  `missed` tinyint(1) NOT NULL DEFAULT '0',
  `time` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `phone_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `shootingrange_scoreboard` (
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `score` varchar(255) DEFAULT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `characterID` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `storageunits` (
  `storageUnit` int NOT NULL,
  `storageItems` longtext NOT NULL,
  `storageOwner` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `twitter_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL,
  `at` varchar(50) DEFAULT NULL,
  `message` varchar(250) NOT NULL,
  `img` varchar(50) NOT NULL,
  `time` bigint NOT NULL,
  `verified` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `twitter_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `img` varchar(50) DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `time` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;


CREATE TABLE IF NOT EXISTS `users` (
  `identifier` varchar(50) DEFAULT NULL,
  `license` varchar(50) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `permission_level` int DEFAULT NULL,
  `group` varchar(50) DEFAULT NULL,
  `carthief_delay` bigint NOT NULL,
  `lastCharName` varchar(50) DEFAULT NULL,
  `lastImage` varchar(255) DEFAULT NULL,
  `lastCharJob` varchar(50) DEFAULT NULL,
  `hudSettings` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

REPLACE INTO `users` (`identifier`, `license`, `name`, `permission_level`, `group`, `carthief_delay`, `lastCharName`, `lastImage`, `lastCharJob`, `hudSettings`) VALUES
	('steam:11000010588340a', 'license:b370a69a0454b348fc3f655f5fe1f550eec93aad', 'LaGgIs', 4000, 'superadmin', 0, NULL, NULL, NULL, NULL);

CREATE TABLE IF NOT EXISTS `user_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `characterId` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` char(50) NOT NULL,
  `favorite` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_quests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `characterId` varchar(50) NOT NULL,
  `quests` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_races` (
  `name` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  `race` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_whitelist` (
  `identifier` varchar(255) NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `uteknark` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `stage` int unsigned NOT NULL DEFAULT '1',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `soil` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stage` (`stage`,`time`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `model` varchar(60) NOT NULL,
  `price` int NOT NULL,
  `category` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2147483648 DEFAULT CHARSET=latin1;

REPLACE INTO `vehicles` (`id`, `name`, `model`, `price`, `category`) VALUES
	(1001, 'Blista', 'blista', 5350, 'compacts'),
	(1002, 'Brioso R/A', 'brioso', 5000, 'compacts'),
	(1003, 'Issi', 'issi2', 5500, 'compacts'),
	(1004, 'Prairie', 'prairie', 6000, 'compacts'),
	(1005, 'Kanjo', 'kanjo', 12000, 'compacts'),
	(1006, 'Asbo', 'asbo', 8000, 'compacts'),
	(1007, 'Issi Classic', 'issi3', 12000, 'compacts'),
	(1008, 'Weevil', 'weevil', 10000, 'compacts'),
	(1009, 'Cognoscenti Cabrio', 'cogcabrio', 18000, 'coupes'),
	(1010, 'Exemplar', 'exemplar', 16500, 'coupes'),
	(1011, 'F620', 'f620', 11500, 'coupes'),
	(1012, 'Felon GT', 'felon2', 26000, 'coupes'),
	(1013, 'Oracle XS', 'oracle2', 8000, 'coupes'),
	(1014, 'Sentinel', 'sentinel', 13000, 'coupes'),
	(1015, 'Windsor', 'windsor', 45000, 'coupes'),
	(1016, 'Windsor Drop', 'windsor2', 25000, 'coupes'),
	(1017, 'Zion', 'zion', 11000, 'coupes'),
	(1018, 'Zion Cabrio', 'zion2', 16500, 'coupes'),
	(1019, 'Sentinel XS', 'sentinel2', 14200, 'coupes'),
	(1020, 'Felon', 'felon', 13500, 'coupes'),
	(1021, 'Jackal', 'jackal', 16000, 'coupes'),
	(1022, 'Enduro', 'enduro', 9000, 'motorcycles'),
	(1023, 'Esskey', 'esskey', 12000, 'motorcycles'),
	(1024, 'Double T', 'double', 17000, 'motorcycles'),
	(1025, 'Akuma', 'AKUMA', 17000, 'motorcycles'),
	(1026, 'Avarus', 'avarus', 15600, 'motorcycles'),
	(1027, 'Bati 801', 'bati', 15000, 'motorcycles'),
	(1028, 'BF400', 'bf400', 17500, 'motorcycles'),
	(1029, 'Defiler', 'defiler', 15000, 'motorcycles'),
	(1030, 'Daemon', 'daemon', 10000, 'motorcycles'),
	(1031, 'Daemon High', 'daemon2', 13500, 'motorcycles'),
	(1032, 'Faggio', 'faggio', 5000, 'motorcycles'),
	(1033, 'Hakuchou', 'hakuchou', 90000, 'motorcycles'),
	(1034, 'Manchez', 'manchez', 15000, 'motorcycles'),
	(1035, 'Diablous2', 'diablous2', 50000, 'motorcycles'),
	(1036, 'Vortex', 'vortex', 35000, 'motorcycles'),
	(1037, 'Sanchez', 'sanchez', 13500, 'motorcycles'),
	(1038, 'Diablous', 'diablous', 30000, 'motorcycles'),
	(1039, 'Zombie Luxuary', 'zombieb', 15000, 'motorcycles'),
	(1040, 'Zombie', 'zombiea', 15500, 'motorcycles'),
	(1041, 'Woflsbane', 'wolfsbane', 13500, 'motorcycles'),
	(1042, 'Nemesis', 'nemesis', 35000, 'motorcycles'),
	(1043, 'Nightblade', 'nightblade', 20000, 'motorcycles'),
	(1044, 'PCJ-600', 'pcj', 32500, 'motorcycles'),
	(1045, 'Ruffian', 'ruffian', 15000, 'motorcycles'),
	(1046, 'Gauntlet Hellfire', 'gauntlet4', 45000, 'muscle'),
	(1047, 'Yosemite', 'yosemite', 25000, 'muscle'),
	(1048, 'Dominator GTX', 'dominator3', 45000, 'muscle'),
	(1049, 'Hustler', 'hustler', 35000, 'muscle'),
	(1050, 'Gauntlet5', 'gauntlet5', 40000, 'muscle'),
	(1051, 'Vamos', 'vamos', 40000, 'muscle'),
	(1052, 'Drift Yosemite', 'yosemite2', 25000, 'muscle'),
	(1053, 'Ellie', 'ellie', 34000, 'muscle'),
	(1054, 'Rat-Truck', 'ratloader2', 23000, 'muscle'),
	(1055, 'Hermes', 'hermes', 30000, 'muscle'),
	(1056, 'Gauntlet Classic', 'gauntlet3', 35000, 'muscle'),
	(1057, 'Coquette BlackFin', 'coquette3', 25000, 'muscle'),
	(1058, 'Voodoo', 'voodoo', 13000, 'muscle'),
	(1059, 'Vigero', 'vigero', 15000, 'muscle'),
	(1060, 'Virgo', 'virgo', 15000, 'muscle'),
	(1061, 'Tampa', 'tampa', 19500, 'muscle'),
	(1602, 'Slam Van', 'slamvan3', 19000, 'muscle'),
	(1603, 'Sabre GT', 'sabregt2', 23000, 'muscle'),
	(1604, 'Sabre Turbo', 'sabregt', 15000, 'muscle'),
	(1605, 'Picador', 'picador', 11000, 'muscle'),
	(1606, 'Dominator ASP', 'dominator7', 45000, 'muscle'),
	(1607, 'Nightshade', 'nightshade', 22500, 'muscle'),
	(1608, 'Faction XL', 'faction3', 22000, 'muscle'),
	(1609, 'Blade', 'blade', 11500, 'muscle'),
	(1610, 'Dominator', 'dominator', 16000, 'muscle'),
	(1611, 'Dukes', 'dukes', 14500, 'muscle'),
	(1612, 'Hotknife', 'hotknife', 20000, 'muscle'),
	(1613, 'Buccaneer', 'buccaneer', 14000, 'muscle'),
	(1614, 'Buccaneer Rider', 'buccaneer2', 21000, 'muscle'),
	(1615, 'Chino', 'chino', 14000, 'muscle'),
	(1616, 'Phoenix', 'phoenix', 17000, 'muscle'),
	(1617, 'Faction', 'faction', 12500, 'muscle'),
	(1618, 'Dominator GTT', 'dominator8', 40000, 'muscle'),
	(1619, 'Chino Custom', 'chino2', 19000, 'muscle'),
	(1620, 'Gauntlet', 'gauntlet', 15000, 'muscle'),
	(1621, 'Faction Rider', 'faction2', 20000, 'muscle'),
	(1622, 'Sandking', 'sandking', 20000, 'offroad'),
	(1623, 'Caracara 4x4', 'caracara2', 40000, 'offroad'),
	(1624, 'Kamacho', 'kamacho', 35000, 'offroad'),
	(1625, 'Sandking XL', 'sandking', 25000, 'offroad'),
	(1626, 'Rebel', 'rebel2', 6500, 'offroad'),
	(1627, 'Everon', 'everon', 28000, 'offroad'),
	(1628, 'Hellion', 'hellion', 35000, 'offroad'),
	(1629, 'Outlaw', 'outlaw', 35000, 'offroad'),
	(1630, 'Sandking SWB', 'sandking2', 27000, 'offroad'),
	(1631, 'Yosemite Rancher', 'yosemite3', 30000, 'offroad'),
	(1632, 'Blazer', 'blazer', 6000, 'offroad'),
	(1633, 'Yosemite Rancher', 'yosemite3', 38000, 'offroad'),
	(1634, 'Guardian', 'guardian', 26000, 'offroad'),
	(1635, 'Vagrant', 'vagrant', 24000, 'offroad'),
	(1636, 'Tailgater', 'tailgater', 17000, 'sedans'),
	(1637, 'Glendale', 'glendale', 8000, 'sedans'),
	(1638, 'Fugitive', 'fugitive', 12000, 'sedans'),
	(1639, 'Stanier', 'stanier', 12000, 'sedans'),
	(1640, 'Emperor', 'emperor', 12000, 'sedans'),
	(1641, 'Premier', 'premier', 8000, 'sedans'),
	(1642, 'Cognoscenti', 'cognoscenti', 18000, 'sedans'),
	(1643, 'Primo Custom', 'primo2', 20000, 'sedans'),
	(1644, 'Super Diamond', 'superd', 30000, 'sedans'),
	(1645, 'Emperor2', 'emperor2', 12000, 'sedans'),
	(1646, 'Warrener', 'warrener', 15500, 'sedans'),
	(1647, 'Intruder', 'intruder', 7500, 'sedans'),
	(1648, 'Sultan RS Classic', 'sultan2', 50000, 'sports'),
	(1649, 'Cypher', 'cypher', 55000, 'sports'),
	(1650, 'Jester RR', 'jester4', 75000, 'sports'),
	(1651, 'Schlagen', 'schlagen', 95000, 'sports'),
	(1652, 'Pariah', 'pariah', 60000, 'sports'),
	(1653, 'revolter', 'Revolter', 50000, 'sports'),
	(1654, 'Growler', 'growler', 70000, 'sports'),
	(1655, 'Vectre', 'vectre', 60000, 'sports'),
	(1656, 'Comet S2', 'comet6', 75000, 'sports'),
	(1657, 'Euros', 'euros', 55000, 'sports'),
	(1658, 'Calico', 'calico', 60000, 'sports'),
	(1659, 'Sugoi', 'sugoi', 52000, 'sports'),
	(1660, 'vstr', 'VSTR', 40000, 'sports'),
	(1661, 'Neon', 'neon', 135000, 'sports'),
	(1662, 'Tailgater2', 'tailgater2', 55000, 'sports'),
	(1663, 'ZR350', 'zr350', 60000, 'sports'),
	(1664, '9F', 'ninef', 60000, 'sports'),
	(1665, '8F Drafter', 'drafter', 65000, 'sports'),
	(1667, 'Imorgon', 'imorgon', 80000, 'sports'),
	(1668, 'Issi Sport', 'issi7', 52000, 'sports'),
	(1669, 'Jester Classic', 'jester3', 65000, 'sports'),
	(1670, 'Verlierer', 'verlierer2', 49500, 'sports'),
	(1671, 'Schafter V12', 'schafter3', 60000, 'sports'),
	(1672, 'Penumbra FF', 'penumbra2', 50000, 'sports'),
	(1673, 'Paragon', 'paragon', 74000, 'sports'),
	(1674, 'Comet', 'comet2', 45000, 'sports'),
	(1675, 'Komoda', 'komoda', 63000, 'sports'),
	(1676, 'Coquette D10', 'coquette4', 75000, 'sports'),
	(1678, 'Coquette', 'coquette', 52000, 'sports'),
	(1679, 'Comet SR', 'comet5', 62000, 'sports'),
	(1680, 'Banshee', 'banshee', 50000, 'sports'),
	(1681, 'Bestia GTS', 'bestiagts', 72000, 'sports'),
	(1682, ' Buffalo S', 'buffalo2', 42000, 'sports'),
	(1683, 'Carbonizzare', 'carbonizzare', 45000, 'sports'),
	(1684, 'Elegy Retro Custom', 'elegy', 57500, 'sports'),
	(1685, 'Comet Retro Custom', 'comet3', 56000, 'sports'),
	(1686, 'Comet Safari', 'comet4', 52000, 'sports'),
	(1687, 'Jaguar', 'jugular', 63000, 'sports'),
	(1688, 'Coquette Classic', 'coquette2', 63000, 'sportsclassics'),
	(1689, 'GT500', 'gt500', 49500, 'sportsclassics'),
	(1690, 'Dynasty', 'dynasty', 40000, 'sportsclassics'),
	(1691, 'Stafford', 'stafford', 55000, 'sportsclassics'),
	(1692, 'GB200', 'gb200', 65000, 'sportsclassics'),
	(1693, 'Infernus Classic', 'infernus2', 70000, 'sportsclassics'),
	(1694, 'JB700', 'jb700', 43000, 'sportsclassics'),
	(1695, 'Cheetah Classic', 'cheetah2', 69000, 'sportsclassics'),
	(1696, 'Casco', 'casco', 57000, 'sportsclassics'),
	(1697, 'Feltzer Classic', 'feltzer3', 50000, 'sportsclassics'),
	(1698, 'Savestra', 'savestra', 52000, 'sportsclassics'),
	(1699, 'Z190', 'z190', 55000, 'sportsclassics'),
	(1700, 'Fagaloa', 'fagaloa', 25000, 'sportsclassics'),
	(1701, 'Cheburek', 'cheburek', 35000, 'sportsclassics'),
	(1702, 'Retinue', 'retinue', 40000, 'sportsclassics'),
	(1703, 'Retinue Mk II', 'retinue2', 50000, 'sportsclassics'),
	(1704, 'Mamba', 'mamba', 50000, 'sportsclassics'),
	(1705, 'Turismo Classic', 'turismo2', 70500, 'sportsclassics'),
	(1706, 'Nebula Turbo', 'nebula', 60000, 'sportsclassics'),
	(1707, 'Zion Classic', 'zion3', 50000, 'sportsclassics'),
	(1708, 'Entity XF', 'entityxf', 80000, 'super'),
	(1709, 'Furia', 'furia', 140000, 'super'),
	(1710, 'Emerus', 'emerus', 130000, 'super'),
	(1711, 'Thrax', 'thrax', 200000, 'super'),
	(1712, 'Tyrant', 'tyrant', 150000, 'super'),
	(1713, 'Bullet', 'bullet', 65000, 'super'),
	(1714, 'Banshee 900R', 'banshee2', 67000, 'super'),
	(1715, 'Cheetah', 'cheetah', 70000, 'super'),
	(1716, 'FMJ', 'fmj', 115000, 'super'),
	(1717, 'X80 Proto', 'prototipo', 130000, 'super'),
	(1718, 'Krieger', 'krieger', 190000, 'super'),
	(1719, 'Reaper', 'reaper', 105000, 'super'),
	(1720, 'Sultan RS', 'sultanrs', 90000, 'super'),
	(1721, 'T20', 't20', 100000, 'super'),
	(1722, 'Infernus', 'infernus', 75000, 'super'),
	(1723, 'Osiris', 'osiris', 100000, 'super'),
	(1724, 'Pfister 811', 'pfister811', 80000, 'super'),
	(1725, 'Turismo R', 'turismor', 90000, 'super'),
	(1726, 'Vacca', 'vacca', 78000, 'super'),
	(1727, 'Adder', 'adder', 110000, 'super'),
	(1728, 'Itali GTB Custom', 'italigtb2', 100000, 'super'),
	(1729, 'Itali GTB', 'italigtb', 90000, 'super'),
	(1730, 'XA-21', 'xa21', 123000, 'super'),
	(1731, 'Visione', 'visione', 129000, 'super'),
	(1732, 'Nero Custom', 'nero2', 200000, 'super'),
	(1733, 'Nero', 'nero', 160000, 'super'),
	(1734, 'Entity XXR', 'entity2', 125000, 'super'),
	(1735, 'Tempesta', 'tempesta', 130000, 'super'),
	(1736, 'Itali RSX', 'italirsx', 180000, 'super'),
	(1737, 'Tigon', 'tigon', 87000, 'super'),
	(1738, 'Itali GTO', 'italigto', 160000, 'super'),
	(1739, 'Dubsta Luxury', 'dubsta2', 25000, 'suvs'),
	(1740, 'Gresley', 'gresley', 11000, 'suvs'),
	(1741, 'Fathom', 'fq2', 18000, 'suvs'),
	(1742, 'Landstalker XL', 'landstalker2', 30000, 'suvs'),
	(1743, 'Baller II', 'baller2', 22000, 'suvs'),
	(1744, 'Baller LE LWB', 'baller3', 30000, 'suvs'),
	(1745, 'Dubsta', 'dubsta', 14000, 'suvs'),
	(1746, 'Contender', 'contender', 26500, 'suvs'),
	(1747, 'Baller', 'baller', 17000, 'suvs'),
	(1748, 'Seminole Frontier', 'seminole2', 14000, 'suvs'),
	(1749, 'Mesa', 'mesa', 7000, 'suvs'),
	(1750, 'Mesa Trail', 'mesa3', 20000, 'suvs'),
	(1751, 'Patriot', 'patriot', 15000, 'suvs'),
	(1752, 'Radius', 'radi', 7500, 'suvs'),
	(1753, 'Rocoto', 'rocoto', 14000, 'suvs'),
	(1754, 'Seminole', 'seminole', 8000, 'suvs'),
	(1755, 'XLS', 'xls', 17000, 'suvs'),
	(1756, 'Novak', 'novak', 20000, 'suvs'),
	(1757, 'Landstalker', 'landstalker', 7000, 'suvs'),
	(1758, 'Rebla GTS', 'rebla', 25000, 'suvs'),
	(1759, 'Toros', 'toros', 80000, 'suvs'),
	(1760, 'Rumpo', 'rumpo', 7000, 'vans'),
	(1761, 'Youga Classic', 'youga2', 6750, 'vans'),
	(1762, 'Minivan Custom', 'minivan2', 17500, 'vans'),
	(1763, 'Youga', 'youga', 8000, 'vans'),
	(1764, 'Volkswagen Golf 8R', 'gcmgolf8r', 210000, 'volk'),
	(2000, 'Alfaromeo Giulia GTA', 'gtam21', 195000, 'alfa'),
	(2001, 'Audi RS7 C8', 'rs7c8', 300000, 'audi'),
	(2002, 'Audi RS3', 'rs318', 190000, 'audi'),
	(2003, 'Audi RS6', 'rs6rabt20', 320000, 'audi'),
	(2004, 'Audi R8', 'r820', 295000, 'audi'),
	(2005, 'Audi RSQ8', '21rsq8', 230000, 'audi'),
	(2006, 'BMW M5 2022', '22m5', 275000, 'bmw'),
	(2007, 'BMW M5 F90', 'bmwm5f90', 220000, 'bmw'),
	(2008, 'BMW M2C', 'm2c', 190000, 'bmw'),
	(2009, 'BMW M4 F82', 'f82', 200000, 'bmw'),
	(2010, 'Dodge Challanger', 'redeye', 265000, 'dodge'),
	(2011, 'Dodge Charger', 'sjdodge', 235000, 'dodge'),
	(2012, 'Ford Mustang', 'mustang19', 245000, 'ford'),
	(2013, 'Darkfate', 'darkfate', 35000, 'importmc'),
	(2014, 'Nazgul', 'nazgul2', 35000, 'importmc'),
	(2015, 'Darknight', 'darknight2', 35000, 'importmc'),
	(2016, 'Hamster', 'hamster', 35000, 'importmc'),
	(2017, 'Crucero', 'crucero', 35000, 'importmc'),
	(2018, 'Cvo', 'cvo', 35000, 'importmc'),
	(2019, 'Born', 'born', 35000, 'importmc'),
	(2020, 'Harrier', 'harrier', 35000, 'importmc'),
	(2021, 'Lamborghini Urus', 'urus', 230000, 'lambo'),
	(2022, 'Mercedes E63 AMG', 'e63amg', 235000, 'mercedes'),
	(2023, 'Brabus 850', 'brabus850', 240000, 'mercedes'),
	(2024, 'Nissan Skyline', 'skyline', 250000, 'nissan'),
	(2025, 'Nissan GTR', 'gtr', 265000, 'nissan'),
	(2026, 'Porsche 911 R', '911r', 275000, 'porsche'),
	(2027, 'Porsche Macan', '18macan', 220000, 'porsche'),
	(2028, 'Porsche Panamera', '22psh', 255000, 'porsche'),
	(3001, 'Civilbil - Drafter', 'poliscivil', 10000, 'polisfordon'),
	(3002, 'Radiobil - Volkswagen T5 (Yttre befÃ?Æ?Ã?â??Ã?â??Ã?Â¤l)', 'police10yb', 10000, 'polisfordon'),
	(3003, 'Riot - Ford FRI', 'riot', 10000, 'polisfordon'),
	(3004, 'Civilbuss - Mercedes', 'policet', 10000, 'polisfordon'),
	(3005, 'Radiobil - Mercedes Sprinter', 'policet20', 10000, 'polisfordon'),
	(3006, 'Motormyckel - BMW R1200', 'policeb', 10000, 'polisfordon'),
	(3007, 'Civilbil - Volvo V90', 'police20', 10000, 'polisfordon'),
	(3008, 'Civilbil - Volvo V90CC', 'police40', 10000, 'polisfordon'),
	(3009, 'Civilbil - Volkswagen Tiguan', 'police80', 10000, 'polisfordon'),
	(3010, 'Radiobil - Volvo V90CC (Yttre befÃ?Æ?Ã?â??Ã?â??Ã?Â¤l)', 'police60yb', 10000, 'polisfordon'),
	(3011, 'Radiobil - Volvo V90', 'police30', 10000, 'polisfordon'),
	(3012, 'Radiobil - Volvo XC60', 'police90', 10000, 'polisfordon'),
	(3013, 'Radiobil - Volvo XC70', 'police10', 10000, 'polisfordon'),
	(3014, 'Radiobil - Volkswagen Tiguan', 'police70', 10000, 'polisfordon'),
	(3015, 'Radiobil - Saab 95', '2009saab95', 10000, 'polisfordon'),
	(3016, 'Civilbil - RS6 2020', 'fbi', 10000, 'polisfordon'),
	(3017, 'Span - Ford', 'taurusbb', 10000, 'polisfordon'),
	(3018, 'Radiobil - Volvo V90CC', 'police60', 10000, 'polisfordon'),
	(3019, 'Civilbil - RS7', 'rs7polis', 10000, 'polisfordon');

CREATE TABLE IF NOT EXISTS `vehicle_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `label` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000001 DEFAULT CHARSET=latin1;

REPLACE INTO `vehicle_categories` (`id`, `name`, `label`) VALUES
	(1, 'compacts', 'Compacts'),
	(2, 'coupes', 'Coupes'),
	(3, 'sedans', 'Sedans'),
	(4, 'sports', 'Sportbilar'),
	(5, 'sportsclassics', 'Gammla Sportbilar'),
	(6, 'super', 'Superbilar'),
	(7, 'muscle', 'Muskelbilar'),
	(8, 'offroad', 'Off Road'),
	(9, 'suvs', 'SUVs'),
	(10, 'vans', 'Vans'),
	(12, 'motorcycles', 'Motorcyklar'),
	(16, 'ford', 'Ford'),
	(17, 'alfa', 'Alfaromeo'),
	(18, 'audi', 'Audi'),
	(19, 'bmw', 'BMW'),
	(20, 'dodge', 'Dodge'),
	(21, 'lambo', 'Lamborghini'),
	(22, 'mercedes', 'Mercedes'),
	(23, 'nissan', 'Nissan'),
	(24, 'porsche', 'Porsche'),
	(25, 'volk', 'Volkswagen'),
	(1000000, 'polisfordon', 'Polisfordon');

CREATE TABLE IF NOT EXISTS `wanted_users` (
  `WantedName` varchar(255) DEFAULT NULL,
  `WantedPersonalnumber` varchar(255) DEFAULT NULL,
  `WantedReason` longtext,
  `WantedCreator` varchar(255) DEFAULT NULL,
  `WantedDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `whitelist` (
  `name` varchar(255) DEFAULT NULL,
  `prio` tinyint NOT NULL DEFAULT '0',
  `wl` tinyint NOT NULL DEFAULT '0',
  `dc` varchar(255) NOT NULL,
  `created` varchar(255) DEFAULT NULL,
  `authCode` varchar(255) DEFAULT NULL,
  `history` longtext,
  `access_token` longtext,
  `rank` varchar(50) NOT NULL DEFAULT 'Spelare'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_evidence` (
  `evidenceId` varchar(250) NOT NULL,
  `evidenceOwner` varchar(50) NOT NULL,
  `itemData` longtext NOT NULL,
  `startedChecking` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_furnishings` (
  `motelId` bigint NOT NULL DEFAULT '0',
  `furnishingData` longtext,
  `ownedFurnishingData` longtext,
  PRIMARY KEY (`motelId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_journals` (
  `journalJob` varchar(50) NOT NULL DEFAULT 'police',
  `journalData` longtext NOT NULL,
  PRIMARY KEY (`journalJob`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_junkyard` (
  `junkPosition` int NOT NULL DEFAULT '1',
  `junkVehicle` longtext NOT NULL,
  `junkDeliverer` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_keys` (
  `uuid` bigint NOT NULL DEFAULT '0',
  `owner` varchar(255) NOT NULL,
  `keyData` longtext NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_motels` (
  `userIdentifier` varchar(50) NOT NULL,
  `motelData` longtext NOT NULL,
  `motelCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_police_lockers` (
  `lockerOwner` varchar(50) NOT NULL,
  `lockerDisplay` varchar(150) NOT NULL,
  `lockerCreator` varchar(50) NOT NULL,
  `lockerCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`lockerOwner`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_storages` (
  `storageId` varchar(50) NOT NULL DEFAULT '0',
  `storageData` longtext NOT NULL,
  PRIMARY KEY (`storageId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
