/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `Valize` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `Valize`;

CREATE TABLE IF NOT EXISTS `addon_account` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `shared` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=534534548 DEFAULT CHARSET=latin1;

REPLACE INTO `addon_account` (`id`, `name`, `label`, `shared`) VALUES
	(2, 'society_cardealer', 'Car Dealer', 1),
	(3, 'society_cardealer2', 'Mc dealer', 1),
	(8, 'society_police', 'Police', 1),
	(13, 'society_mecano', 'Mechanic', 1),
	(14, 'society_ambulance', 'Ambulance', 1),
	(15, 'society_taxi', 'Taxi', 1),
	(28, 'society_realestateagent', 'M?klaren', 1),
	(45, 'society_bennys', 'Bennys', 1),
	(46, 'society_nightclub', 'The Palace', 1),
	(48, 'society_raddningstjansten', 'R?ddningstj?nsten', 1),
	(50, 'society_trygghansa', 'Trygghansa', 1),
	(51, 'society_postnord', 'Postnord', 1),
	(52, 'society_nattklubb', 'Vanilla Unicorn', 1),
	(53, 'society_qpark', 'Qpark', 1),
	(54, 'society_mcdonalds', 'Mcdonalds', 1),
	(58, 'society_carluxery', 'Luxury Autos', 1),
	(60, 'society_bandidos', 'Bandidos', 1),
	(61, 'society_hells', 'Hells', 1),
	(62, 'society_ballas', 'Ballas', 1),
	(63, 'society_bloods', 'Bloods', 1),
	(64, 'society_crips', 'Crips', 1),
	(65, 'society_groovestreet', 'Groovestreet', 1),
	(66, 'society_grove', 'Grove', 1),
	(67, 'society_loszetas', 'Loszetas', 1),
	(68, 'society_shottaz', 'Shottaz', 1),
	(71, 'society_cartel', 'Cartel', 1),
	(73, 'society_latinkings', 'Latinkings', 1),
	(242, 'society_securitas', 'Securitas', 1),
	(555, 'society_19th', '19th Steet', 1),
	(3232, 'society_gsf', 'GSF', 1),
	(3434, 'society_hyenorna', 'Hyenorna', 1),
	(4242, 'society_soa', 'Sons Of Anarchy', 1),
	(64564, 'society_costanostra', 'Costanostra', 1),
	(64644, 'society_fallenangels', 'Fallen Angels', 1),
	(83535, 'society_boatdealer', 'B?tbolaget', 1),
	(83536, 'society_families', 'V?rbyn?tverket', 1),
	(83540, 'society_dodspatrullen', 'dodspatrullen', 1),
	(343434, 'society_vl13', 'Vl123', 1),
	(534534534, 'society_autoexperten', 'Autoexperten', 1),
	(534534535, 'society_salims', 'Salims Pizzeria', 1),
	(534534540, 'society_maisonette', 'Maisonette', 1),
	(534534542, 'society_biker', 'Biker', 1),
	(534534543, 'society_mafia', 'Mafia', 1),
	(534534545, 'society_gang2', 'gang2', 1),
	(534534546, 'society_crips', 'Crips', 1),
	(534534547, 'society_cartel', 'Cartel', 1);

CREATE TABLE IF NOT EXISTS `addon_account_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) DEFAULT NULL,
  `money` double NOT NULL,
  `owner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32424391 DEFAULT CHARSET=latin1;

REPLACE INTO `addon_account_data` (`id`, `account_name`, `money`, `owner`) VALUES
	(32424346, 'society_cardealer', 951103100, NULL),
	(32424347, 'society_cardealer2', 0, NULL),
	(32424348, 'society_police', 384900, NULL),
	(32424349, 'society_mecano', 52704, NULL),
	(32424350, 'society_ambulance', 5000, NULL),
	(32424351, 'society_taxi', 10, NULL),
	(32424352, 'society_realestateagent', 0, NULL),
	(32424353, 'society_bennys', 3902427, NULL),
	(32424354, 'society_nightclub', 100000, NULL),
	(32424355, 'society_raddningstjansten', 0, NULL),
	(32424356, 'society_trygghansa', 0, NULL),
	(32424357, 'society_postnord', 0, NULL),
	(32424358, 'society_nattklubb', 2, NULL),
	(32424359, 'society_qpark', 0, NULL),
	(32424360, 'society_mcdonalds', 0, NULL),
	(32424361, 'society_carluxery', 0, NULL),
	(32424362, 'society_bandidos', 0, NULL),
	(32424363, 'society_hells', 0, NULL),
	(32424364, 'society_ballas', 0, NULL),
	(32424365, 'society_bloods', 0, NULL),
	(32424366, 'society_crips', 0, NULL),
	(32424367, 'society_groovestreet', 0, NULL),
	(32424368, 'society_grove', 0, NULL),
	(32424369, 'society_loszetas', 0, NULL),
	(32424370, 'society_shottaz', 0, NULL),
	(32424371, 'society_cartel', 0, NULL),
	(32424372, 'society_maffia', 0, NULL),
	(32424373, 'society_latinkings', 0, NULL),
	(32424374, 'society_securitas', 0, NULL),
	(32424375, 'society_19th', 0, NULL),
	(32424376, 'society_gsf', 0, NULL),
	(32424377, 'society_hyenorna', 0, NULL),
	(32424378, 'society_soa', 0, NULL),
	(32424379, 'society_costanostra', 0, NULL),
	(32424380, 'society_fallenangels', 0, NULL),
	(32424381, 'society_boatdealer', 0, NULL),
	(32424382, 'society_families', 0, NULL),
	(32424383, 'society_dodspatrullen', 0, NULL),
	(32424384, 'society_vl13', 0, NULL),
	(32424385, 'society_autoexperten', 0, NULL),
	(32424386, 'society_salims', 0, NULL),
	(32424387, 'society_maisonette', 0, NULL),
	(32424388, 'society_biker', 0, NULL),
	(32424389, 'society_mafia', 0, NULL),
	(32424390, 'society_gang2', 0, NULL);

CREATE TABLE IF NOT EXISTS `addon_inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `shared` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

REPLACE INTO `addon_inventory` (`id`, `name`, `label`, `shared`) VALUES
	(1, 'society_biker', 'biker', 1),
	(3, 'society_mafia', 'Mafia', 1),
	(4, 'society_biker', 'Biker', 1),
	(5, 'society_gang2', 'gang2', 1),
	(6, 'society_crips', 'Crips', 1),
	(7, 'society_cartel', 'Cartel', 1);

CREATE TABLE IF NOT EXISTS `advanced_report` (
  `name` varchar(50) DEFAULT NULL,
  `args` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `baninfo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `license` varchar(50) DEFAULT NULL,
  `identifier` varchar(25) DEFAULT NULL,
  `liveid` varchar(21) DEFAULT NULL,
  `xblid` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `playerip` varchar(25) DEFAULT NULL,
  `playername` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3978 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `banlist` (
  `license` varchar(50) NOT NULL,
  `identifier` varchar(25) DEFAULT NULL,
  `liveid` varchar(21) DEFAULT NULL,
  `xblid` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `playerip` varchar(25) DEFAULT NULL,
  `targetplayername` varchar(32) DEFAULT NULL,
  `sourceplayername` varchar(32) DEFAULT NULL,
  `reason` varchar(255) NOT NULL,
  `timeat` varchar(50) NOT NULL,
  `expiration` varchar(50) NOT NULL,
  `permanent` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`license`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `banlisthistory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `license` varchar(50) DEFAULT NULL,
  `identifier` varchar(25) DEFAULT NULL,
  `liveid` varchar(21) DEFAULT NULL,
  `xblid` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `playerip` varchar(25) DEFAULT NULL,
  `targetplayername` varchar(32) DEFAULT NULL,
  `sourceplayername` varchar(32) DEFAULT NULL,
  `reason` varchar(255) NOT NULL,
  `timeat` int NOT NULL,
  `added` varchar(40) NOT NULL,
  `expiration` int NOT NULL,
  `permanent` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1490 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `bixbi_territories` (
  `name` varchar(50) NOT NULL,
  `gang` varchar(50) NOT NULL DEFAULT '',
  `itemstake` tinyint NOT NULL DEFAULT '5',
  `washtake` tinyint NOT NULL DEFAULT '5',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `boatdealer_boats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vehicle` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `state` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=547 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

REPLACE INTO `boatdealer_boats` (`id`, `vehicle`, `price`, `state`) VALUES
	(531, 'squalo', 200000, 0),
	(535, 'toro', 300000, 0),
	(540, 'marquis', 400000, 0),
	(543, 'dinghy', 200000, 0),
	(545, 'seashark', 100000, 0),
	(546, 'dinghy', 200000, 0);

CREATE TABLE IF NOT EXISTS `boats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `model` varchar(60) NOT NULL,
  `price` int NOT NULL,
  `category` varchar(60) DEFAULT NULL,
  `namn` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=781 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

REPLACE INTO `boats` (`id`, `name`, `model`, `price`, `category`, `namn`) VALUES
	(1, 'Vattenskoter', 'seashark', 100000, 'b?tar', NULL),
	(2, 'Speeder', 'speeder', 200000, 'b?tar', NULL),
	(3, 'Squalo', 'squalo', 200000, 'b?tar', NULL),
	(4, 'Fiskeb?t', 'dinghy', 200000, 'b?tar', NULL),
	(5, 'Suntrap', 'suntrap', 200000, 'b?tar', NULL),
	(6, 'Tr?b?t', 'toro', 300000, 'b?tar', NULL),
	(7, 'Segelb?t', 'marquis', 400000, 'b?tar', NULL),
	(8, 'Jetmax', 'jetmax', 200000, 'b?tar', NULL);

CREATE TABLE IF NOT EXISTS `boats_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `label` varchar(60) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

REPLACE INTO `boats_categories` (`id`, `name`, `label`) VALUES
	(1, 'b?tar', 'B?tar');

CREATE TABLE IF NOT EXISTS `boat_sold` (
  `client` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `plate` varchar(50) NOT NULL,
  `soldby` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`plate`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;


CREATE TABLE IF NOT EXISTS `bwh_bans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receiver` text NOT NULL,
  `sender` varchar(60) NOT NULL,
  `length` datetime DEFAULT NULL,
  `reason` text NOT NULL,
  `unbanned` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `bwh_identifiers` (
  `steam` varchar(60) NOT NULL,
  `license` varchar(60) NOT NULL,
  `ip` varchar(60) NOT NULL,
  `name` varchar(128) NOT NULL,
  `xbl` varchar(60) DEFAULT NULL,
  `live` varchar(60) DEFAULT NULL,
  `discord` varchar(60) DEFAULT NULL,
  `fivem` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`steam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `bwh_warnings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receiver` text NOT NULL,
  `sender` varchar(60) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `cardealer2_vehicles2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vehicle` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `state` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3009 DEFAULT CHARSET=latin1;

REPLACE INTO `cardealer2_vehicles2` (`id`, `vehicle`, `price`, `state`) VALUES
	(2999, '08rm250', 590000, 0),
	(3000, '08rm250', 590000, 0),
	(3001, '08rm250', 590000, 0),
	(3002, 'g63nt', 657868878, 0),
	(3003, 'nh2r', 1000000, 0),
	(3004, 'JB700', 230000, 0),
	(3005, 'g63nt', 657868878, 0),
	(3006, 'ksd', 830000, 0),
	(3008, 'g63nt', 657868878, 0);

CREATE TABLE IF NOT EXISTS `cardealer_vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vehicle` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `state` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2382 DEFAULT CHARSET=latin1;

REPLACE INTO `cardealer_vehicles` (`id`, `vehicle`, `price`, `state`) VALUES
	(2356, 'bugatti', 400000, 0),
	(2360, '940fk', 35000, 0),
	(2365, '19ramoffroad', 871000, 0),
	(2367, 'amarok', 400000, 0),
	(2369, '19ramoffroad', 871000, 0),
	(2370, 'skyline', 240000, 0),
	(2371, '940stv', 40000, 0),
	(2372, 'p1lm', 2500000, 0),
	(2374, 'x5e53', 871900, 0),
	(2375, 'x6m', 900000, 0),
	(2376, 'p1lm', 2500000, 0),
	(2377, '650s', 780000, 0),
	(2378, '720s', 800000, 0),
	(2379, 'toysupmk4', 779700, 0),
	(2380, 'ksd', 830000, 0),
	(2381, 'jesko2020', 3000000, 0);

CREATE TABLE IF NOT EXISTS `characters` (
  `id` varchar(50) NOT NULL DEFAULT '1337',
  `identifier` varchar(50) NOT NULL DEFAULT 'steam:undefined',
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `dateofbirth` varchar(20) NOT NULL DEFAULT '0000-00-00',
  `sex` varchar(20) NOT NULL DEFAULT '0000-00-00',
  `height` varchar(20) NOT NULL DEFAULT '0000-00-00',
  `lastdigits` int NOT NULL DEFAULT '0',
  `phone_number` char(50) DEFAULT NULL,
  `cash` bigint NOT NULL DEFAULT '0',
  `bank` bigint NOT NULL DEFAULT '0',
  `dirty` bigint NOT NULL DEFAULT '0',
  `inventory` longtext NOT NULL,
  `health` int NOT NULL DEFAULT '100',
  `armor` int NOT NULL DEFAULT '0',
  `job` varchar(50) NOT NULL DEFAULT 'unemployed',
  `job_grade` varchar(50) NOT NULL DEFAULT '0',
  `status` longtext NOT NULL,
  `appearance` longtext NOT NULL,
  `position` longtext NOT NULL,
  `tattoos` longtext NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastUpdated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `jail` int NOT NULL DEFAULT '0',
  `carthief_delay` bigint NOT NULL,
  `cid` char(50) DEFAULT NULL,
  `lop` char(50) DEFAULT NULL,
  `animations` longtext,
  `efterlyst` varchar(50) DEFAULT 'Nej',
  `image` varchar(50) NOT NULL DEFAULT 'NONE',
  `gang` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_animations` (
  `cid` varchar(50) NOT NULL,
  `anims` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_boats` (
  `plate` varchar(12) NOT NULL,
  `vehicle` longtext NOT NULL,
  `owner` varchar(60) NOT NULL,
  `currentGarage` varchar(50) NOT NULL DEFAULT 'A',
  `impoundedTime` longtext NOT NULL,
  `forsakrad` tinyint(1) NOT NULL DEFAULT '0',
  `tunerdata` longtext NOT NULL,
  PRIMARY KEY (`plate`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;


CREATE TABLE IF NOT EXISTS `characters_creditcards` (
  `cid` varchar(50) NOT NULL,
  `creditNumber` int NOT NULL DEFAULT '1337420911',
  `creditCode` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_furnishings` (
  `apartment` varchar(50) NOT NULL,
  `furnishings` longtext NOT NULL,
  PRIMARY KEY (`apartment`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_gangs` (
  `owner` varchar(50) NOT NULL DEFAULT '1337-12-12',
  `gangName` varchar(50) NOT NULL DEFAULT '',
  `ownedMarks` varchar(50) DEFAULT NULL,
  `money` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_invoices` (
  `invoiceId` int NOT NULL AUTO_INCREMENT,
  `cid` varchar(50) NOT NULL,
  `invoiceSender` varchar(50) NOT NULL,
  `invoiceType` varchar(50) NOT NULL,
  `invoiceAmount` int NOT NULL DEFAULT '0',
  `invoiceText` varchar(500) NOT NULL,
  `invoiceCreated` varchar(255) NOT NULL,
  PRIMARY KEY (`invoiceId`)
) ENGINE=InnoDB AUTO_INCREMENT=3173 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_jail` (
  `characterId` int NOT NULL,
  `jailTime` int NOT NULL DEFAULT '1',
  `jailReason` varchar(50) NOT NULL DEFAULT 'Fangslad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_keys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner` varchar(60) NOT NULL,
  `data` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4576 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_licenses` (
  `characterId` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `licenseName` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_messages` (
  `messageHolder` varchar(50) NOT NULL,
  `messageSender` varchar(50) NOT NULL,
  `messageData` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_motels` (
  `characterId` varchar(50) NOT NULL,
  `motelNumber` int NOT NULL,
  `motelOwnerName` varchar(50) NOT NULL,
  PRIMARY KEY (`characterId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_plants` (
  `plantId` int NOT NULL,
  `plantLevel` int NOT NULL DEFAULT '1',
  `plantWaterLeft` int NOT NULL DEFAULT '1',
  `plantTime` int NOT NULL DEFAULT '30',
  `plantCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `plantEdited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`plantId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_properties` (
  `propertyName` varchar(50) NOT NULL,
  `propertyData` longtext NOT NULL,
  `propertyCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`propertyName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_shops` (
  `cidOwner` varchar(50) NOT NULL,
  `shopName` varchar(50) NOT NULL,
  `shopLabel` varchar(50) NOT NULL,
  `shopStock` longtext NOT NULL,
  `shopVault` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`shopName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_skills` (
  `cid` varchar(50) NOT NULL,
  `skills` longtext NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_storages` (
  `storageName` varchar(50) NOT NULL,
  `storageItems` longtext NOT NULL,
  `locked` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`storageName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_vehicles` (
  `plate` varchar(12) NOT NULL,
  `vehicle` longtext NOT NULL,
  `owner` varchar(60) NOT NULL,
  `currentGarage` varchar(50) NOT NULL DEFAULT 'Garage',
  `impoundedTime` longtext NOT NULL,
  `forsakrad` tinyint(1) NOT NULL DEFAULT '0',
  `tunerdata` longtext NOT NULL,
  `carseller` int DEFAULT '0',
  `wanted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `characters_vehicles_sale` (
  `characterId` varchar(50) NOT NULL,
  `vehicleProps` longtext NOT NULL,
  `price` int NOT NULL DEFAULT '0',
  `seller` int DEFAULT NULL,
  `vehPrice` int DEFAULT NULL,
  `vehProps` int DEFAULT NULL,
  `sellerIdentifier` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `communityservice` (
  `identifier` varchar(100) NOT NULL,
  `actions_remaining` int NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `cooldowns` (
  `pk` int NOT NULL AUTO_INCREMENT,
  `id` text,
  `cooldown` bigint DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `identifier` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk`),
  KEY `identifier` (`identifier`),
  KEY `timestamp` (`timestamp`),
  KEY `cooldown` (`cooldown`)
) ENGINE=InnoDB AUTO_INCREMENT=1097 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `criminal_records` (
  `id` int DEFAULT NULL,
  `offence` varchar(50) DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `officer_id` varchar(50) DEFAULT NULL,
  `jail` int DEFAULT NULL,
  `created_at` int DEFAULT NULL,
  `reason` varchar(50) DEFAULT NULL,
  `fine` varchar(50) DEFAULT NULL,
  `time` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `darkchat_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT '',
  `messages` text,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `datastore` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `shared` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

REPLACE INTO `datastore` (`id`, `name`, `label`, `shared`) VALUES
	(1, 'user_ears', 'Ears', 0),
	(2, 'user_glasses', 'Glasses', 0),
	(3, 'user_helmet', 'Helmet', 0),
	(4, 'user_mask', 'Mask', 0),
	(5, 'user_hat', 'Hat', 0),
	(6, 'property', 'Property', 0),
	(7, 'society_police', 'Police', 1),
	(8, 'user_watches', 'Watches', 0),
	(9, 'user_bags', 'Bags', 0),
	(10, 'society_unicorn', 'Unicorn', 1),
	(11, 'society_unicorn', 'Unicorn', 1),
	(12, 'society_isak', 'Isak', 1),
	(13, 'society_isak', 'Isak', 1),
	(14, 'society_isak', 'Isak', 1),
	(15, 'society_isak', 'Isak', 1),
	(16, 'society_dodspatrullen', 'Dodspatrullen', 1),
	(18, 'society_biker', 'Biker', 1),
	(19, 'society_mafia', 'Mafia', 1),
	(20, 'society_biker', 'Biker', 1),
	(21, 'society_gang2', 'gang2', 1),
	(22, 'society_crips', 'Crips', 1),
	(23, 'society_cartel', 'Cartel', 1);

CREATE TABLE IF NOT EXISTS `datastore_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `owner` varchar(50) DEFAULT NULL,
  `data` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34960 DEFAULT CHARSET=latin1;

REPLACE INTO `datastore_data` (`id`, `name`, `owner`, `data`) VALUES
	(26911, 'society_police', NULL, '{}'),
	(26912, 'society_unicorn', NULL, '{}'),
	(26913, 'society_isak', NULL, '{}'),
	(26914, 'society_dodspatrullen', NULL, '{}');

CREATE TABLE IF NOT EXISTS `devtoolbans` (
  `steam` varchar(25) NOT NULL,
  `rockstar` varchar(50) DEFAULT NULL,
  `live` varchar(21) DEFAULT NULL,
  `xbox` varchar(21) DEFAULT NULL,
  `discord` varchar(30) DEFAULT NULL,
  `ip` varchar(25) DEFAULT NULL,
  `targetn` varchar(32) NOT NULL,
  `banid` int NOT NULL,
  PRIMARY KEY (`banid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `dpkeybinds` (
  `id` varchar(50) DEFAULT NULL,
  `keybind1` varchar(50) DEFAULT 'num4',
  `emote1` varchar(255) DEFAULT '',
  `keybind2` varchar(50) DEFAULT 'num5',
  `emote2` varchar(255) DEFAULT '',
  `keybind3` varchar(50) DEFAULT 'num6',
  `emote3` varchar(255) DEFAULT '',
  `keybind4` varchar(50) DEFAULT 'num7',
  `emote4` varchar(255) DEFAULT '',
  `keybind5` varchar(50) DEFAULT 'num8',
  `emote5` varchar(255) DEFAULT '',
  `keybind6` varchar(50) DEFAULT 'num9',
  `emote6` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `d_policecad_register` (
  `id` varchar(50) DEFAULT NULL,
  `creator` varchar(50) DEFAULT 'Okant',
  `creatorId` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `crime` varchar(50) DEFAULT NULL,
  `reason` longtext,
  `date` varchar(50) DEFAULT NULL,
  `uuid` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `d_policecad_wanted` (
  `id` varchar(50) DEFAULT NULL,
  `creator` varchar(50) DEFAULT 'Okant',
  `creatorId` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `heading` varchar(50) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `uuid` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `epc_bolos` (
  `id` int DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `height` varchar(50) DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  `type_of_crime` varchar(50) DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `fine` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `apperance` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `epc_notes` (
  `id` int DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` varchar(50) DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `fine_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;

REPLACE INTO `fine_types` (`id`, `label`, `amount`, `category`) VALUES
	(1, 'Missbruk av signalhorn', 750, 0),
	(2, 'P-bot', 750, 0),
	(3, 'Felaktig fordonsbelysning', 900, 0),
	(4, 'R?dljus', 1250, 0),
	(5, 'Stopplikt', 1250, 0),
	(6, 'Trafikfarligt fordon', 1500, 0),
	(7, 'Olaglig omk?rning', 1500, 0),
	(9, 'Olovlig k?rning', 2000, 0),
	(10, 'Ej anv?nt hj?lm cykel/MC', 2000, 0),
	(11, 'Brott mot mobilf?rbudet', 2200, 0),
	(12, 'V?rdsl?shet i trafik', 3500, 0),
	(13, 'Smitning', 3500, 0),
	(14, 'Grov v?rdsl?shet i trafik', 3500, 0),
	(15, 'Rattfylleri (0.2 - 1.0)', 2500, 0),
	(16, 'Rattfylleri (1.0 - <)', 5500, 0),
	(17, 'Drograttfylleri', 6500, 0),
	(18, 'Hastighets?vertr?delse (5-15km/h)', 1500, 0),
	(19, 'Hastighets?vertr?delse (15-25km/h)', 2500, 0),
	(20, 'Hastighets?vertr?delse (25-30km/h)', 3500, 0),
	(21, 'Hastighets?vertr?delse (30->km/h)', 4500, 0),
	(23, 'St?rande av allm?na ordningen', 1000, 1),
	(24, 'V?gran av polismans order', 1250, 1),
	(25, 'F?rargelsev?ckande beteende', 1320, 1),
	(26, 'Kr?nkning', 1500, 1),
	(27, 'F?regivande av allm?n st?llning', 2000, 1),
	(28, 'Brott mot griftefriden', 3000, 1),
	(29, 'Olaga intr?ng', 3000, 1),
	(30, 'Skadeg?relse', 3500, 1),
	(31, 'Brott mot jaktlagen', 3500, 1),
	(32, 'Olaga hot', 3600, 2),
	(33, 'Hot mot tj?nsteman', 4000, 2),
	(34, 'Narkotikabrott', 3750, 2),
	(35, 'Grovt narkotikabrott', 5500, 2),
	(36, 'Grovt olaga hot', 6500, 2),
	(37, 'Ofredande', 3500, 2),
	(38, 'Sexuellt ofredande', 4800, 2),
	(39, 'St?ld', 4000, 2),
	(40, 'Grov st?ld', 4500, 2),
	(42, '?vergrepp i r?ttssak', 4500, 2),
	(43, 'Olaga f?rf?ljelse', 4500, 2),
	(44, 'Brott mot knivlagen', 5000, 2),
	(45, 'Bedr?geri', 6500, 2),
	(46, 'Misshandel', 7500, 2),
	(47, 'Grov misshandel', 13500, 2),
	(48, 'V?ld mot tj?nsteman', 7500, 2),
	(49, 'Grovt bedr?geri', 8700, 2),
	(50, 'Vapenbrott klass 1', 10000, 2),
	(51, 'Vapenbrott klass 2', 20000, 2),
	(52, 'Kidnappning', 10000, 3),
	(53, 'F?rs?k till r?n', 12500, 3),
	(54, 'R?n', 16500, 3),
	(55, 'F?rs?k till bankr?n', 18000, 3),
	(56, 'Bankr?n', 25000, 3),
	(57, 'V?llande till annans d?d', 15000, 3),
	(58, 'F?rs?k till mord', 20000, 3),
	(59, 'Mord', 25000, 3);

CREATE TABLE IF NOT EXISTS `gksphone_app_chat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(20) NOT NULL,
  `message` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_bank_transfer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` int NOT NULL,
  `identifier` longtext,
  `price` longtext NOT NULL,
  `name` longtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_blockednumber` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` longtext NOT NULL,
  `hex` longtext NOT NULL,
  `number` longtext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_calls` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner` longtext NOT NULL COMMENT 'Num tel proprio',
  `num` longtext NOT NULL COMMENT 'Num refÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½rence du contact',
  `incoming` int NOT NULL COMMENT 'DÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½fini si on est ÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½ l''origine de l''appels',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepts` int NOT NULL COMMENT 'Appels accepter ou pas',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_gallery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hex` longtext NOT NULL,
  `image` longtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_gotur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` longtext NOT NULL,
  `price` int DEFAULT '0',
  `count` int NOT NULL,
  `item` longtext NOT NULL,
  `kapat` varchar(50) DEFAULT 'false',
  `adet` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_gps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hex` longtext NOT NULL,
  `nott` longtext,
  `gps` longtext,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_group_message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupid` int NOT NULL,
  `owner` longtext NOT NULL,
  `ownerphone` varchar(50) NOT NULL,
  `groupname` varchar(255) NOT NULL,
  `messages` longtext NOT NULL,
  `contacts` longtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `groupid` (`groupid`) USING BTREE,
  CONSTRAINT `FK_phonegroupmessage` FOREIGN KEY (`groupid`) REFERENCES `gksphone_messages_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_insto_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `forename` longtext NOT NULL,
  `surname` longtext NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` longtext NOT NULL,
  `avatar_url` longtext,
  `takip` longtext,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_insto_instas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorId` int NOT NULL,
  `realUser` longtext,
  `message` longtext NOT NULL,
  `image` longtext NOT NULL,
  `filters` longtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `likes` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_gksphone_insto_instas_gksphone_insto_accounts` (`authorId`),
  CONSTRAINT `FK_gksphone_insto_instas_gksphone_insto_accounts` FOREIGN KEY (`authorId`) REFERENCES `gksphone_insto_accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_insto_likes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorId` int DEFAULT NULL,
  `inapId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_gksphone_insto_likes_gksphone_insto_accounts` (`authorId`),
  KEY `FK_gksphone_insto_likes_gksphone_insto_instas` (`inapId`),
  CONSTRAINT `FK_gksphone_insto_likes_gksphone_insto_accounts` FOREIGN KEY (`authorId`) REFERENCES `gksphone_insto_accounts` (`id`),
  CONSTRAINT `FK_gksphone_insto_likes_gksphone_insto_instas` FOREIGN KEY (`inapId`) REFERENCES `gksphone_insto_instas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_insto_story` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorId` int NOT NULL,
  `realUser` longtext,
  `stories` longtext NOT NULL,
  `isRead` varchar(256) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `likes` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_gksphone_insto_story_gksphone_insto_accounts` (`authorId`) USING BTREE,
  CONSTRAINT `FK_gksphone_insto_story_gksphone_insto_accounts` FOREIGN KEY (`authorId`) REFERENCES `gksphone_insto_accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_job_message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `number` varchar(50) NOT NULL,
  `message` longtext NOT NULL,
  `photo` longtext,
  `gps` varchar(255) NOT NULL,
  `owner` int NOT NULL DEFAULT '0',
  `jobm` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_mails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(255) NOT NULL DEFAULT '0',
  `sender` varchar(255) NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '0',
  `image` text NOT NULL,
  `message` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transmitter` varchar(50) NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `message` longtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isRead` int NOT NULL DEFAULT '0',
  `owner` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;

/*!40000 ALTER TABLE `gksphone_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `gksphone_messages` ENABLE KEYS */;

CREATE TABLE IF NOT EXISTS `gksphone_messages_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner` longtext NOT NULL,
  `ownerphone` varchar(50) NOT NULL,
  `groupname` varchar(255) NOT NULL,
  `gimage` longtext NOT NULL,
  `contacts` longtext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hex` longtext,
  `haber` longtext,
  `baslik` longtext,
  `resim` longtext,
  `video` longtext,
  `zaman` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` longtext NOT NULL,
  `crypto` longtext NOT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `avatar_url` longtext,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_tinderacc` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `passaword` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `gender` int DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_tindermatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL DEFAULT '0',
  `friend_id` int NOT NULL DEFAULT '0',
  `is_match` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_tindermessage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `tinderes` text NOT NULL,
  `owner` int NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_twitter_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '0',
  `password` varchar(64) NOT NULL DEFAULT '0',
  `avatar_url` longtext,
  `profilavatar` longtext,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_twitter_likes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorId` int DEFAULT NULL,
  `tweetId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_gksphone_twitter_likes_gksphone_twitter_accounts` (`authorId`),
  KEY `FK_gksphone_twitter_likes_gksphone_twitter_tweets` (`tweetId`),
  CONSTRAINT `FK_gksphone_twitter_likes_gksphone_twitter_accounts` FOREIGN KEY (`authorId`) REFERENCES `gksphone_twitter_accounts` (`id`),
  CONSTRAINT `FK_gksphone_twitter_likes_gksphone_twitter_tweets` FOREIGN KEY (`tweetId`) REFERENCES `gksphone_twitter_tweets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_twitter_tweets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorId` int NOT NULL,
  `realUser` varchar(50) DEFAULT NULL,
  `message` varchar(256) NOT NULL,
  `image` longtext,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `likes` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_gksphone_twitter_tweets_gksphone_twitter_accounts` (`authorId`),
  CONSTRAINT `FK_gksphone_twitter_tweets_gksphone_twitter_accounts` FOREIGN KEY (`authorId`) REFERENCES `gksphone_twitter_accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_users_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` longtext,
  `number` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*!40000 ALTER TABLE `gksphone_users_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `gksphone_users_contacts` ENABLE KEYS */;

CREATE TABLE IF NOT EXISTS `gksphone_vehicle_sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner` longtext NOT NULL,
  `ownerphone` varchar(255) NOT NULL,
  `plate` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `image` longtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `gksphone_yellow` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(50) DEFAULT NULL,
  `firstname` varchar(256) DEFAULT NULL,
  `lastname` varchar(256) DEFAULT NULL,
  `message` longtext NOT NULL,
  `image` longtext,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `instagram_account` (
  `id` varchar(90) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avatar` text,
  `description` text,
  `verify` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `instagram_followers` (
  `username` varchar(50) NOT NULL,
  `followed` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `instagram_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `image` text NOT NULL,
  `description` varchar(255) NOT NULL,
  `location` varchar(50) NOT NULL,
  `filter` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `likes` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `instagram_stories` (
  `owner` varchar(50) NOT NULL,
  `data` text,
  PRIMARY KEY (`owner`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `insta_stories` (
  `username` varchar(50) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `filter` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `image` text,
  `created` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `inventories` (
  `name` varchar(255) DEFAULT NULL,
  `data` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `whitelisted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=645654657 DEFAULT CHARSET=latin1;

REPLACE INTO `jobs` (`id`, `name`, `label`, `whitelisted`) VALUES
	(1, 'unemployed', 'A-Kassa', 0),
	(2, 'ambulance', 'Sjukv?rdare', 1),
	(3, 'mecano', 'Mekonomen', 1),
	(4, 'police', 'Polis', 1),
	(5, 'cardealer', 'Ragnhilds Lyx & Snyggt', 1),
	(6, 'taxi', 'Uber', 1),
	(7, 'realestateagent', 'M?klare', 1),
	(8, 'bennys', 'Vianor', 1),
	(10, 'nightclub', 'Bahamas Mamas', 1),
	(69, 'raddningstjansten', 'R?ddningstj?nsten', 1),
	(71, 'postnord', 'Postnord', 0),
	(81, 'trygghansa', 'Trygghansa', 1),
	(82, 'nattklubb', 'Vanilla Unicorn', 1),
	(83, 'qpark', 'Qpark', 1),
	(84, 'mcdonalds', 'Mcdonalds', 1),
	(91, 'bandidos', 'Bandidos', 1),
	(92, 'hells', 'Hells', 1),
	(93, 'ballas', 'Ballas', 1),
	(94, 'bloods', 'Bloods', 1),
	(95, 'crips', 'Crips', 1),
	(96, 'groovestreet', 'Groovestreet', 1),
	(97, 'grove', 'Grove', 1),
	(98, 'loszetas', 'Sicilianska Maffian', 1),
	(99, 'shottaz', '/', 1),
	(100, 'boatdealer', 'B?tbolaget', 1),
	(103, 'autoexperten', 'Autoexperten', 1),
	(355, '19th', '19th Street', 1),
	(555, 'maisonette', 'Maisonette', 1),
	(2323, 'falck', 'Falck', 1),
	(4131, 'cardealer2', 'Emil\'s MC', 1),
	(4545, 'vl13', '....', 1),
	(5453, 'delicio', 'Delicio Bar', 1),
	(10012, 'securitas', 'Securitas', 1),
	(23434, 'costanostra', 'Commisso?ndrina', 1),
	(34343, 'gsf', 'Svenska Maffian', 1),
	(53535, 'vl133', 'The Silent Tribe', 1),
	(234234, 'hyenorna', 'Hyenorna', 1),
	(343434, 'latinkings', 'Alliansen', 1),
	(454353, 'lost', 'Lostmc', 1),
	(4343434, 'dp', 'Kartellen', 1),
	(4545242, 'fallenangels', 'Kavkaz', 1),
	(34423435, 'families', '/', 1),
	(34423436, 'dodspatrullen', 'Alliansen', 1),
	(34423437, 'salims', 'Salims Pizzeria', 1),
	(645654645, 'sinaloa', 'Whyos', 1),
	(645654646, 'advokat', '?hman Advokatbyr?', 1),
	(645654647, 'alliansen', 'Alliansen', 1),
	(645654648, 'danskarna', 'danskarna', 1),
	(645654649, 'balles', 'Abdison', 1),
	(645654650, 'biker', 'Biker', 1),
	(645654652, 'mafia', 'Mafia', 1),
	(645654654, 'gang2', 'gang2', 1),
	(645654655, 'crips', 'Cosa Nostra', 1),
	(645654656, 'cartel', 'Cartel', 1);

CREATE TABLE IF NOT EXISTS `job_grades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_name` varchar(255) DEFAULT NULL,
  `grade` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `salary` int NOT NULL,
  `skin_male` longtext NOT NULL,
  `skin_female` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2147483648 DEFAULT CHARSET=latin1;

REPLACE INTO `job_grades` (`id`, `job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
	(1, 'unemployed', 0, 'rsa', 'Arbetsl?s', 100, '', ''),
	(2, 'balles', 1, 'arbetart', 'arbetarte', 1, '', ''),
	(3, 'balles', 2, 'gangister', 'Ganggang', 1000, '', ''),
	(6, 'mecano', 0, 'recrue', 'Provanst?lld (0)', 200, '', ''),
	(7, 'mecano', 1, 'novice', 'Anst?lld (1)', 260, '', ''),
	(8, 'mecano', 2, 'experimente', 'Erfaren (2)', 350, '', ''),
	(9, 'mecano', 4, 'boss', 'Personalchef (4)', 400, '', ''),
	(10, 'mecano', 5, 'boss', 'Chef (5)', 450, '', ''),
	(11, 'police', 1, 'recruit', 'Aspirant', 400, '', ''),
	(12, 'police', 2, 'officer', 'Assistent', 600, '', ''),
	(13, 'police', 3, 'sergeant', 'Assistent 4 ?rs', 800, '', ''),
	(14, 'police', 4, 'lieutenant', 'Inspekt?r', 1000, '', ''),
	(15, 'police', 7, 'boss', 'Polissekreterare', 1300, '', ''),
	(16, 'police', 6, 'boss', 'Polisintendent', 1400, '', ''),
	(17, 'police', 8, 'boss', 'Polis?verintendent', 1600, '', ''),
	(18, 'police', 9, 'boss', 'Polism?stare', 1800, '', ''),
	(19, 'police', 10, 'boss', 'Polisdirekt?r', 2000, '', ''),
	(20, 'cardealer', 1, 'novice', 'L?rling', 175, '', ''),
	(21, 'cardealer', 2, 'novice', 'F?rs?ljare', 225, '', ''),
	(22, 'cardealer', 3, 'experienced', 'Erfaren', 300, '', ''),
	(23, 'cardealer', 4, 'boss', 'Chef', 400, '', ''),
	(24, 'cardealer', 5, 'boss', 'Bitr?dande Chef', 300, '', ''),
	(26, 'taxi', 0, 'recrue', 'Provanst?lld', 150, '', ''),
	(27, 'taxi', 1, 'novice', 'F?rare', 225, '', ''),
	(28, 'taxi', 2, 'experimente', 'Uber', 300, '', ''),
	(29, 'taxi', 3, 'boss', 'Personalchef', 350, '', ''),
	(30, 'mafia', 0, 'soldato', 'Springpojke', 0, '', ''),
	(31, 'mafia', 2, 'mafioso', 'Medlem', 0, '', ''),
	(32, 'mafia', 3, 'capo', 'Trusted', 0, '', ''),
	(33, 'mafia', 4, 'assassin', 'Hitman', 0, '', ''),
	(34, 'mafia', 5, 'consigliere', 'Vice-Ledare', 0, '', ''),
	(35, 'mafia', 6, 'boss', 'Ledare', 0, '', ''),
	(40, 'biker', 0, 'soldato', 'Springpojke', 0, '', ''),
	(41, 'biker', 4, 'assassin', 'Hitman', 0, '', ''),
	(42, 'biker', 5, 'consigliere', 'Vice-Ledare', 0, '', ''),
	(43, 'biker', 6, 'boss', 'Ledare', 0, '', ''),
	(44, 'biker', 2, 'mafioso', 'Medlem', 0, '', ''),
	(45, 'biker', 3, 'capo', 'Trusted', 0, '', ''),
	(154, 'realestateagent', 0, 'location', 'Leasing', 250, '', ''),
	(155, 'realestateagent', 1, 'vendeur', 'S?ljare', 500, '', ''),
	(156, 'realestateagent', 2, 'boss', 'Manager', 500, '', ''),
	(157, 'realestateagent', 3, 'boss', 'VD', 550, '', ''),
	(242, 'bennys', 0, 'recruit', 'Provanst?lld', 150, '', ''),
	(243, 'bennys', 1, 'worker', 'Arbetare', 200, '', ''),
	(244, 'bennys', 2, 'worker', 'Erfaren Arbetare', 300, '', ''),
	(245, 'bennys', 5, 'boss', 'Chef', 400, '', ''),
	(247, 'bennys', 3, 'boss', 'Personalchef', 350, '', ''),
	(249, 'mecano', 3, 'experimente', 'Gruppledare (3)', 450, '', ''),
	(252, 'ambulance', 0, 'recruit', 'Praktikant (0)', 150, '', ''),
	(253, 'ambulance', 1, 'caretaker', 'V?rdare (1)', 250, '', ''),
	(254, 'ambulance', 2, 'assistantnurse', 'Undersk?terska (2)', 300, '', ''),
	(255, 'ambulance', 3, 'nurse', 'Sjuksk?terska (3)', 350, '', ''),
	(256, 'ambulance', 4, 'psychologist', 'Psykolog (4)', 400, '', ''),
	(257, 'ambulance', 5, 'doctor', 'L?kare (5)', 425, '', ''),
	(258, 'ambulance', 6, 'doctor', '?verl?kare (6)', 488, '', ''),
	(259, 'police', 5, 'officer', 'Kommissarie', 500, '', ''),
	(260, 'nightclub', 0, 'recruit', 'Provanst?lld', 150, '', ''),
	(261, 'nightclub', 1, 'worker', 'Anst?lld', 250, '', ''),
	(262, 'nightclub', 2, 'experienced', 'Erfaren Arbetare', 300, '', ''),
	(263, 'nightclub', 3, 'boss', 'Del?gare', 390, '', ''),
	(264, 'nightclub', 4, 'boss', 'Klubb?gare', 450, '', ''),
	(265, 'garbage', 0, 'employee', 'Anst?lld', 250, '', ''),
	(269, 'ambulance', 7, 'boss', 'Regionchef', 550, '', ''),
	(272, 'raddningstjansten', 1, 'recrue', 'Provanst?lld', 150, '', ''),
	(273, 'raddningstjansten', 2, 'novice', 'Anst?lld', 250, '', ''),
	(274, 'raddningstjansten', 3, 'boss', 'Chef', 500, '', ''),
	(300, 'maisonette', 0, 'recruit', 'Provanst?lld', 150, '', ''),
	(301, 'maisonette', 1, 'worker', 'Anst?lld', 200, '', ''),
	(312, 'cartel', 6, 'boss', 'Ledare', 0, '', ''),
	(318, 'trygghansa', 0, 'recrue', 'Provanst?lld', 250, '', ''),
	(319, 'trygghansa', 1, 'novice', 'Anst?lld', 500, '', ''),
	(320, 'trygghansa', 2, 'experimente', 'Erfaren', 750, '', ''),
	(321, 'trygghansa', 3, 'kung', 'Bitr?dande chef', 300, '', ''),
	(322, 'trygghansa', 4, 'boss', 'Chef', 400, '', ''),
	(349, 'postnord', 0, 'interim', 'Provanst?lld', 169, '', ''),
	(350, 'postnord', 1, 'novice', 'Anst?lld', 200, '', ''),
	(351, 'postnord', 2, 'boss', 'Chef', 300, '', ''),
	(354, 'nattklubb', 0, 'recrue', 'Bartender', 200, '', ''),
	(355, 'nattklubb', 1, 'experimente', 'Dansare', 350, '', ''),
	(361, 'nattklubb', 2, 'experienced', 'Del?gare', 400, '', ''),
	(362, 'nattklubb', 3, 'boss', '?gare', 420, '', ''),
	(363, 'qpark', 0, 'recrue', 'Nyanst?lld', 150, '{}', '{}'),
	(364, 'qpark', 1, 'novice', 'Anst?lld', 250, '{}', '{}'),
	(365, 'qpark', 2, 'experimente', 'Erfaren', 350, '{}', '{}'),
	(367, 'qpark', 3, 'boss', 'Chef', 450, '{}', '{}'),
	(368, 'mcdonalds', 0, 'recrue', 'Nyanst?lld', 100, '{}', '{}'),
	(369, 'mcdonalds', 1, 'novice', 'Anst?lld', 200, '{}', '{}'),
	(370, 'mcdonalds', 2, 'experimente', 'Erfaren', 300, '{}', '{}'),
	(371, 'mcdonalds', 3, 'boss', 'Personalchef', 400, '{}', '{}'),
	(372, 'mcdonalds', 4, 'boss', 'Chef', 500, '{}', '{}'),
	(390, 'cartel', 0, 'soldato', 'Springpojke', 1, '{}', '{}'),
	(391, 'cartel', 2, 'mafioso', 'Medlem', 1, '{}', '{}'),
	(392, 'cartel', 3, 'capo', 'Trusted', 1, '{}', '{}'),
	(393, 'cartel', 4, 'assassin', 'Hitman', 1, '{}', '{}'),
	(394, 'cartel', 5, 'consigliere', 'Vice-Ledare', 1, '{}', '{}'),
	(399, 'hells', 0, 'recrue', 'Provanst?lld', 1, '', ''),
	(400, 'hells', 1, 'novice', 'Anst?lld', 1, '', ''),
	(401, 'hells', 2, 'experimente', 'Erfaren', 1, '', ''),
	(402, 'hells', 3, 'boss', 'G?ngledare', 1, '', ''),
	(403, 'ballas', 0, 'recrue', 'Springis', 1, '', ''),
	(404, 'ballas', 1, 'novice', 'Medlem', 1, '', ''),
	(405, 'ballas', 2, 'boss', 'Vice-Boss', 1, '', ''),
	(406, 'ballas', 3, 'boss', 'Boss', 1, '', ''),
	(407, 'bloods', 0, 'recrue', 'Provanst?lld', 1, '', ''),
	(408, 'bloods', 1, 'novice', 'Anst?lld', 1, '', ''),
	(409, 'bloods', 2, 'experimente', 'Erfaren', 1, '', ''),
	(410, 'bloods', 3, 'boss', 'G?ngledare', 1, '', ''),
	(411, 'crips', 0, 'soldato', 'Springpojke', 1, '', ''),
	(412, 'crips', 2, 'mafioso', 'Medlem', 1, '', ''),
	(413, 'crips', 3, 'capo', 'Trusted', 1, '', ''),
	(414, 'crips', 4, 'assassin', 'Hitman', 1, '', ''),
	(415, 'groovestreet', 0, 'recrue', 'Provanst?lld', 1, '', ''),
	(416, 'groovestreet', 1, 'novice', 'Anst?lld', 1, '', ''),
	(417, 'groovestreet', 2, 'experimente', 'Erfaren', 1, '', ''),
	(418, 'groovestreet', 3, 'boss', 'Personalchef', 1, '', ''),
	(419, 'grove', 0, 'recrue', 'Provanst?lld', 1, '', ''),
	(420, 'grove', 1, 'novice', 'Anst?lld', 1, '', ''),
	(421, 'grove', 2, 'experimente', 'Erfaren', 1, '', ''),
	(422, 'grove', 3, 'boss', 'Personalchef', 1, '', ''),
	(423, 'bandidos', 0, 'recrue', 'Provanst?lld', 1, '', ''),
	(424, 'bandidos', 1, 'novice', 'Anst?lld', 1, '', ''),
	(425, 'bandidos', 2, 'experimente', 'Erfaren', 1, '', ''),
	(426, 'bandidos', 3, 'boss', 'Personalchef', 1, '', ''),
	(427, 'shottaz', 0, 'recrue', 'Provanst?lld', 1, '', ''),
	(428, 'shottaz', 1, 'novice', 'Anst?lld', 1, '', ''),
	(429, 'shottaz', 2, 'experimente', 'Erfaren', 1, '', ''),
	(430, 'shottaz', 3, 'boss', 'G?ngledare', 1, '', ''),
	(465, 'crips', 5, 'consigliere', 'Vice-Ledare', 0, '', ''),
	(466, 'crips', 6, 'boss', 'Ledare', 0, '', ''),
	(500, 'gang2', 0, 'soldato', 'Springpojke', 1, '', ''),
	(502, 'gang2', 2, 'mafioso', 'Medlem', 1, '', ''),
	(503, 'gang2', 3, 'capo', 'Trusted', 1, '', ''),
	(504, 'gang2', 4, 'assassin', 'Hitman', 0, '', ''),
	(505, 'gang2', 5, 'consigliere', 'Voice-Ledare', 0, '', ''),
	(506, 'gang2', 6, 'boss', 'Ledare', 0, '', ''),
	(653, 'police', 0, 'reqruit', 'Studerande-Polis', 200, '', ''),
	(1235, 'cardealer2', 1, 'novice', 'F?rs?ljare', 200, '', ''),
	(1236, 'cardealer2', 0, 'recruit', 'L?rling', 100, '', ''),
	(2332, 'securitas', 4, 'boss', 'Chef', 450, '', ''),
	(3232, 'latinkings', 1, 'recrue', 'Medlem', 1, '', ''),
	(4242, 'securitas', 1, 'sergeant', 'Anst?lld', 200, '', ''),
	(4343, 'autoexperten', 2, 'novice', 'Erfaren', 300, '', ''),
	(4545, 'hyenorna', 1, 'medlem', 'Medlem', 1, '', ''),
	(5454, 'fallenangels', 0, 'springpojke', 'Springpojke', 1, '', ''),
	(13232, 'gsf', 1, 'novice', 'Medlem', 1, '', ''),
	(23131, 'boatdealer', 0, 'novice', 'Provanst?lld', 200, '', ''),
	(23232, 'falck', 0, 'novice', 'Provanst?lld', 100, '', ''),
	(23424, 'boatdealer', 1, 'novice', 'Anst?lld', 200, '', ''),
	(42342, 'lost', 0, 'recrue', 'Springpojke', 1, '', ''),
	(42422, 'gsf', 3, 'boss', 'Boss', 1, '', ''),
	(43242, 'securitas', 0, 'officer', 'Provanst?lld', 100, '', ''),
	(43434, 'latinkings', 0, 'recrue', 'Springpojke', 1, '', ''),
	(45453, 'autoexperten', 1, 'novice', 'Anst?lld', 200, '', ''),
	(45488, 'alliansen', 0, 'recrue', 'Springpojke', 1, '', ''),
	(45565, 'vl13', 3, 'boss', 'Boss', 1, '', ''),
	(45888, 'alliansen', 1, 'novice', 'Medlem', 1, '', ''),
	(53535, 'delicio', 1, 'novice', 'Anst?lld', 200, '', ''),
	(54356, 'costanostra', 2, 'topshooter', 'Top shooter', 1, '', ''),
	(56466, 'dp', 1, 'medlem', 'Medlem', 1, '{}', '{}'),
	(57676, 'dp', 4, 'boss', 'Boss', 1, '{}', '{}'),
	(64644, 'delicio', 3, 'boss', 'Del?gare', 300, '', ''),
	(65656, 'sinaloa', 0, 'medlem', 'Springpojke', 1, '', ''),
	(65666, '19th', 1, '19th Street', 'Springpojke', 1, '', ''),
	(65667, '19th', 2, '19th Street', 'Medlem', 1, '', ''),
	(65668, '19th', 3, '19th Street', 'Vice-Boss', 1, '', ''),
	(65669, '19th', 4, '19th Street', 'Boss', 1, '', ''),
	(65757, 'costanostra', 1, 'medlem', 'Medlem', 1, '', ''),
	(67676, 'costanostra', 4, 'boss', 'Boss', 1, '', ''),
	(73043, 'loszetas', 3, 'boss', 'Boss', 1, '', ''),
	(97989, 'gsf', 0, 'novice', 'Springpojke', 1, '', ''),
	(131231, 'cardealer2', 4, 'boss', 'Chef', 450, '', ''),
	(233232, 'securitas', 2, 'lieutenant', 'Erfaren', 350, '', ''),
	(242342, 'boatdealer', 2, 'novice', 'Erfaren', 300, '', ''),
	(321313, 'securitas', 3, 'boss', 'Bitr.Chef', 350, '', ''),
	(324424, 'boatdealer', 3, 'boss', 'Chef', 0, '', ''),
	(342342, 'lost', 3, 'boss', 'Boss', 1, '', ''),
	(345353, 'autoexperten', 0, 'novice', 'Provanst?lld', 100, '', ''),
	(345453, 'autoexperten', 3, 'boss', 'Bitr?dande Chef', 200, '', ''),
	(423423, 'lost', 1, 'recrue', 'Medlem', 1, '', ''),
	(434343, 'fallenangels', 2, 'novice', 'Top Shooter', 1, '', ''),
	(434344, 'hyenorna', 3, 'boss', 'Boss', 1, '', ''),
	(453434, 'fallenangels', 1, 'medlem', 'Medlem', 1, '', ''),
	(455433, 'vl13', 0, 'novice', 'Springpojke', 1, '', ''),
	(458881, 'alliansen', 2, 'boss', 'Boss', 1, '', ''),
	(464646, 'sinaloa', 4, 'boss', 'Boss', 1, '', ''),
	(543532, 'latinkings', 3, 'boss', 'Boss', 1, '', ''),
	(543535, 'advokat', 1, 'boss', 'Bitr?dande', 350, '', ''),
	(545454, 'fallenangels', 3, 'boss', 'Vice-Boss', 1, '', ''),
	(545466, 'advokat', 0, 'Anst?lld', 'Anst?lld', 200, '', ''),
	(545666, 'hyenorna', 2, 'novice', 'Kapten', 1, '', ''),
	(645646, 'sinaloa', 2, 'medlem', 'Top shooter', 1, '', ''),
	(646464, 'vl133', 3, 'boss', 'Boss', 1, '', ''),
	(654644, 'advokat', 2, 'boss', 'Chef', 450, '', ''),
	(655667, 'fallenangels', 4, 'boss', 'Boss', 1, '', ''),
	(657575, 'autoexperten', 4, 'boss', 'Chef', 450, '', ''),
	(788675, 'gsf', 2, 'boss', 'Vice-Boss', 1, '', ''),
	(803535, 'loszetas', 2, 'experimente', 'Vice Boss', 1, '', ''),
	(1242342, 'sinaloa', 3, 'boss', 'Vice-Boss', 1, '', ''),
	(2532523, 'cardealer', 6, 'boss', 'VD', 550, '', ''),
	(3434545, 'costanostra', 3, 'boss', 'Vice-Boss', 1, '', ''),
	(4343434, 'hyenorna', 0, 'springpojke', 'Springpojke', 1, '', ''),
	(5353535, 'falck', 2, 'novice', 'Erfaren', 300, '', ''),
	(5433333, 'danskarna', 0, 'springpojke', 'Springpojke', 1, '', ''),
	(5433334, 'danskarna', 1, 'medlem', 'Medlem', 1, '', ''),
	(5433335, 'danskarna', 2, 'boss', 'Vice-Boss', 1, '', ''),
	(5433336, 'danskarna', 3, 'boss', 'Boss', 1, '', ''),
	(5454545, 'dp', 2, 'topshooter', 'Top-Shooter', 100, '{}', '{}'),
	(6455646, 'costanostra', 0, 'medlem', 'Springpojke', 1, '', ''),
	(6456464, 'vl133', 1, 'novice', 'Medlem', 1, '', ''),
	(6546464, 'dp', 3, 'boss', 'Vice-boss', 1, '{}', '{}'),
	(7575757, 'vl133', 2, 'boss', 'Vice-Boss', 1, '', ''),
	(7645756, 'vl13', 2, 'boss', 'Vice-Boss', 1, '', ''),
	(23232323, 'falck', 1, 'novice', 'Anst?lld', 200, '', ''),
	(23525525, 'cardealer2', 3, 'boss', 'Bitr?dande Chef', 350, '', ''),
	(32525255, 'ambulance', 6, 'boss', 'Bitr?dande Regionchef', 200, '', ''),
	(43242424, 'cardealer2', 5, 'boss', 'VD', 400, '', ''),
	(45234452, 'delicio', 4, 'boss', '?gare', 500, '', ''),
	(45345325, 'delicio', 0, 'novice', 'Provanst?lld', 100, '', ''),
	(52352525, 'falck', 3, 'boss', 'Chef', 500, '', ''),
	(52352526, 'families', 1, 'springpojke', 'Springpojke', 1, '{}', '{}'),
	(52352527, 'families', 2, 'medlem', 'Medlem', 1, '{}', '{}'),
	(52352528, 'families', 3, 'novice', 'Top Shooter', 1, '{}', '{}'),
	(52352529, 'families', 4, 'boss', 'Vice-Boss', 1, '{}', '{}'),
	(52352530, 'families', 5, 'boss', 'Boss', 1, '{}', '{}'),
	(52352531, 'cardealer2', 2, 'experienced', 'Erfaren', 400, '', ''),
	(52352532, 'dodspatrullen', 0, 'springpojke', 'Springpojke', 1, '{}', '{}'),
	(52352533, 'dodspatrullen', 1, 'medlem', 'Medlem', 1, '{}', '{}'),
	(52352534, 'dodspatrullen', 2, 'topshooter', 'Top-Shooter', 1, '{}', '{}'),
	(52352535, 'dodspatrullen', 3, 'boss', 'Vice-boss', 1, '{}', '{}'),
	(52352536, 'dodspatrullen', 4, 'boss', 'Boss', 1, '{}', '{}'),
	(52352537, 'salims', 0, 'recruit', 'Provanst?lld', 100, '{}', '{}'),
	(52352538, 'salims', 1, 'chef', 'Arbetare', 200, '{}', '{}'),
	(52352539, 'salims', 2, 'boss', 'Chef', 400, '{}', '{}'),
	(52352540, 'salims', 3, 'boss', 'VD', 500, '{}', '{}'),
	(52352558, 'maisonette', 2, 'experienced', 'Erfaren Arbetare', 350, '', ''),
	(52352559, 'maisonette', 4, 'boss', '?gare', 500, '', ''),
	(52352560, 'maisonette', 3, 'boss', 'Del?gare', 420, '', ''),
	(56456464, 'dp', 0, 'springpojke', 'Springpojke', 1, '{}', '{}'),
	(64646464, 'vl133', 0, 'novice', 'Springpojke', 1, '', ''),
	(67464646, 'vl13', 1, 'novice', 'Medlem', 1, '', ''),
	(86786786, 'sinaloa', 1, 'medlem', 'Medlem', 1, '', ''),
	(234243424, 'bennys', 4, 'boss', 'Bitr?dande Chef', 450, '', ''),
	(834834834, 'loszetas', 1, 'novice', 'Medlem', 0, '', ''),
	(2147483647, 'delicio', 2, 'novice', 'Erfaren', 200, '', '');

CREATE TABLE IF NOT EXISTS `jsfour_criminalrecord` (
  `offense` varchar(160) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `charge` varchar(255) DEFAULT NULL,
  `description` mediumtext,
  `term` varchar(255) DEFAULT NULL,
  `classified` int NOT NULL DEFAULT '0',
  `identifier` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `warden` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`offense`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_criminaluserinfo` (
  `identifier` varchar(160) NOT NULL,
  `aliases` varchar(255) DEFAULT NULL,
  `recordid` varchar(255) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  `eyecolor` varchar(255) DEFAULT NULL,
  `haircolor` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `jsfour_dna` (
  `pk` varchar(255) NOT NULL,
  `killer` varchar(255) DEFAULT NULL,
  `dead` varchar(255) DEFAULT NULL,
  `weapon` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT 'murder',
  `lastdigits` varchar(255) DEFAULT NULL,
  `uploader` varchar(255) DEFAULT NULL,
  `datum` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `mail_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mail` varchar(120) NOT NULL,
  `password` varchar(120) NOT NULL,
  `createdBy` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `mail_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` varchar(60) NOT NULL,
  `sender` varchar(120) NOT NULL,
  `receiver` varchar(120) NOT NULL,
  `subject` varchar(120) NOT NULL,
  `content` text,
  `isRead` tinyint DEFAULT '0',
  `sendBy` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `mark_cooldowns` (
  `owner` varchar(50) DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `place` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `owned_properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `rented` int NOT NULL,
  `owner` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `owned_vehicles` (
  `owner` varchar(40) NOT NULL,
  `plate` varchar(12) NOT NULL,
  `vehicle` longtext,
  `type` varchar(20) NOT NULL DEFAULT 'car',
  `job` varchar(20) DEFAULT NULL,
  `stored` tinyint NOT NULL DEFAULT '0',
  `lasthouse` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `playerhousing` (
  `id` int NOT NULL,
  `owner` varchar(50) DEFAULT NULL,
  `rented` tinyint(1) DEFAULT NULL,
  `price` int DEFAULT NULL,
  `wardrobe` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `player_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `number` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `iban` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `display` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_general_ci NOT NULL,
  `pp` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `identifier` (`identifier`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `player_gallery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` text COLLATE utf8mb4_general_ci NOT NULL,
  `resim` text COLLATE utf8mb4_general_ci NOT NULL,
  `data` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `player_mails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sender` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subject` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_general_ci,
  `read` tinyint DEFAULT '0',
  `mailid` int DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `button` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `identifier` (`identifier`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `player_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` text COLLATE utf8mb4_general_ci NOT NULL,
  `baslik` text COLLATE utf8mb4_general_ci NOT NULL,
  `aciklama` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `playlists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(60) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `playlist_songs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `playlist` int DEFAULT NULL,
  `link` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


CREATE TABLE IF NOT EXISTS `queuesystem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `storageunits` (
  `storageUnit` int NOT NULL,
  `storageItems` longtext NOT NULL,
  `storageOwner` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `store_balance` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `market_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `income` bit(1) NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `amount` int unsigned NOT NULL,
  `date` int unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=447 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `store_business` (
  `market_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `stock` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '[]',
  `stock_upgrade` tinyint unsigned NOT NULL DEFAULT '0',
  `truck_upgrade` tinyint unsigned NOT NULL DEFAULT '0',
  `relationship_upgrade` tinyint unsigned NOT NULL DEFAULT '0',
  `money` int unsigned NOT NULL DEFAULT '0',
  `total_money_earned` int unsigned NOT NULL DEFAULT '0',
  `total_money_spent` int unsigned NOT NULL DEFAULT '0',
  `goods_bought` int unsigned NOT NULL DEFAULT '0',
  `distance_traveled` double unsigned NOT NULL DEFAULT '0',
  `total_visits` int unsigned NOT NULL DEFAULT '0',
  `customers` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`market_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

REPLACE INTO `store_business` (`market_id`, `user_id`, `stock`, `stock_upgrade`, `truck_upgrade`, `relationship_upgrade`, `money`, `total_money_earned`, `total_money_spent`, `goods_bought`, `distance_traveled`, `total_visits`, `customers`) VALUES
	('market_21', 'steam:11000013e75e2f8', '{"fries":1999,"monster":5}', 0, 0, 0, 55363452, 55, 101250, 2005, 2.08, 7, 1),
	('market_3', 'steam:11000013f975722', '[]', 0, 0, 0, 0, 0, 0, 0, 0, 27, 0);

CREATE TABLE IF NOT EXISTS `store_jobs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `market_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `reward` int unsigned NOT NULL DEFAULT '0',
  `product` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `amount` int NOT NULL DEFAULT '0',
  `progress` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `tinder_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `pp` text COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `gender` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `targetGender` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `hobbies` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `age` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `description` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `password` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `tinder_likes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(1024) COLLATE utf8mb4_general_ci NOT NULL,
  `likeds` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `tinder_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `number` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `messages` varchar(1024) COLLATE utf8mb4_general_ci DEFAULT '{}',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `twitter_account` (
  `id` varchar(90) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `avatar` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `twitter_hashtags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(80) COLLATE utf8mb4_general_ci NOT NULL,
  `created` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `count` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `twitter_mentions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_tweet` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `mentioned` text COLLATE utf8mb4_general_ci NOT NULL,
  `created` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `twitter_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `at` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `message` varchar(250) COLLATE utf8mb4_bin NOT NULL,
  `img` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `time` bigint NOT NULL,
  `verified` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


CREATE TABLE IF NOT EXISTS `twitter_tweets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(80) COLLATE utf8mb4_general_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `hashtags` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `mentions` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `created` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `image` text COLLATE utf8mb4_general_ci NOT NULL,
  `likes` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `twitter_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `img` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `time` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=COMPACT;


CREATE TABLE IF NOT EXISTS `users` (
  `identifier` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `license` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `permission_level` int DEFAULT NULL,
  `group` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `carthief_delay` bigint NOT NULL,
  `jail` int DEFAULT NULL,
  `apps` text COLLATE utf8mb4_bin,
  `widget` text COLLATE utf8mb4_bin,
  `bt` text COLLATE utf8mb4_bin,
  `charinfo` text COLLATE utf8mb4_bin,
  `metadata` mediumtext COLLATE utf8mb4_bin,
  `cryptocurrency` longtext COLLATE utf8mb4_bin,
  `cryptocurrencytransfers` text COLLATE utf8mb4_bin,
  `status` longtext COLLATE utf8mb4_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


CREATE TABLE IF NOT EXISTS `user_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `characterId` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `number` char(50) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


CREATE TABLE IF NOT EXISTS `user_licenses` (
  `Identifier` varchar(50) DEFAULT NULL,
  `owner` int DEFAULT NULL,
  `type` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `user_quests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `characterId` varchar(50) NOT NULL,
  `quests` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `user_races` (
  `name` varchar(50) NOT NULL,
  `time` double NOT NULL,
  `race` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `user_whitelist` (
  `identifier` varchar(255) NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `model` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `price` int NOT NULL,
  `category` varchar(60) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2147483648 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

REPLACE INTO `vehicles` (`id`, `name`, `model`, `price`, `category`) VALUES
	(6, 'Audi 80b4', '80b4', 780000, 'audi'),
	(7, 'Audi A4', 'aaq4', 470000, 'audi'),
	(8, 'Audi A8', 'q820', 720000, 'audi'),
	(9, 'Audi quattro 1974', 'audquattros', 740000, 'audi'),
	(10, 'Audi R8 gammal', 'r8ppi', 500000, 'audi'),
	(12, 'Audi S8D2', 's8d2', 240000, 'audi'),
	(13, 'Audi sq7 ', 'sq72016', 800000, 'audi'),
	(14, 'Audi ttrs', 'ttrs', 492000, 'audi'),
	(15, 'Audi RS318', 'rs318', 1400000, 'audi'),
	(16, '1997 BMW M3 E36', 'm3e36', 420000, 'bmw'),
	(17, '2004 BMW 760Li Individual (E66/PFL)', '760li04', 642700, 'bmw'),
	(18, '2008 BMW M3 e92', 'm3e92', 894700, 'bmw'),
	(19, 'BMW X5 E53 2005 Sport Package', 'x5e53', 871900, 'bmw'),
	(20, 'Bmw e34 1994', 'e34', 184000, 'bmw'),
	(21, 'Bmw i8', 'i8', 600000, 'bmw'),
	(22, 'Bmw m2 ', 'm2', 250000, 'bmw'),
	(23, 'Bmw m3', 'm3f80', 450000, 'bmw'),
	(25, 'Bmw m4', 'm4f82', 400000, 'bmw'),
	(26, 'Bmw m5', 'bmci', 500000, 'bmw'),
	(27, 'Bmw m5 combi', '16m5', 800000, 'bmw'),
	(28, 'Bmw m6', 'm6f13', 1400000, 'bmw'),
	(29, 'Bmw m8', 'bmwm8', 2400000, 'bmw'),
	(30, 'Bmw z4 19 ', 'z419', 1200000, 'bmw'),
	(33, 'Chevrolet Tahoe', '09tahoe', 573400, 'chevrolet'),
	(34, 'Chevrolet Camaro SS', '2020ss', 200000, 'chevrolet'),
	(35, 'Chevrolet Camaro', 'zl12017', 720000, 'chevrolet'),
	(36, 'Camaro cab rs 17', 'camrs17', 840000, 'chevrolet'),
	(37, 'Chevrolet Trailboss', '20trailboss', 740000, 'chevrolet'),
	(38, 'Chevrolet Tahoe2 ', 'tahoe', 174000, 'chevrolet'),
	(39, 'Chevrolet tahoe 2015', '15tahoe', 780000, 'chevrolet'),
	(40, 'Chevrolet tahoe 2021', 'tahoe21', 721000, 'chevrolet'),
	(41, 'Chevrolet Ram offroad extreme', '19ramoffroad', 871000, 'chevrolet'),
	(42, 'Corvette c5z06', 'corvettec5z06', 810000, 'corvette'),
	(43, 'Corvette c7', 'c7', 1240000, 'corvette'),
	(44, 'Corvette c8', 'c8', 1200000, 'corvette'),
	(45, 'Corvette czr1', 'czr1', 720000, 'corvette'),
	(51, '1999 Dodge Viper GTS ACR', '99viper', 821000, 'dodge'),
	(52, '2015 Dodge RAM 2500', 'ram2500', 774000, 'dodge'),
	(53, '2017 Dodge RAM 1500 Rebel TRX', 'trx', 1234000, 'dodge'),
	(54, '2018 Dodge Challenger SRT', 'demon', 1182000, 'dodge'),
	(57, 'Dodge Neon SRT-4', 'srt4', 647100, 'dodge'),
	(58, 'Dodge Challenger', '16challenger', 740000, 'dodge'),
	(59, 'Dodge Charger', '16charger', 1400000, 'dodge'),
	(60, 'Dodge Charger 1969', '69charger', 787000, 'dodge'),
	(62, '2015 Ford Mustang GT 50 Years Special Edition', 'mustang50th', 1724000, 'ford'),
	(63, 'Ford 150', 'f150', 710000, 'ford'),
	(64, 'Ford f-150 1978', 'f15078', 140000, 'ford'),
	(65, 'Ford gt ', 'gt17', 1150000, 'ford'),
	(66, 'Ford wildtrak', 'wildtrak', 740000, 'ford'),
	(67, 'Ford gt 1994', 'fgt', 1700000, 'ford'),
	(68, 'Mustang gt', 'MGT', 800000, 'ford'),
	(69, 'Buccaneer2', 'buccaneer2', 100000, 'gang'),
	(70, 'Chino', 'chino2', 100000, 'gang'),
	(71, 'Faction', 'faction2', 100000, 'gang'),
	(72, 'MoonBeam', 'moonbeam2', 100000, 'gang'),
	(73, 'Van', 'minivan2', 100000, 'gang'),
	(74, 'Virgo', 'virgo2', 100000, 'gang'),
	(75, '2001 Honda Civic Type-R (EP3)', 'ep3', 197000, 'honda'),
	(76, 'Honda CRX SiR 1991', 'honcrx91', 72000, 'honda'),
	(77, 'Honda S2000 AP2', 'ap2', 172400, 'honda'),
	(78, 'Honda civic', 'fk8', 470000, 'honda'),
	(79, 'Honda na1', 'na1', 570000, 'honda'),
	(82, 'Jaguar fpace', 'fpacehm', 1400000, 'jaguar'),
	(83, 'Jeep Renegade', 'jeepreneg', 527000, 'jeep'),
	(84, 'Jeep srt8', 'srt8', 1400000, 'jeep'),
	(85, 'Jeep trackhawk', 'trhawk', 1700000, 'jeep'),
	(86, 'Jeep wrangler', '18rubicon', 147000, 'jeep'),
	(87, 'Jeep wrangler 2012', 'jeep2012', 470000, 'jeep'),
	(94, 'Madza drag race', 'dragfd', 924000, 'madza'),
	(95, 'Madza gls se drift', '84rx7k', 347000, 'madza'),
	(96, 'Madza na6', 'na6', 327000, 'madza'),
	(97, 'Madza rx7', 'fc3s', 527000, 'madza'),
	(98, 'Madza rx7 2016', 'majfd', 987000, 'madza'),
	(99, 'Mazda miata turbo', 'miata3', 1274000, 'madza'),
	(100, 'Maserati levante', 'levante', 2100000, 'maserati'),
	(112, 'Mitsubishi fto drift', 'fto', 477000, 'mitsubishi'),
	(113, 'Mitsubishi lancer', 'cp9a', 634000, 'mitsubishi'),
	(114, '1997 Nissan Patrol Super Safari Y60', 'safari97', 184000, 'nissan'),
	(115, '1998 Nissan Silvia K', 's14', 327000, 'nissan'),
	(116, '2017 Nissan Titan Warrior', 'nissantitan17', 642000, 'nissan'),
	(117, '2017 R35 Nissan GTR Convertible', 'gtrc', 1124000, 'nissan'),
	(118, 'Nissan 180SX Type-X', '180sx', 272400, 'nissan'),
	(119, 'Nissan 300ZX Z32', 'z32', 518000, 'nissan'),
	(121, 'Nissan Fairlady Z Z33', 'maj350', 813500, 'nissan'),
	(122, 'Nissan Silvia S15 Spec-R', 'nis15', 417400, 'nissan'),
	(123, 'Nissan gtr', 'gtr', 600000, 'nissan'),
	(124, 'Nissan gtr 2043', 'elva', 3175000, 'nissan '),
	(125, 'Nissan Skyline', 'skyline', 240000, 'nissan'),
	(126, '1978 Porsche 935 Moby Dick', 'maj935', 800000, 'porsche'),
	(127, 'Porsche 718caymans', '718caymans', 800000, 'porsche'),
	(128, 'Porsche 911', 'p911r', 960000, 'porsche'),
	(129, 'Porsche PGT3', 'pgt3', 800000, 'porsche'),
	(130, 'Porsche carrera gt', 'cgt', 560000, 'porsche'),
	(131, 'Porsche cayman', 'pcs18', 650000, 'porsche'),
	(132, 'Porsche macan', 'pm19', 750000, 'porsche'),
	(133, 'Porsche panamera turbo', 'panamera17turbo', 1000000, 'porsche'),
	(134, 'Porsche race 1994', 'pcs18', 900000, 'porsche'),
	(135, 'Porsche taycan', 'taycan', 600000, 'porsche'),
	(136, 'Range rover evoque', 'rrevoque', 980000, 'range rover'),
	(137, 'Range rover svr 2016', 'rsvr16', 800000, 'range rover'),
	(138, 'Range rover velar', 'rrst', 950000, 'range rover'),
	(139, 'Golf Bil', 'caddy', 240000, 'special'),
	(140, '1996 Subaru Alcyone SVX', 'svx', 97000, 'subaru'),
	(141, '2004 Subaru Impreza WRX STI', 'subwrx', 278000, 'subaru'),
	(143, '1998 Toyota Supra Turbo drift', 'toysupmk4', 779700, 'toyota'),
	(144, '2018 Toyota Camry XSE', 'cam8tun', 239100, 'toyota'),
	(145, 'Toyota GT', 'gt86', 300000, 'toyota'),
	(146, 'Toyota cruiser 2020', 'cruisersj', 800000, 'toyota'),
	(147, 'Toyota supra', 'a80', 600000, 'toyota'),
	(149, 'Toyota Tourer ', 'mk2100', 120000, 'toyota'),
	(150, 'Toyota vxr', 'vxr', 100000, 'toyota'),
	(151, 'Volkswagen amarok', 'amarok', 400000, 'volkswagen'),
	(154, 'Volvo 145', 'volvo145', 50000, 'volvo'),
	(155, 'Volvo 242 Turbo', 'v242', 45000, 'volvo'),
	(156, 'Volvo 740 ', 'buffalo', 20000, 'volvo'),
	(157, 'Volvo 850', 'volvo850r', 25000, 'volvo'),
	(158, 'Volvo 940', '940fk', 35000, 'volvo'),
	(159, 'Volvo 945', '940stv', 40000, 'volvo'),
	(160, 'Volvo S60 ', 's60pole', 60000, 'volvo'),
	(161, 'Volvo V60 ', 'v60', 300000, 'volvo'),
	(168, 'Ferrari 488 Spider', '488', 600000, 'ferrari'),
	(169, 'Mercedes 63LB', '63lb', 920000, 'mercedes'),
	(170, 'McLaren 650S Coupe', '650s', 780000, 'mclaren'),
	(171, 'McLaren 675LT Coupe', '675lt', 700000, 'mclaren'),
	(172, 'McLaren 720S', '720s', 800000, 'mclaren'),
	(173, 'Koenigsegg Agera RS', 'agerars', 3100000, 'koenigsegg'),
	(174, 'Mercedes AMG GTR', 'amggtrr20', 900000, 'mercedes'),
	(175, 'Audi RS6', 'audirs6tk', 1000000, 'audi'),
	(176, 'Mercedes Brabus 800 standard', 'b800', 800000, 'mercedes'),
	(177, 'Bentley Startech', 'bentaygast', 900000, 'bentley'),
	(179, 'Bugatti Veyron', 'bugatti', 400000, 'bugatti'),
	(180, 'Mercedes C6320', 'c6320', 800000, 'mercedes'),
	(181, 'Bentley CGT Cab', 'cgts', 700000, 'bentley'),
	(182, 'Rolls & Royce Dawnonyx', 'dawnonyx', 800000, 'rolls'),
	(183, 'Bugatti Divo', 'divo', 3000000, 'bugatti'),
	(184, 'Mercedes E400', 'e400', 800000, 'mercedes'),
	(185, 'Mercedes E63 AMG', 'e63amg', 700000, 'mercedes'),
	(186, 'Mercedes E63B Brabus', 'e63b', 800000, 'mercedes'),
	(187, 'Ferrari F430s', 'f430s', 600000, 'ferrari'),
	(188, 'Ferrari 812', 'f812', 700000, 'ferrari'),
	(189, 'Ferrari California T', 'fct', 900000, 'ferrari'),
	(190, 'Ferrari FXX-K Hybrid Hypercar', 'fxxk', 800000, 'ferrari'),
	(191, 'Mercedes 6x6', 'G63AMG6x6', 500000, 'mercedes'),
	(192, 'Mercedes G65 AMG', 'g65amg', 3000000, 'mercedes'),
	(193, 'Koenigsegg Gemera', 'gemera', 3200000, 'koenigsegg'),
	(194, 'Mercedes GL63', 'gl63', 700000, 'mercedes'),
	(195, 'McLaren F1 GTR', 'gtr96', 600000, 'mclaren '),
	(196, 'Lamborghini Huracan Super Trofeo', 'huracanst', 600000, 'lamborghini'),
	(197, 'Koenigsegg Jesko', 'jesko2020', 3000000, 'koenigsegg'),
	(198, 'Ferrari LaFerrari', 'laferrari', 1000000, 'ferrari'),
	(199, 'Lamborghini Sesto Elemento', 'lambose', 900000, 'lamborghini'),
	(200, 'Lamborghini Trimmad', 'lp670sv', 1200000, 'lamborghini'),
	(201, 'Lamborghini Aventador LP700-4 Roadster', 'lp700r', 800000, 'lamborghini'),
	(202, 'Mercedes E63', 'mbc63', 800000, 'mercedes'),
	(203, 'Ferrari Enzo', 'mig', 600000, 'ferrari'),
	(204, 'McLaren MP4-12C', 'mp412c', 1000000, 'mclaren '),
	(205, 'Mclaren widebody 2020', 'p1lm', 2500000, 'mclaren'),
	(206, 'Tesla Model X Unplugged Performance', 'p90d', 500000, 'tesla'),
	(207, 'Ferrari Pista', 'PD458WB', 1000000, 'ferrari'),
	(208, 'Audi R8 2020', 'r820', 600000, 'audi'),
	(209, 'Mercedes Brabus 800 widebody', 'rmode63s', 800000, 'mercedes'),
	(210, 'Mercedes GT63', 'rmodgt63', 800000, 'mercedes'),
	(211, 'Rolls & Royce Phantom', 'rrphantom', 500000, 'rolls'),
	(212, 'Audi RS7', 'RS72020', 1200000, 'audi'),
	(213, 'Mercedes S500W222', 's500w222', 700000, 'mercedes'),
	(214, 'McLaren Senna', 'senna', 700000, 'mclaren '),
	(215, 'Mercedes SL500', 'sl500', 350000, 'mercedes'),
	(216, 'Tesla Model S Prior', 'teslapd', 500000, 'tesla'),
	(217, 'Tesla Model X', 'teslax', 670000, 'tesla'),
	(218, 'Mercedes V250', 'v250', 500000, 'mercedes'),
	(219, 'Rolls & Royce Wraith', 'wraith', 500000, 'rolls'),
	(220, 'Bmw X6', 'x6m', 900000, 'bmw'),
	(221, 'Mercedes Yachting', 'yachting', 890000, 'mercedes'),
	(222, 'Kawasaki ninja H2R', 'nh2r', 1000000, 'mc'),
	(223, 'KTM Duke 1000', 'ksd', 830000, 'mc'),
	(2333, 'Saab 95', 'stanier', 594700, 'saab'),
	(23112, 'Volvo 850r', 'stratum', 35000, 'volvo'),
	(23113, '1932 Ford V-8', 'fordc32', 500000, 'ford'),
	(32111, 'Mercedes Benz E55 AMG', 'benze55', 780000, 'mercedes'),
	(43434, 'BMW 327 Turbo', '325et', 300000, 'bmw'),
	(45453, 'Impala', 'impala64', 890000, 'chevrolet'),
	(53535, 'Volvo Epa 1', 'epa1', 160000, 'volvo'),
	(343434, 'Saab 93', 'saab93', 394700, 'saab'),
	(434343, 'Rs7 beast', 'rs7beast', 890000, 'audi'),
	(563535, 'Volvo epa 4', 'epa4', 160000, 'volvo'),
	(666666, 'Rolls & Royce Barn', 'PV_dawn', 2147483647, 'rolls'),
	(764644, 'Volvo Epa 3', 'epa3', 160000, 'volvo'),
	(5634534, 'Volvo Epa 2', 'epa2', 160000, 'volvo'),
	(6666667, 'Bmw barn', 'PV_bmwe36', 2147483647, 'bmw');

CREATE TABLE IF NOT EXISTS `vehicles1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `model` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `price` int NOT NULL,
  `category` varchar(60) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2147483648 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

REPLACE INTO `vehicles1` (`id`, `name`, `model`, `price`, `category`) VALUES
	(1, 'Kawasaki ninja h2r', 'nh2r', 1000000, 'mc'),
	(2, 'Wolfsbane mc', 'wolfsbane', 50000, 'mc'),
	(3, 'Honda Wave110i', 'nemesis', 75000, 'mc'),
	(4, 'Honda titan 80hk', 'manchez', 35000, 'mc'),
	(5, 'Yamaha Tmax 2020', 'tmaxdx', 1330000, 'mc'),
	(6, 'BMX', 'bmx', 9000, 'cykel'),
	(8, 'Scorcher', 'scorcher', 7000, 'cykel'),
	(9, 'Fixter', 'fixter', 7000, 'cykel'),
	(10, 'Cruiser', 'cruiser', 7000, 'cykel'),
	(11, 'Yamaha YZF 450 ATV', 'blazer3', 970000, 'mc'),
	(13, 'Suzuki RM250 -08', '08rm250', 590000, 'mc'),
	(14, 'Templar', 'templar', 900000, 'mc'),
	(15, '1998 Yamaha YZF-R1 Limited edition', 'r11998', 250000, 'mc'),
	(16, '1987 Yamaha Banshee', 'banshee87', 150000, 'mc'),
	(17, 'Honda CB750 Chopper', 'CB750', 55000, 'mc'),
	(18, 'Skidoo 800', 'skidoo800R', 150000, 'skoter'),
	(19, 'Slave', 'slave', 87000, 'mc'),
	(20, 'Templar2', 'templar2', 900000, 'mc'),
	(21, 'Fox RK', 'foxrk', 1400000, 'mc'),
	(5454, 'Harley Davidson Daemon', 'daemon', 1400000, 'mc'),
	(64646, 'g63nt', 'g63nt', 657868878, 'sÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½lj'),
	(65656, 'Ktm ksd 125', 'ksd', 830000, 'mc'),
	(432423, 'Alfa Romeo 1750', 'AR1750GTV', 46000, 'bilar'),
	(443242, 'Briso 300', 'Brioso', 36000, 'bilar'),
	(756757, 'Acknod Hoj', 'na25', 75000, 'mc'),
	(4345234, 'Regina', 'regina', 100000, 'bilar'),
	(67464643, 'JB700', 'JB700', 230000, 'bilar');

CREATE TABLE IF NOT EXISTS `vehiclestopsar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `model` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `price` int NOT NULL,
  `category` varchar(60) COLLATE utf8mb4_bin DEFAULT NULL,
  `namn` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=781 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

REPLACE INTO `vehiclestopsar` (`id`, `name`, `model`, `price`, `category`, `namn`) VALUES
	(21, 'Camaro zl12017', 'zl12017', 135000, 'camaro', NULL),
	(23, 'Piaggio NRG Power 70cc 2-takt', 'nrg', 15000, 'motorcyklar', NULL),
	(38, 'KTM EXC 530', 'exc530', 30000, 'motorcyklar', NULL),
	(41, 'Honda CBR1000RR', 'hcbr17', 350000, 'honda', NULL),
	(52, 'Audi RS5', 'rs5', 670000, 'audi', NULL),
	(53, 'C63 AMG - Widebody', 'rmodamgc63', 1460000, 'mercedes', NULL),
	(66, 'Audi RS7 2013', '2013rs7', 850000, 'audi', NULL),
	(67, 'Mercedes S63 AMG', 's63w222', 1100000, 'mercedes', NULL),
	(68, 'BMW M5 F90', 'BMCI', 1000000, 'bmw', NULL),
	(75, 'Volvo 850R', 'v850r', 120000, 'volvo', NULL),
	(77, 'Audi S4 Avant', 's4a', 360000, 'audi', NULL),
	(79, 'Audi RS3', 'rs318', 400000, 'audi', NULL),
	(80, 'Audi RS6 2020', 'rs62', 2000000, 'audi', NULL),
	(176, 'Lamborghini HuracÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½n Performante', '18performante', 4400000, 'lamborghini', NULL),
	(218, 'Petrovsen', 'taco', 7500, 'firma', NULL),
	(242, 'Daemon', 'daemon2', 15000, 'firma', NULL),
	(243, 'Polackbygge AB', 'burrito', 15000, 'firma', NULL),
	(246, 'Chevrolet Corvette C7', 'c7', 280000, 'chevrolet', NULL),
	(247, 'Cadillac Escalade', 'esv', 380000, 'cadillac', NULL),
	(248, 'Mercedes Benz G65', 'g65amg', 835000, 'mercedes', NULL),
	(250, 'Mercedes-Benz CLA 45 AMG', 'cla45sb', 790000, 'mercedes', NULL),
	(251, 'Ford F150 Raptor', 'raptor12', 140000, 'ford', NULL),
	(252, 'Honda GL1800', 'goldwing', 90000, 'honda', NULL),
	(253, 'Harley Davidson V-Rod', 'hvrod', 132000, 'motorcyklar', NULL),
	(254, 'Suzuki Hayabusa Drag', 'hyabusadrag', 180000, 'motorcyklar', NULL),
	(255, 'Yamaha R1', 'r1', 245000, 'yamaha', NULL),
	(257, 'BMW 440IX', '440i', 290000, 'bmw', NULL),
	(258, 'Mercedes-Benz C63', 'c63', 765000, 'mercedes', NULL),
	(264, 'Porsche 911 Turbo S', '911turbos', 1900000, 'porsche', NULL),
	(265, 'Audi R8', 'r820', 2750000, 'audi', NULL),
	(266, 'BMW Z4 M40i', 'z419', 650000, 'bmw', NULL),
	(268, 'Bentley Bentayga Startech', 'bentaygast', 800000, 'bentley', NULL),
	(269, 'Ferrari 812 Superfast', 'f812', 3650000, 'ferrari', NULL),
	(270, 'Ford Mustang GT', 'mgt', 420000, 'ford', NULL),
	(271, 'GMC Sierra 1500 Crew Cab', 'gmcs', 360000, 'gmc', NULL),
	(272, 'Nissan 370Z Nismo Z34', '370z', 380000, 'nissan', NULL),
	(273, 'Porsche Cayenne Turbo S', 'cayenne', 1000000, 'porsche', NULL),
	(276, 'Jeep Wrangler Rubicon', 'rubi3d', 270000, 'jeep', NULL),
	(277, 'Diablous', 'diablous', 17500, 'motorcyklar', NULL),
	(278, 'BMW X6M', 'x6m', 850000, 'bmw', NULL),
	(279, 'Derbi Senda 70cc', 'derbi', 10000, 'motorcyklar', NULL),
	(280, 'Aftonbladet', 'rumpo', 20000, 'firma', NULL),
	(283, 'BF400', 'bf400', 15000, 'motorcyklar', NULL),
	(284, 'Sovereign MC BOSS', 'sovereign', 15000, 'firma', NULL),
	(287, 'MC Sanctus', 'sanctus', 15000, 'firma', NULL),
	(289, 'Nissan Skyline', 'skyline', 900000, 'nissan', NULL),
	(291, 'Rolls Royce Wraith', 'wraith', 4900000, 'rollsroyce', NULL),
	(292, 'Audi RS7 2018', 'rs7r', 1000000, 'audi', NULL),
	(293, 'Volvo XC90', 'xc90', 450000, 'volvo', NULL),
	(294, 'Porsche Panamera Turbo', 'grandgt18', 1600000, 'porsche', NULL),
	(295, 'Lowrider Bike', 'lowriderb', 3000, 'cykel', NULL),
	(296, 'Tesla Model X', 'teslax', 1550000, 'tesla', NULL),
	(297, 'RS6 2009 Model', 'rs6sedan', 90000, 'audi', NULL),
	(305, 'KIA Sorento 2019', 'sorento19', 100000, 'kia', NULL),
	(306, 'Mercedes-Benz S600', 's600w220', 30000, 'mercedes', NULL),
	(308, 'Ferrari 488', '488NLARGO', 3500000, 'ferrari', NULL),
	(309, 'Yamaha Aerox 155', 'aeroxdrag', 200000, 'yamaha', NULL),
	(311, 'Tesla Roadster 2020', 'tr22', 3800000, 'tesla', NULL),
	(312, 'Volvo S60', 's60pole', 530000, 'volvo', NULL),
	(313, 'Rolls-royce cullinan mansory', 'manscull', 4600000, 'rollsroyce', NULL),
	(314, '2020 Yamaha X-MAX', '20xmax', 200000, 'motorcyklar', NULL),
	(315, 'BMW Alpina B7', 'alpinab7', 1000000, 'bmw', NULL),
	(318, 'Bugatti Chiron 2017', '2017chiron', 4900000, 'bugatti', NULL),
	(319, 'Impala 64', 'impala64', 150000, 'impala', NULL),
	(320, 'SAAB 9-3', 'saab93', 90000, 'saab', NULL),
	(321, 'Bentley 2017', 'BEN17', 1650000, 'bentley', NULL),
	(323, 'BMW e30', 'M3E30', 160000, 'bmw', NULL),
	(324, 'Koenigsegg Agera', 'agerars', 4700000, 'koenigsegg', NULL),
	(325, 'Ferrari 488 misha', '488misha', 4000000, 'ferrari', NULL),
	(326, 'Mercedes AMG 488', 'rmodgt63', 2300000, 'mercedes', NULL),
	(327, 'Mercedes c63', 'c63tmodel', 650000, 'mercedes', NULL),
	(329, 'Mercedes Benz C Class', 'MCEC', 35000, 'mercedes', NULL),
	(330, 'Jeep 18 Rubicon', '18rubicon', 295000, 'jeep', NULL),
	(332, 'Templar', 'templar', 200000, 'motorcyklar', NULL),
	(333, 'Chevrolet G20', 'G20C', 180000, 'chevrolet', NULL),
	(339, 'Acura TL Type-S', 'tltypes', 80000, 'acura', NULL),
	(340, 'Aston Martin DBX', 'amdbx', 570000, 'astonmartin', NULL),
	(341, '2013 Aston Martin Vanquish', 'ast', 990000, 'astonmartin', NULL),
	(342, '1995 Audi Cabriolet', '80B4', 40000, 'audi', NULL),
	(343, '2017 Audi A4 Quattro', 'aaq4', 110000, 'audi', NULL),
	(344, '1983 Audi Quattro Sport', 'audquattros', 190000, 'audi', NULL),
	(345, '2013 Audi R8 V10', 'r8ppi', 790000, 'audi', NULL),
	(346, '2016 Audi RS6 C7', 'rs6', 230000, 'audi', NULL),
	(347, '2020 Audi RS7', 'rs72020', 1730000, 'audi', NULL),
	(348, '1998 Audi S8', 's8d2', 55000, 'audi', NULL),
	(349, '2016 Audi SQ7', 'sq72016', 390000, 'audi', NULL),
	(350, '2010 Audi TT RS', 'ttrs', 140000, 'audi', NULL),
	(351, '2020 Bentley Continental', 'cgts', 940000, 'bentley', NULL),
	(352, '2004 BMW 760Li', '760li04', 100000, 'bmw', NULL),
	(353, '1995 BMW M5 E34', 'e34', 66000, 'bmw', NULL),
	(354, '2016 BMW M2', 'm2', 446000, 'bmw', NULL),
	(355, '1997 BMW M3 E36', 'm3e36', 46000, 'bmw', NULL),
	(356, '2008 BMW M3 e92', 'm3e92', 556000, 'bmw', NULL),
	(357, '2015 BMW M3', 'm3f80', 656000, 'bmw', NULL),
	(358, '2015 BMW M4 F82', 'm4f82', 670000, 'bmw', NULL),
	(359, 'BMW M6 F13 Shadow', 'm6f13', 470000, 'bmw', NULL),
	(360, '2019 BMW Z4', 'z419', 700000, 'bmw', NULL),
	(361, '2020 Bugatti Bolide', 'bolide', 5700000, 'bugatti', NULL),
	(362, '2016 Cadillac ATS-V', 'cats', 200000, 'cadillac', NULL),
	(363, '2021 Cadillac Escalade', 'cesc21', 450000, 'cadillac', NULL),
	(364, '2009 Chevrolet Tahoe', '09tahoe', 250000, 'chevrolet', NULL),
	(365, '2015 Chevrolet Tahoe', '15tahoe', 350000, 'chevrolet', NULL),
	(366, '2021 Chevrolet Tahoe RST', 'camrs17', 470000, 'chevrolet', NULL),
	(367, '2020 Chevrolet Corvette C8', 'c8', 1170000, 'chevrolet', NULL),
	(368, '2020 Chevrolet Camaro SS', '2020ss', 690000, 'chevrolet', NULL),
	(369, 'Chevrolet Corvette C5', 'corvettec5z06', 230000, 'chevrolet', NULL),
	(370, '2009 Chevrolet Corvette', 'czr1', 320000, 'chevrolet', NULL),
	(371, '2016 Dodge Charger', '16charger', 550000, 'dodge', NULL),
	(372, 'Dodge Charger Hellcat Widebody 2021', 'chr20', 510000, 'dodge', NULL),
	(374, 'Ferrari 488 Spider', '488', 3900000, 'ferrari', NULL),
	(375, 'Ferrari F430 Scuderia', 'f430s', 3650000, 'ferrari', NULL),
	(376, '2018 Ferrari 812', 'f812', 950000, 'ferrari', NULL),
	(377, '2015 Ferrari California', 'fct', 1010000, 'ferrari', NULL),
	(378, 'Ferrari FXX-K', 'fxxk', 3700000, 'ferrari', NULL),
	(379, '2015 Ferrari LaFerrari', 'laferrari', 2000000, 'ferrari', NULL),
	(380, 'Ferrari Enzo', 'mig', 3900000, 'ferrari', NULL),
	(381, 'Ferrari 458', 'yFe458i1', 2900000, 'ferrari', NULL),
	(382, 'Ferrari 458 Spider', 'yFe458i2', 2900000, 'ferrari', NULL),
	(383, 'Ferrari Speciale', 'yFe458s1X', 3010000, 'ferrari', NULL),
	(384, 'Ferrari Aperta', 'yFe458s2X', 1000000, 'ferrari', NULL),
	(385, '2012 Ford F150', 'f150', 180000, 'ford', NULL),
	(386, '1978 Ford F150 XLT', 'f15078', 80000, 'ford', NULL),
	(387, '2005 Ford GT', 'fgt', 480000, 'ford', NULL),
	(388, '2017 Ford GT', 'gt17', 1180000, 'ford', NULL),
	(391, '2021 Ford Bronco', 'wildtrak', 460000, 'ford', NULL),
	(393, 'Honda S2000 AP2', 'ap2', 320000, 'honda', NULL),
	(394, '2001 Honda Civic', 'ep3', 45000, 'honda', NULL),
	(395, '2018 Honda Civic', 'fk8', 295000, 'honda', NULL),
	(396, 'Honda CRX SiR 1991', 'honcrx91', 27000, 'honda', NULL),
	(397, '1992 Honda NSX-R', 'na1', 309000, 'honda', NULL),
	(398, '2017 Italdesign Zerouno', 'it18', 1000000, 'italdesign', NULL),
	(399, 'Jaguar F-pace 2017', 'fpacehm', 570000, 'jaguar', NULL),
	(400, '2012 Jeep Wrangler', 'jeep2012', 170000, 'jeep', NULL),
	(401, 'Jeep Renegade', 'jeepreneg', 200000, 'jeep', NULL),
	(402, '2015 Jeep SRT-8', 'srt8', 150000, 'jeep', NULL),
	(403, '2018 Jeep Grand Cherokee', 'trhawk', 200000, 'jeep', NULL),
	(404, 'Koenigsegg Regara', 'regera', 1700000, 'koenigsegg', NULL),
	(405, 'Lamborghini Huracan', 'huracanst', 3500000, 'lamborghini', NULL),
	(406, 'Lamborghini Sesto', 'lambose', 3600000, 'lamborghini', NULL),
	(407, '2013 Lamborghini Aventador', 'lp700r', 1500000, 'lamborghini', NULL),
	(408, 'Lamborghini Aventador SVJ', 'svj63', 7500000, 'lamborghini', NULL),
	(409, 'Lexus GS 350', 'gs350', 120000, 'lexus', NULL),
	(410, '2014 Lexus IS 350', 'is350mod', 70000, 'lexus', NULL),
	(411, '2015 Lexus RCF', 'rcf', 95000, 'lexus', NULL),
	(412, '1973 Land Rover Range', 'lrrr', 150000, 'rangerover', NULL),
	(413, '2002 Lotus Esprit V8', 'esprit02', 390000, 'rangerover', NULL),
	(414, 'Quartz Regalia 723', 'regalia', 6990000, 'quartzregalia', NULL),
	(415, 'Maserati Levante', 'levante', 199000, 'maserati', NULL),
	(416, '1984 Mazda RX-7', '84rx7k', 200000, 'mazda', NULL),
	(417, '2002 Mazda RX-7 FD', 'dragfd', 550000, 'mazda', NULL),
	(418, 'Mazda RX7 FC3S', 'fc3s', 180000, 'mazda', NULL),
	(419, 'Mazda MX-5 Miata', 'na6', 100000, 'mazda', NULL),
	(420, '2020 McLaren Speedtail', 'mcst', 2750000, 'mclaren', NULL),
	(421, '2020 Mercedes-Benz AMG', 'amggtrr20', 750000, 'mercedes', NULL),
	(422, '2020 Mercedes-AMG C63s', 'c6320', 390000, 'mercedes', NULL),
	(423, '2013 Mercedes-Benz G65 AMG', 'G65', 420000, 'mercedes', NULL),
	(424, '2019 Mercedes-Benz E400', 'e400', 370000, 'mercedes', NULL),
	(425, 'Mercedes-Benz GL63 AMG', 'gl63', 1020000, 'mercedes', NULL),
	(426, '2012 Mercedes-Benz C63', 'mbc63', 900000, 'mercedes', NULL),
	(427, '2014 Mercedes-Benz S500', 's500w222', 560000, 'mercedes', NULL),
	(428, '1995 Mercedes-Benz SL500', 'sl500', 60000, 'mercedes', NULL),
	(430, 'Mitsubishi Lancer Evo', 'cp9a', 230000, 'mitsubishi', NULL),
	(431, 'Mitsubishi FTO GP', 'fto', 90000, 'mitsubishi', NULL),
	(432, 'Nissan 180SX Type-X', '180sx', 130000, 'nissan', NULL),
	(433, '2017 Nissan GTR', 'gtr', 950000, 'nissan', NULL),
	(434, '2017 R35 Nissan GTR', 'gtrc', 660000, 'nissan', NULL),
	(435, 'Nissan Fairlady Z Z33', 'maj350', 360000, 'nissan', NULL),
	(436, 'Nissan Silvia', 'nis15', 200000, 'nissan', NULL),
	(437, '2017 Nissan Titan', 'nissantitan17', 490000, 'nissan', NULL),
	(438, 'Nissan 350z Stardast', 'ns350', 400000, 'nissan', NULL),
	(439, 'Nissan 370z', 'nzp', 300000, 'nissan', NULL),
	(440, '1998 Nissan Silvia', 's14', 200000, 'nissan', NULL),
	(441, '1997 Nissan Patrol', 'Safari97', 120000, 'nissan', NULL),
	(442, 'Nissan 300ZX Z32', 'z32', 80000, 'nissan', NULL),
	(443, 'Porsche 718 Cayman S', '718caymans', 1580000, 'porsche', NULL),
	(444, '2003 Porsche Carrera GT', 'cgt', 1100000, 'porsche', NULL),
	(445, '1978 Porsche 935', 'maj935', 1500000, 'porsche', NULL),
	(446, '2018 Porsche Cayenne S', 'pcs18', 600000, 'porsche', NULL),
	(447, '2019 Porsche Macan', 'pm19', 800000, 'porsche', NULL),
	(448, '2020 Porsche Taycan', 'taycan', 2300000, 'porsche', NULL),
	(449, 'Range Rover Evoque', 'rrevoque', 500000, 'rangerover', NULL),
	(450, 'Range Rover Vogue', 'rrst', 850000, 'rangerover', NULL),
	(451, '2016 Range Rover Sport', 'rsvr16', 550000, 'rangerover', NULL),
	(452, '2016 Rolls-Royce Dawn', 'dawnonyx', 4500000, 'rollsroyce', NULL),
	(453, 'Rolls Royce Cullinan	', 'rculi', 8350000, 'rollsroyce', NULL),
	(454, '2018 Rolls-Royce Phantom', 'rrphantom', 5550000, 'rollsroyce', NULL),
	(455, '2008 Subaru WRX STi', 'subisti08', 210000, 'subaru', NULL),
	(457, '2004 Subaru Impreza', 'subwrx', 220000, 'subaru', NULL),
	(458, '1996 Subaru Alcyone', 'svx', 45000, 'subaru', NULL),
	(459, '2018 Toyota Camry', 'cam8tun', 145000, 'toyota', NULL),
	(460, '1998 Toyota Supra', 'toysupmk4', 200000, 'toyota', NULL),
	(461, 'Toyota Mark', 'mk2100', 75000, 'toyota', NULL),
	(462, '2016 Toyota Land Cruiser', 'vxr', 110000, 'toyota', NULL),
	(463, '2015 Volkswagen Golf', 'golfgti7', 150000, 'volkswagen', NULL),
	(464, 'W-Motors Lykan', 'lykan', 550000, 'wmotors', NULL),
	(465, 'W-Motors Fenyr', 'wmfenyr', 750000, 'wmotors', NULL),
	(466, '2013 Lamborghini Veneno', 'veneno', 6500000, 'lamborghini', NULL),
	(467, 'Bugatti Veyron', 'BUGATTI', 4100000, 'bugatti', NULL),
	(468, '2017 Hennessey Velociraptor', 'velociraptor', 780000, 'ford', NULL),
	(469, 'Yamaha TMAX 2015', 'tmaxDX', 115000, 'yamaha', NULL),
	(470, 'KTM 450 SX-F', 'sxf450sm', 95000, 'motorcyklar', NULL),
	(472, 'Tesla Model 3', 'TMODEL', 1220000, 'tesla', NULL),
	(473, 'BMW X5 E53 2005', '48IS', 120000, 'bmw', NULL),
	(474, '2019 McLaren Senna', 'senna', 1000000, 'mclaren', NULL),
	(475, 'Lamborghini Urus', 'urus', 2600000, 'lamborghini', NULL),
	(482, 'Mercedes Benz X Class', 'xxxxx', 1000000, 'mercedes', NULL),
	(483, 'Ford F350 6x6 2020', 'f350offroadspec', 290000, 'ford', NULL),
	(486, 'Toyota Supra', 'a80', 135000, 'toyota', NULL),
	(487, 'BMW 745le', '745le', 560000, 'bmw', NULL),
	(488, 'Minimoto', 'DirtBike', 12000, 'mc', NULL),
	(497, 'Benefactor Krieger', 'kriegerc', 325000, 'benefactor', NULL),
	(498, 'Isuzu Dmax', 'mux', 50000, 'isuzu', NULL),
	(499, 'Mitsubishi Evolution', 'kuruma', 200000, 'mitsubishi', NULL),
	(500, 'Peuegot 206 GTI', '206', 18000, 'peuegot', NULL),
	(501, 'Subaru WRX', 'sultan', 80000, 'subaru', NULL),
	(502, 'Volkswagen Caddy', 'caddyvw', 25000, 'volkswagen', NULL),
	(507, 'Cheif', 'cheif', 160000, 'mc', NULL),
	(508, 'Harley Davidson Road King', 'foxrk', 350000, 'mc', NULL),
	(509, 'Templar 4', 'templar4', 70000, 'mc', NULL),
	(510, 'Rascal', 'hexer', 25000, 'mc', NULL),
	(511, 'Bloodline', 'bloodline', 90000, 'mc', NULL),
	(512, 'Slave', 'slave', 30000, 'mc', NULL),
	(532, 'Tampa', 'tampa', 16000, 'muscle', NULL),
	(537, 'Brioso R/A', 'brioso', 18000, 'compacts', NULL),
	(540, 'Prairie', 'prairie', 12000, 'compacts', NULL),
	(553, 'Rumpo Trail', 'rumpo3', 119500, 'vans', NULL),
	(554, 'Surfer', 'surfer', 32000, 'vans', NULL),
	(563, 'Premier', 'premier', 8000, 'sedans', NULL),
	(564, 'Primo Custom', 'primo2', 14000, 'sedans', NULL),
	(568, 'Super Diamond', 'superd', 130000, 'sedans', NULL),
	(584, 'Mesa Trail', 'mesa3', 40000, 'suvs', NULL),
	(586, 'Radius', 'radi', 29000, 'suvs', NULL),
	(596, 'Monroe', 'monroe', 55000, 'sportsclassics', NULL),
	(597, 'Pigalle', 'pigalle', 20000, 'sportsclassics', NULL),
	(598, 'Stinger', 'stinger', 80000, 'sportsclassics', NULL),
	(599, 'Stinger GT', 'stingergt', 75000, 'sportsclassics', NULL),
	(600, 'Stirling GT', 'feltzer3', 65000, 'sportsclassics', NULL),
	(655, 'Schafter V12', 'schafter3', 50000, 'sports', NULL),
	(661, 'Adder', 'adder', 900000, 'super', NULL),
	(671, 'RE-7B', 'le7b', 325000, 'super', NULL),
	(682, 'Avarus', 'avarus', 118000, 'mc', NULL),
	(687, 'BMX (velo)', 'bmx', 500, 'cykel', NULL),
	(689, 'Chimera', 'chimera', 138000, 'motorcyklar', NULL),
	(690, 'Cliffhanger', 'cliffhanger', 129500, 'motorcyklar', NULL),
	(691, 'Cruiser (velo)', 'cruiser', 800, 'cykel', NULL),
	(692, 'Daemon', 'daemon', 111500, 'mc', NULL),
	(693, 'Daemon High', 'daemon2', 113500, 'mc', NULL),
	(697, 'Esskey', 'esskey', 114200, 'motorcyklar', NULL),
	(700, 'Fixter (velo)', 'fixter', 1525, 'cykel', NULL),
	(701, 'Gargoyle', 'gargoyle', 116500, 'mc', NULL),
	(704, 'Hexer', 'hexer', 112000, 'mc', NULL),
	(705, 'Innovation', 'innovation', 123500, 'mc', NULL),
	(708, 'Nightblade', 'nightblade', 120000, 'mc', NULL),
	(713, 'Sanctus', 'sanctus', 225000, 'mc', NULL),
	(714, 'Scorcher (velo)', 'scorcher', 1200, 'cykel', NULL),
	(715, 'Sovereign', 'sovereign', 22000, 'motorcycles', NULL),
	(716, 'Shotaro Concept', 'shotaro', 320000, 'motorcycles', NULL),
	(717, 'Thrust', 'thrust', 24000, 'motorcycles', NULL),
	(718, 'Tri bike (velo)', 'tribike3', 520, 'cykel', NULL),
	(722, 'Zombie', 'zombiea', 119000, 'mc', NULL),
	(723, 'Zombie Luxuary', 'zombieb', 112000, 'mc', NULL),
	(732, 'Rapid GT3', 'rapidgt3', 885000, 'sportsclassics', NULL),
	(733, 'raiden', 'raiden', 1375000, 'sports', NULL),
	(739, 'riata', 'riata', 380000, 'offroad', NULL),
	(741, 'Savestra', 'savestra', 990000, 'sportsclassics', NULL),
	(753, 'Yamaha YZ450F Supermoto', 'yzfsm', 17000, 'yamaha', NULL),
	(754, 'Yamaha SXF450SM', 'sxf450sm', 15000, 'mc', NULL),
	(755, 'Yamaha YZF450', 'blazer3', 32000, 'mc', NULL),
	(756, 'Yamaha XT-700', 'xt700', 226000, 'mc', NULL),
	(757, 'Yamaha XT-66', 'xt66', 38000, 'mc', NULL),
	(766, 'BMW M5 E60', 'm5e60', 100000, 'bmw', NULL),
	(768, 'BMW M4', 'f82', 230000, 'bmw', NULL),
	(769, 'Ninja H2R', 'ninjah2', 80000, 'mc', NULL),
	(771, 'BMW M8', 'bmwm8', 940000, 'bmw', NULL),
	(773, 'Dyne', 'dyne', 110000, 'mc', NULL),
	(774, 'Dyna', 'dyna', 100000, 'mc', NULL),
	(775, 'Range Rover', 'rr12', 670000, 'rangerover', NULL),
	(778, 'Opel Kadett E GSi 16V', 'opel', 13000, 'opel', NULL),
	(779, 'Opel Kadett E Sedan', 'opel2', 25000, 'opel', NULL),
	(780, 'Yamaha TMAX 2020', '20xmax', 300000, 'yamaha', NULL);

CREATE TABLE IF NOT EXISTS `vehicles_for_sale` (
  `id` int NOT NULL AUTO_INCREMENT,
  `seller` varchar(50) NOT NULL,
  `vehicleProps` longtext NOT NULL,
  `price` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `vehicle_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `label` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=563454 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

REPLACE INTO `vehicle_categories` (`id`, `name`, `label`) VALUES
	(14, 'audi', 'Audi'),
	(15, 'bentley', 'Bentley'),
	(16, 'bmw', 'BMW'),
	(17, 'bugatti', 'Bugatti'),
	(18, 'chevrolet', 'Chevrolet'),
	(19, 'dodge', 'Dodge'),
	(21, 'ford', 'Ford'),
	(22, 'lamborghini', 'Lamborghini'),
	(25, 'mc', 'MC'),
	(26, 'mclaren', 'McLaren'),
	(27, 'mercedes', 'Mercedes'),
	(28, 'nissan', 'Nissan'),
	(29, 'porsche', 'Porsche'),
	(31, 'tesla', 'Tesla'),
	(32, 'toyota', 'Toyota'),
	(33, 'volkswagen', 'Volkswagen'),
	(34, 'volvo', 'Volvo'),
	(43, 'mitsubishi', 'Mitsubishi'),
	(45, 'subaru', 'Subaru'),
	(66, 'ferrari', 'Ferrari'),
	(68, 'honda', 'Honda'),
	(71, 'jaguar', 'Jaguar'),
	(72, 'jeep', 'Jeep'),
	(74, 'koenigsegg', 'Koenigsegg'),
	(75, 'maserati', 'Maserati'),
	(78, 'ram', 'RAM'),
	(79, 'rangerover', 'Range Rover'),
	(80, 'rolls', 'Rolls Royce'),
	(81, 'saab', 'Saab'),
	(82, 'Motorcykel', 'mc'),
	(45454, 'salj', 'SÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½LJ INTE');

CREATE TABLE IF NOT EXISTS `vehicle_categories topstar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `label` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

REPLACE INTO `vehicle_categories topstar` (`id`, `name`, `label`) VALUES
	(14, 'audi', 'Audi'),
	(15, 'bentley', 'Bentley'),
	(16, 'bmw', 'BMW'),
	(17, 'bugatti', 'Bugatti'),
	(18, 'chevrolet', 'Chevrolet'),
	(19, 'dodge', 'Dodge'),
	(21, 'ford', 'Ford'),
	(22, 'lamborghini', 'Lamborghini'),
	(23, 'landrover', 'Land Rover'),
	(24, 'lexus', 'Lexus'),
	(25, 'mc', 'MC'),
	(26, 'mclaren', 'McLaren'),
	(27, 'mercedes', 'Mercedes'),
	(28, 'nissan', 'Nissan'),
	(29, 'porsche', 'Porsche'),
	(30, 'rollsroyce', 'Rolls Royce'),
	(31, 'tesla', 'Tesla'),
	(32, 'toyota', 'Toyota'),
	(33, 'volkswagen', 'Volkswagen'),
	(34, 'volvo', 'Volvo'),
	(41, 'benefactor', 'Benefactor'),
	(42, 'isuzu', 'Isuzu'),
	(43, 'mitsubishi', 'Mitsubishi'),
	(44, 'peuegot', 'Peuegot'),
	(45, 'subaru', 'Subaru'),
	(46, 'yamaha', 'Yamaha'),
	(47, 'compacts', 'Compacts'),
	(48, 'coupes', 'CoupÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½s'),
	(49, 'sedans', 'Sedans'),
	(50, 'sports', 'Sports'),
	(51, 'sportsclassics', 'Sports Classics'),
	(52, 'super', 'Super'),
	(53, 'muscle', 'Muscle'),
	(54, 'offroad', 'Off Road'),
	(55, 'suvs', 'SUVs'),
	(56, 'vans', 'Vans'),
	(57, 'motorcycles', 'Motos'),
	(62, 'acura', 'Acura'),
	(63, 'astonmartion', 'Aston Martin'),
	(64, 'cadillac', 'Cadillac'),
	(65, 'camaro', 'Camaro'),
	(66, 'ferrari', 'Ferrari'),
	(67, 'gmc', 'GMC'),
	(68, 'honda', 'Honda'),
	(69, 'impala', 'Impala'),
	(70, 'italdesign', 'Italdesign'),
	(71, 'jaguar', 'Jaguar'),
	(72, 'jeep', 'Jeep'),
	(73, 'kia', 'Kia'),
	(74, 'koenigsegg', 'Koenigsegg'),
	(75, 'maserati', 'Maserati'),
	(76, 'mazda', 'Mazda'),
	(77, 'quartzregalia', 'Quartzregalia'),
	(78, 'ram', 'RAM'),
	(79, 'rangerover', 'Range Rover'),
	(80, 'saab', 'Saab'),
	(81, 'wmotors', 'WMotors'),
	(82, 'opel', 'Opel'),
	(83, 'cykel', 'Cykel');

CREATE TABLE IF NOT EXISTS `vehicle_categories1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `label` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

REPLACE INTO `vehicle_categories1` (`id`, `name`, `label`) VALUES
	(1, 'mc', 'Mc'),
	(2, 'cykel', 'Cykel'),
	(3, 'bilar', 'Bilar'),
	(4, 'sÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½lj', 'SÃÆÃÂ¯ÃâÃÂ¿ÃâÃÂ½LJ INTE');

CREATE TABLE IF NOT EXISTS `vehicle_sold` (
  `client` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `plate` varchar(50) NOT NULL,
  `soldby` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `wavebite_ban` (
  `license` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `identifier` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `liveid` varchar(21) COLLATE utf8mb4_bin DEFAULT NULL,
  `xblid` varchar(21) COLLATE utf8mb4_bin DEFAULT NULL,
  `discord` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `playerip` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `targetplayername` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `sourceplayername` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `timeat` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `expiration` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `permanent` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`license`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


CREATE TABLE IF NOT EXISTS `world_furnishings` (
  `motelId` bigint NOT NULL DEFAULT '0',
  `furnishingData` longtext,
  `ownedFurnishingData` longtext,
  PRIMARY KEY (`motelId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_keys` (
  `uuid` bigint NOT NULL DEFAULT '0',
  `owner` varchar(50) NOT NULL,
  `keyData` longtext NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_motels` (
  `userIdentifier` varchar(50) NOT NULL,
  `motelData` longtext NOT NULL,
  `motelCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_notes` (
  `noteTitle` varchar(50) NOT NULL,
  `noteText` varchar(255) NOT NULL,
  `noteCoords` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `world_police_lockers` (
  `lockerOwner` varchar(50) NOT NULL,
  `lockerDisplay` varchar(150) DEFAULT NULL,
  `lockerCreator` varchar(50) DEFAULT NULL,
  `lockerCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fetechlockers` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`lockerOwner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `world_storages` (
  `storageId` varchar(255) NOT NULL,
  `storageData` longtext NOT NULL,
  PRIMARY KEY (`storageId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `world_storage_logs` (
  `storageName` varchar(50) NOT NULL,
  `characterName` varchar(50) NOT NULL,
  `itemLabel` varchar(50) NOT NULL,
  `itemCount` int NOT NULL,
  `type` varchar(50) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


CREATE TABLE IF NOT EXISTS `yellowpages_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner` text COLLATE utf8mb4_general_ci NOT NULL,
  `mesaj` text COLLATE utf8mb4_general_ci NOT NULL,
  `isim` text COLLATE utf8mb4_general_ci NOT NULL,
  `telno` text COLLATE utf8mb4_general_ci NOT NULL,
  `resim` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `zones2` (
  `zone` varchar(50) DEFAULT NULL,
  `owner` char(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

REPLACE INTO `zones2` (`zone`, `owner`) VALUES
	('Farmen', 'fallenangels'),
	('Kanalerna', 'gang21'),
	('Discount', 'loszetas'),
	('Industrierna', 'fallenangels'),
	('Havet', 'lost'),
	('nicaragua', 'mecano'),
	('Farmen', 'fallenangels'),
	('Kanalerna', 'gang21'),
	('Discount', 'loszetas'),
	('Industrierna', 'fallenangels'),
	('Havet', 'lost'),
	('nicaragua', 'mecano'),
	('Farmen', 'fallenangels'),
	('Kanalerna', 'gang21'),
	('Discount', 'loszetas'),
	('Industrierna', 'fallenangels'),
	('Havet', 'lost'),
	('nicaragua', 'mecano'),
	('Huset', 'ballas');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
