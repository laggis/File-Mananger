Config = {}
Config.ESX_Legacy = false --@Are you running ESX Legacy??
Config.ES_EXTENDED_FOLDER_NAME = 'elias_base' --@What folder name of es extended (DEFAULT: es_extended)
Config.ESXLibrary = 'esx:getSharedObject' --@Only if you are NOT USING Legacy
Config.Ox_Inventory = false --@If you are using Ox Inventory set to true if not set it to false
Config.Turn_ON_Weather = true --@If you dont want to use weather and time system change this to false!
Config.DynamicWeather = true --@If true weather will change every 15 mins!
Config.DefaultWeather = 'EXTRASUNNY' --@Default weather for server start
Config.NewWeatherTimer = 10 --@In minutes, how oft should weather change?
Config.KickMessage = "You have been kicked out from server!"
Config.Main_Identifier = "steam" --@Whats your identifier from database? (license, steam)
Config.AmbulanceJobTrigger = 'esx_ambulancejob:revive' --@Trigger from your ambulance job (ESX)
Config.Admin_Menu_Command = "admin_menu" --@Command to access admin menu
Config.Admin_Menu_Key = "HOME" --@Keyboard Key to access admin menu
Config.Announce_Message_Duration = 8 --@In seconds, how long should announce message last.

Config.AdminGroups = {
    "servervakt",
	"mod",
    "admin",
    "superadmin"
}

Config.Permissions = {
     ["servervakt"] = {
        Can_Kick = true,
        Can_Ban = true,
        Bring_Player = false,
        Goto_Player = false,
        Kill_Player = false,
        Revive_Player = false,
        Heal_Player = false,
        Godmode_Player = false,
        Visibility = false,
        Freeze_Player = false,
        Set_Cash = false,
        Set_Bank = false,
        Set_Dirty = false,
        Give_Items = false,
        Teleport_Player = false,
        Give_Weapon = false,
        Set_Job = false,
        Spawn_Car = false,
        Can_Unban = false,
        TPM = false,
        Tools_Coords = false,
        Tools_IDS = false,
        Tools_Noclip = false,
        Tools_Announce = false,
        Can_Spectate = false,
    },
	["mod"] = {
        Can_Kick = false,
        Can_Ban = false,
        Bring_Player = false,
        Goto_Player = false,
        Kill_Player = true,
        Revive_Player = true,
        Heal_Player = true,
        Godmode_Player = true,
        Visibility = true,
        Freeze_Player = true,
        Set_Cash = true,
        Set_Bank = true,
        Set_Dirty = true,
        Give_Items = true,
        Teleport_Player = true,
        Give_Weapon = true,
        Set_Job = true,
        Spawn_Car = true,
        Can_Unban = true,
        TPM = false,
        Tools_Coords = true,
        Tools_IDS = true,
        Tools_Noclip = true,
        Tools_Announce = true,
        Can_Spectate = true,
    },
    ["admin"] = {
        Can_Kick = true,
        Can_Ban = true,
        Bring_Player = true,
        Goto_Player = true,
        Kill_Player = true,
        Revive_Player = true,
        Heal_Player = true,
        Godmode_Player = true,
        Visibility = true,
        Freeze_Player = true,
        Set_Cash = true,
        Set_Bank = true,
        Set_Dirty = true,
        Give_Items = true,
        Teleport_Player = true,
        Give_Weapon = true,
        Set_Job = true,
        Spawn_Car = true,
        Can_Unban = true,
        TPM = true,
        Tools_Coords = true,
        Tools_IDS = true,
        Tools_Noclip = true,
        Tools_Announce = true,
        Can_Spectate = true,
     },
    ["superadmin"] = {
        Can_Kick = true,
        Can_Ban = true,
        Bring_Player = true,
        Goto_Player = true,
        Kill_Player = true,
        Revive_Player = true,
        Heal_Player = true,
        Godmode_Player = true,
        Visibility = true,
        Freeze_Player = true,
        Set_Cash = true,
        Set_Bank = true,
        Set_Dirty = true,
        Give_Items = true,
        Teleport_Player = true,
        Give_Weapon = true,
        Set_Job = true,
        Spawn_Car = true,
        Can_Unban = true,
        TPM = true,
        Tools_Coords = true,
        Tools_IDS = true,
        Tools_Noclip = true,
        Tools_Announce = true,
        Can_Spectate = true,
     }
}

Config.BOT_NAME = "LaGgIs" 									
Config.BOT_IMAGE = ""
Config.WEBHOOKS = {
	SetMoney = "",
	SetWeapon = "",
	SetItem = "",
    BanPlayer = "",
    UnbanPlayer = "",
}