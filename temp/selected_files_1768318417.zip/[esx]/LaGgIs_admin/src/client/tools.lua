RegisterNUICallback(
    "tpm",
    function()
        TriggerServerEvent("LaGgIs.tryToTPM")
    end
)
RegisterNetEvent("LaGgIs.tpm")
AddEventHandler(
    "LaGgIs.tpm",
    function()
        local a = GetFirstBlipInfoId(8)
        if DoesBlipExist(a) then
            TriggerScreenblurFadeOut(1000)
            SetNuiFocus(false, false)
            SendNUIMessage({type = "close"})
            local b = GetBlipInfoIdCoord(a)
            for c = 1, 1000 do
                SetPedCoordsKeepVehicle(PlayerPedId(), b["x"], b["y"], c + 0.0)
                local d, e = GetGroundZFor_3dCoord(b["x"], b["y"], c + 0.0)
                if d then
                    SetPedCoordsKeepVehicle(PlayerPedId(), b["x"], b["y"], c + 0.0)
                    break
                end
                Citizen.Wait(0)
            end
        else
            ESX.ShowNotification(Translate["error_1"])
        end
    end
)
RegisterNUICallback(
    "coords",
    function(f)
        ESX.TriggerServerCallback(
            "LaGgIs.isAllowedCoordsCB()",
            function(g)
                if g == true then
                    local h = f.type
                    local i = GetPlayerPed(-1)
                    local j = GetEntityCoords(i, true)
                    local k = GetEntityHeading(i)
                    local l, m, n = table.unpack(j)
                    local o = "{x = " .. round(l, 2) .. ", y = " .. round(m, 2) .. ", z = " .. round(n, 2) .. "}"
                    local p = round(l, 2) .. ", " .. round(m, 2) .. ", " .. round(n, 2)
                    local q = "vector3(" .. round(l, 2) .. ", " .. round(m, 2) .. ", " .. round(n, 2) .. ")"
                    local r = round(k, 2)
                    if h == 1 then
                        SendNUIMessage({type = "show-coords", text1 = o, text2 = r})
                    elseif h == 2 then
                        SendNUIMessage({type = "show-coords", text1 = p, text2 = r})
                    elseif h == 3 then
                        SendNUIMessage({type = "show-coords", text1 = q, text2 = r})
                    end
                else
                    ESX.ShowNotification(Translate["error_2"])
                end
            end
        )
    end
)
local s = false
RegisterNUICallback(
    "ids",
    function()
        ESX.TriggerServerCallback(
            "LaGgIs.isAllowedIdsCB()",
            function(g)
                if g == true then
                    if not s then
                        s = true
                        ESX.ShowNotification(Translate["msg1"])
                    else
                        s = false
                        ESX.ShowNotification(Translate["msg2"])
                    end
                else
                    ESX.ShowNotification(Translate["error_2"])
                end
            end
        )
    end
)
disPlayerNames = 20
playerDistances = {}
Citizen.CreateThread(
    function()
        while true do
            Citizen.Wait(0)
            if not s then
                Citizen.Wait(1000)
            else
                for t, u in ipairs(GetActivePlayers()) do
                    local v = GetPlayerPed(u)
                    if GetPlayerPed(u) ~= GetPlayerPed(-1) then
                        if playerDistances[u] ~= nil and playerDistances[u] < disPlayerNames then
                            print("asd")
                            x2, y2, z2 = table.unpack(GetEntityCoords(GetPlayerPed(u), true))
                            if not NetworkIsPlayerTalking(u) then
                                DrawText3D(
                                    x2,
                                    y2,
                                    z2 + 0.94,
                                    "~b~" .. GetPlayerServerId(u) .. " ~w~| ~w~" .. GetPlayerName(u)
                                )
                            else
                                DrawText3D(
                                    x2,
                                    y2,
                                    z2 + 0.94,
                                    "~b~" .. GetPlayerServerId(u) .. " ~w~| ~w~" .. GetPlayerName(u) .. " 🎤"
                                )
                            end
                        end
                    end
                end
            end
        end
    end
)
Citizen.CreateThread(
    function()
        while true do
            for t, u in ipairs(GetActivePlayers()) do
                if GetPlayerPed(u) ~= GetPlayerPed(-1) then
                    x1, y1, z1 = table.unpack(GetEntityCoords(GetPlayerPed(-1), true))
                    x2, y2, z2 = table.unpack(GetEntityCoords(GetPlayerPed(u), true))
                    distance = math.floor(GetDistanceBetweenCoords(x1, y1, z1, x2, y2, z2, true))
                    playerDistances[u] = distance
                end
            end
            Citizen.Wait(1000)
        end
    end
)
function DrawText3D(l, m, n, w)
    local x, y, z = World3dToScreen2d(l, m, n)
    local A, B, C = table.unpack(GetGameplayCamCoords())
    local D = GetDistanceBetweenCoords(A, B, C, l, m, n, 1)
    local E = 1 / D * 5
    local F = 1 / GetGameplayCamFov() * 100
    local E = E * F
    if x then
        SetTextScale(0.0 * E, 0.22 * E)
        SetTextFont(0)
        SetTextProportional(1)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(w)
        DrawText(y, z)
    end
end
RegisterNUICallback(
    "noclip",
    function()
        ESX.TriggerServerCallback(
            "LaGgIs.isAllowedNoclipCB()",
            function(g)
                if g == true then
                    Noclip()
                else
                    ESX.ShowNotification(Translate["error_2"])
                end
            end
        )
    end
)
local G = false
Noclip = function()
    local u = PlayerId()
    if G == false then
        noclip_pos = GetEntityCoords(PlayerPedId(), false)
    end
    G = not G
    local H = 0
    Citizen.CreateThread(
        function()
            while true do
                Citizen.Wait(0)
                if G then
                    SetEntityCoordsNoOffset(PlayerPedId(), noclip_pos.x, noclip_pos.y, noclip_pos.z, 0, 0, 0)
                    if IsControlPressed(1, 34) then
                        H = H + 1.5
                        if H > 360 then
                            H = 0
                        end
                        SetEntityHeading(PlayerPedId(), H)
                    end
                    if IsControlPressed(1, 9) then
                        H = H - 1.5
                        if H < 0 then
                            H = 360
                        end
                        SetEntityHeading(PlayerPedId(), H)
                    end
                    if IsControlPressed(1, 8) then
                        noclip_pos = GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, 1.0, 0.0)
                    end
                    if IsControlPressed(1, 32) then
                        noclip_pos = GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, -1.0, 0.0)
                    end
                    if IsControlPressed(1, 27) then
                        noclip_pos = GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, 0.0, 1.0)
                    end
                    if IsControlPressed(1, 173) then
                        noclip_pos = GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, 0.0, -1.0)
                    end
                else
                    Citizen.Wait(200)
                end
            end
        end
    )
end
RegisterNUICallback(
    "tools-announce",
    function(f)
        local I = f.message
        local J = f.label
        ESX.TriggerServerCallback(
            "LaGgIs.isAllowedAnnounceCB()",
            function(g)
                if g == true then
                    TriggerScreenblurFadeOut(1000)
                    SetNuiFocus(false, false)
                end
            end,
            J,
            I
        )
    end
)
RegisterNetEvent("LaGgIs.announceE")
AddEventHandler(
    "LaGgIs.announceE",
    function(J, K)
        SendNUIMessage({type = "announce-nui", time = Config.Announce_Message_Duration * 1000, label = J, message = K})
    end
)
