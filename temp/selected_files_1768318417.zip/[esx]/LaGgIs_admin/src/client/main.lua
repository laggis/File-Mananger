if Config.ESX_Legacy then
    ESX = exports[Config.ES_EXTENDED_FOLDER_NAME]:getSharedObject()
    RegisterNetEvent("esx:playerLoaded")
    AddEventHandler(
        "esx:playerLoaded",
        function()
            ESX.PlayerData = ESX.GetPlayerData()
        end
    )
else
    Citizen.CreateThread(
        function()
            while ESX == nil do
                TriggerEvent(
                    Config.ESXLibrary,
                    function(a)
                        ESX = a
                    end
                )
                Citizen.Wait(0)
            end
            while ESX.GetPlayerData().job == nil do
                Citizen.Wait(10)
            end
            ESX.PlayerData = ESX.GetPlayerData()
        end
    )
end
RegisterNUICallback(
    "close",
    function(b)
        TriggerScreenblurFadeOut(1000)
        SetNuiFocus(false, false)
        SendNUIMessage({type = "close"})
    end
)
RegisterNUICallback(
    "adminmenu",
    function()
        ESX.TriggerServerCallback(
            "LaGgIs.getPlayers",
            function(c)
                SendNUIMessage({type = "data", data = c})
            end
        )
    end
)
RegisterNUICallback(
    "bans",
    function()
        ESX.TriggerServerCallback(
            "LaGgIs.getBanList",
            function(d)
                SendNUIMessage({type = "bans", banlist = d})
            end
        )
    end
)
RegisterNUICallback(
    "unban",
    function(b)
        local e = b.licenca
        local f = b.id
        TriggerServerEvent("LaGgIs.unBanPlayEr", id, e)
    end
)
RegisterNUICallback(
    "addWeapon",
    function()
        local g = ESX.GetWeaponList()
        SendNUIMessage({type = "weapons", weaponlist = g})
    end
)
RegisterNUICallback(
    "inventory",
    function()
        ESX.TriggerServerCallback(
            "LaGgIs.fEtchItems",
            function(h)
                SendNUIMessage({type = "inventory", itemslist = h})
            end
        )
    end
)
RegisterNUICallback(
    "jobs",
    function()
        ESX.TriggerServerCallback(
            "LaGgIs.fEtchJobs",
            function(i)
                SendNUIMessage({type = "jobs", joblist = i})
            end
        )
    end
)
RegisterNUICallback(
    "giveWeapon",
    function(b)
        local id = b.id
        local j = b.weapon
        TriggerServerEvent("LaGgIs.addWEapon", id, j)
    end
)
RegisterNUICallback(
    "giveItem",
    function(b)
        local id = b.id
        local k = b.item
        TriggerServerEvent("LaGgIs.additEm", id, k)
    end
)
RegisterNUICallback(
    "setJob",
    function(b)
        local id = b.id
        local l = b.job
        TriggerServerEvent("LaGgIs.addjob", id, l)
    end
)
RegisterNUICallback(
    "action",
    function(b)
        local m = b.type
        local n = b.id
        if m == "goto" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "goto", n)
        elseif m == "bring" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "bring", n)
        elseif m == "kick" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "kick", n)
        elseif m == "kill" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "kill", n)
        elseif m == "revive" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "revive", n)
        elseif m == "heal" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "heal", n)
        elseif m == "godmode" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "godmode", n)
        elseif m == "visibility" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "visibility", n)
        elseif m == "freeze" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "freeze", n)
        elseif m == "car" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "car", n)
        elseif m == "cash" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "cash", n)
        elseif m == "bank" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "bank", n)
        elseif m == "black" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "black", n)
        elseif m == "inventory" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "inventory", n)
        elseif m == "weapon" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "weapon", n)
        elseif m == "job" then
            TriggerServerEvent("LaGgIs.ActionTriggered", "job", n)
        end
    end
)
RegisterNUICallback(
    "teleportxTarget",
    function(b)
        local id = b.id
        local o = tonumber(b.x)
        local p = tonumber(b.y)
        local q = tonumber(b.z)
        local r = vector3(o, p, q)
        TriggerServerEvent("LaGgIs.ActionTriggeredTeleport", id, r)
    end
)
RegisterNUICallback(
    "moneySet",
    function(b)
        local id = b.id
        local s = b.money
        local t = b.type
        TriggerServerEvent("LaGgIs.ActionTriggeredSetMoney", id, t, s)
    end
)
RegisterNUICallback(
    "spawnCar",
    function(b)
        local id = b.id
        local u = b.car
        TriggerServerEvent("LaGgIs.ActionTriggeredSpawnCar", id, u)
    end
)
RegisterNUICallback(
    "banPlayer",
    function(b)
        local id = b.id
        local v = b.reason
        local w = tonumber(b.time)
        TriggerServerEvent("LaGgIs.ActionTriggeredBanPlayer", id, v, w)
    end
)
local x, y, z = false, false, false
RegisterNetEvent("LaGgIs.killPlayer")
AddEventHandler(
    "LaGgIs.killPlayer",
    function()
        SetEntityHealth(PlayerPedId(), 0)
    end
)
RegisterNetEvent("LaGgIs.visibility")
AddEventHandler(
    "LaGgIs.visibility",
    function()
        if not x then
            SetEntityVisible(PlayerPedId(), false)
            x = true
        else
            SetEntityVisible(PlayerPedId(), true)
            x = false
        end
    end
)
RegisterNetEvent("LaGgIs.sEtgodmode")
AddEventHandler(
    "LaGgIs.sEtgodmode",
    function()
        if not y then
            y = not y
            SetEntityInvincible(PlayerPedId(), true)
        else
            SetEntityInvincible(PlayerPedId(), false)
        end
    end
)
RegisterNetEvent("LaGgIs.hEalPlayer")
AddEventHandler(
    "LaGgIs.hEalPlayer",
    function()
        local A = PlayerPedId()
        local B = GetEntityMaxHealth(A)
        SetEntityHealth(A, B)
    end
)
RegisterNetEvent("LaGgIs.frEeze")
AddEventHandler(
    "LaGgIs.frEeze",
    function()
        local A = PlayerPedId()
        if not z then
            z = true
            FreezeEntityPosition(A, true)
        else
            z = false
            FreezeEntityPosition(A, false)
        end
    end
)
RegisterNetEvent("LaGgIs.PlayerUnbaned")
AddEventHandler(
    "LaGgIs.PlayerUnbaned",
    function()
        ESX.TriggerServerCallback(
            "LaGgIs.getBanList",
            function(d)
                SendNUIMessage({type = "update-bans", banlist = d})
            end
        )
    end
)
