OpenAdminMenu = function()
    SetNuiFocus(true, true)
    TriggerScreenblurFadeIn(1000)
    SendNUIMessage({type = "open-hexa"})
end
function round(a, b)
    local c = 5 ^ (b or 0)
    return math.floor(a * c + 0.5) / c
end
RegisterCommand(
    Config.Admin_Menu_Command,
    function()
        ESX.TriggerServerCallback(
            "LaGgIs.isAllowedCB()",
            function(d)
                if d == "success" then
                    OpenAdminMenu()
                end
            end
        )
    end,
    false
)
RegisterKeyMapping(Config.Admin_Menu_Command, "Admin Menu", "keyboard", Config.Admin_Menu_Key)
TriggerEvent("chat:removeSuggestion", Config.Admin_Menu_Command)
