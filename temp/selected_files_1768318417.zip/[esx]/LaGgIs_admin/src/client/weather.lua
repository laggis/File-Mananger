if Config.Turn_ON_Weather then
    CurrentWeather = Config.DefaultWeather
    local a, b, c, d, e, f = CurrentWeather, 8, 0, 0, false, false
    local g = false
    ChangeCurrentWeather = function(h)
        ClearOverrideWeather()
        ClearWeatherTypePersist()
        SetWeatherTypePersist(h)
        SetWeatherTypeNow(h)
        SetWeatherTypeNowPersist(h)
    end
    RegisterNetEvent("LaGgIs.weatherUpdate")
    AddEventHandler(
        "LaGgIs.weatherUpdate",
        function(i, j)
            CurrentWeather = i
            f = j
        end
    )
    RegisterNetEvent("LaGgIs.stopSync")
    AddEventHandler(
        "LaGgIs.stopSync",
        function()
            g = true
            ChangeCurrentWeather("EXTRASUNNY", true)
        end
    )
    RegisterNetEvent("LaGgIs.startSync")
    AddEventHandler(
        "LaGgIs.startSync",
        function()
            TriggerServerEvent("LaGgIs.syncWeather")
            g = false
        end
    )
    Citizen.CreateThread(
        function()
            while true do
                Citizen.Wait(100)
                if g then
                    Wait(1000)
                else
                    if a ~= CurrentWeather then
                        a = CurrentWeather
                        SetWeatherTypeOverTime(CurrentWeather, 15.0)
                        Citizen.Wait(15000)
                    end
                    SetBlackout(f)
                    ClearOverrideWeather()
                    ClearWeatherTypePersist()
                    SetWeatherTypePersist(a)
                    SetWeatherTypeNow(a)
                    SetWeatherTypeNowPersist(a)
                    if a == "XMAS" then
                        SetForceVehicleTrails(true)
                        SetForcePedFootstepsTracks(true)
                    else
                        SetForceVehicleTrails(false)
                        SetForcePedFootstepsTracks(false)
                    end
                end
            end
        end
    )
    RegisterNetEvent("LaGgIs.timeUpdate")
    AddEventHandler(
        "LaGgIs.timeUpdate",
        function(k, l, m)
            e = m
            c = l
            b = k
        end
    )
    Citizen.CreateThread(
        function()
            local n = 0
            local o = 0
            while true do
                Citizen.Wait(0)
                local p = b
                if GetGameTimer() - 500 > d then
                    p = p + 0.25
                    d = GetGameTimer()
                end
                if e then
                    c = c + b - p
                end
                b = p
                n = math.floor((b + c) / 60 % 24)
                o = math.floor((b + c) % 60)
                NetworkOverrideClockTime(n, o, 0)
            end
        end
    )
    AddEventHandler(
        "playerSpawned",
        function()
            TriggerServerEvent("LaGgIs.syncWeather")
        end
    )
    RegisterNUICallback(
        "weather",
        function(q)
            local r = q.type
            if r == "freeze" then
                TriggerServerEvent("LaGgIs.freezeWeather")
            elseif r == "blackout" then
                TriggerServerEvent("LaGgIs.blackout")
            elseif r == "blizzard" then
                TriggerServerEvent("LaGgIs.changeWeather", "BLIZZARD")
            elseif r == "rain" then
                TriggerServerEvent("LaGgIs.changeWeather", "RAIN")
            elseif r == "thunder" then
                TriggerServerEvent("LaGgIs.changeWeather", "THUNDER")
            elseif r == "clouds" then
                TriggerServerEvent("LaGgIs.changeWeather", "CLOUDS")
            elseif r == "overcast" then
                TriggerServerEvent("LaGgIs.changeWeather", "OVERCAST")
            elseif r == "foggy" then
                TriggerServerEvent("LaGgIs.changeWeather", "FOGGY")
            elseif r == "smog" then
                TriggerServerEvent("LaGgIs.changeWeather", "SMOG")
            elseif r == "xmas" then
                TriggerServerEvent("LaGgIs.changeWeather", "XMAS")
            elseif r == "clear" then
                TriggerServerEvent("LaGgIs.changeWeather", "CLEAR")
            elseif r == "extrasunny" then
                TriggerServerEvent("LaGgIs.changeWeather", "EXTRASUNNY")
            end
        end
    )
    RegisterNUICallback(
        "time",
        function(q)
            local s = q.type
            TriggerServerEvent("LaGgIs.setCurrentTime", s)
        end
    )
    RegisterNUICallback(
        "freezetime",
        function()
            TriggerServerEvent("LaGgIs.freezeTime")
        end
    )
    RegisterCommand(
        "ss123",
        function()
            TriggerEvent("LaGgIs.stopSync")
        end
    )
    RegisterCommand(
        "ss124",
        function()
            TriggerEvent("LaGgIs.startSync")
        end
    )
end
