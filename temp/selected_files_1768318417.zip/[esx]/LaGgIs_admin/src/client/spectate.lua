local a = false
local b
local c
local d = 0
local e = 90
local f = -3.5
local g
local h = {}
local i = false
function polar3DToWorld3D(j, f, d, e)
    local k = d * math.pi / 180.0
    local l = e * math.pi / 180.0
    local m = {
        x = j.x + f * math.sin(l) * math.cos(k),
        y = j.y - f * math.sin(l) * math.sin(k),
        z = j.z - f * math.cos(l)
    }
    return m
end
RegisterNetEvent("LaGgIs.StartSpec")
AddEventHandler(
    "LaGgIs.StartSpec",
    function(n)
        spectate(n)
    end
)
function spectate(n)
    if not a then
        c = GetEntityCoords(PlayerPedId())
    end
    local o = PlayerPedId()
    SetEntityCollision(o, false, false)
    SetEntityVisible(o, false)
    Citizen.CreateThread(
        function()
            if not DoesCamExist(g) then
                g = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
            end
            SetCamActive(g, true)
            RenderScriptCams(true, false, 0, true, true)
            a = true
            b = n
        end
    )
end
function rC()
    a = false
    b = nil
    local o = PlayerPedId()
    SetCamActive(g, false)
    RenderScriptCams(false, false, 0, true, true)
    SetEntityCollision(o, true, true)
    SetEntityVisible(o, true)
    SetEntityCoords(o, c.x, c.y, c.z)
end
Citizen.CreateThread(
    function()
        while true do
            Wait(0)
            if a then
                local p = GetPlayerFromServerId(b)
                local o = PlayerPedId()
                local q = GetPlayerPed(p)
                local r = GetEntityCoords(q)
                for s, t in ipairs(GetActivePlayers()) do
                    if t ~= PlayerId() then
                        local u = GetPlayerPed(t)
                        SetEntityNoCollisionEntity(o, u, true)
                        SetEntityVisible(o, false)
                    end
                end
                if IsControlPressed(2, 241) then
                    f = f + 2.0
                end
                if IsControlPressed(2, 242) then
                    f = f - 2.0
                end
                if f > -1 then
                    f = -1
                end
                local v = GetDisabledControlNormal(0, 1)
                local w = GetDisabledControlNormal(0, 2)
                d = d + v * 10
                if d >= 360 then
                    d = 0
                end
                e = e + w * 10
                if e >= 360 then
                    e = 0
                end
                local x = polar3DToWorld3D(r, f, d, e)
                SetCamCoord(g, x.x, x.y, x.z)
                PointCamAtEntity(g, q)
                SetEntityCoords(o, r.x, r.y, r.z + 10)
                if IsControlPressed(0, 200) then
                    rC()
                elseif IsControlPressed(0, 202) then
                    rC()
                end
            else
                Wait(1000)
            end
        end
    end
)
RegisterNUICallback(
    "spec-player",
    function(y)
        local z = tonumber(y.id)
        ESX.TriggerServerCallback(
            "LaGgIs.isAllowedSpectateCB()",
            function(A)
                if A == true then
                    TriggerScreenblurFadeOut(1000)
                    SetNuiFocus(false, false)
                    SendNUIMessage({type = "close"})
                end
            end,
            z
        )
    end
)
