if Config.Turn_ON_Weather then
    function split(a, b)
        result = {}
        for c in (a .. b):gmatch("(.-)" .. b) do
            table.insert(result, c)
        end
        return result
    end
    SolarAdmin = {}
    CurrentWeather = Config.StartWeather
    local d, e, f, g = 8, 0, false, false
    local h = Config.NewWeatherTimer
    RegisterServerEvent("LaGgIs.syncWeather")
    AddEventHandler(
        "LaGgIs.syncWeather",
        function()
            TriggerClientEvent("LaGgIs.weatherUpdate", -1, CurrentWeather, g)
            TriggerClientEvent("LaGgIs.timeUpdate", -1, d, e, f)
        end
    )
    function ShiftToMinute(i)
        e = e - ((d + e) % 60 - i)
    end
    function ShiftToHour(j)
        e = e - ((d + e) / 60 % 24 - j) * 60
    end
    RegisterNetEvent("LaGgIs.changeWeather")
    AddEventHandler(
        "LaGgIs.changeWeather",
        function(k)
            TriggerClientEvent("esx:showNotification", source, " Weather will change to " .. k)
            CurrentWeather = k
            h = 10
            TriggerEvent("LaGgIs.syncWeather")
        end
    )
    RegisterNetEvent("LaGgIs.blackout")
    AddEventHandler(
        "LaGgIs.blackout",
        function()
            g = not g
            if g then
                TriggerClientEvent("esx:showNotification", source, "Blackout enabled")
            else
                TriggerClientEvent("esx:showNotification", source, "Blackout disabled")
            end
            TriggerEvent("LaGgIs.syncWeather")
        end
    )
    RegisterNetEvent("LaGgIs.freezeWeather")
    AddEventHandler(
        "LaGgIs.freezeWeather",
        function()
            Config.DynamicWeather = not Config.DynamicWeather
            if not Config.DynamicWeather then
                TriggerClientEvent("esx:showNotification", source, "Dynamic Weather disabled")
            else
                TriggerClientEvent("esx:showNotification", source, "Dynamic Weather enabled")
            end
        end
    )
    RegisterNetEvent("LaGgIs.freezeTime")
    AddEventHandler(
        "LaGgIs.freezeTime",
        function()
            f = not f
            if f then
                TriggerClientEvent("esx:showNotification", source, "Time frozen")
            else
                TriggerClientEvent("esx:showNotification", source, "Time unfrozen")
            end
        end
    )
    RegisterNetEvent("LaGgIs.setCurrentTime")
    AddEventHandler(
        "LaGgIs.setCurrentTime",
        function(l)
            l = split(l, ":")
            local m = tonumber(l[1])
            local n = tonumber(l[2])
            if m < 24 then
                ShiftToHour(m)
            else
                ShiftToHour(0)
            end
            if n < 60 then
                ShiftToMinute(n)
            else
                ShiftToMinute(0)
            end
            local o = math.floor((d + e) / 60 % 24) .. ":"
            local i = math.floor((d + e) % 60)
            if i < 10 then
                o = o .. "0" .. i
            else
                o = o .. i
            end
            TriggerClientEvent("esx:showNotification", source, "Time changed to " .. o)
            TriggerEvent("LaGgIs.syncWeather")
        end
    )
    Citizen.CreateThread(
        function()
            while true do
                Citizen.Wait(0)
                local p = os.time(os.date("!*t")) / 2 + 360
                if f then
                    e = e + d - p
                end
                d = p
            end
        end
    )
    Citizen.CreateThread(
        function()
            while true do
                Citizen.Wait(5000)
                TriggerClientEvent("LaGgIs.timeUpdate", -1, d, e, f)
            end
        end
    )
    Citizen.CreateThread(
        function()
            while true do
                Citizen.Wait(300000)
                TriggerClientEvent("LaGgIs.weatherUpdate", -1, CurrentWeather, g)
            end
        end
    )
    Citizen.CreateThread(
        function()
            while true do
                h = h - 1
                Citizen.Wait(60000)
                if h == 0 then
                    if Config.DynamicWeather then
                        NextWeatherStage()
                    end
                    h = 10
                end
            end
        end
    )
    function NextWeatherStage()
        if CurrentWeather == "CLEAR" or CurrentWeather == "CLOUDS" or CurrentWeather == "EXTRASUNNY" then
            local q = math.random(1, 2)
            if q == 1 then
                CurrentWeather = "CLEARING"
            else
                CurrentWeather = "OVERCAST"
            end
        elseif CurrentWeather == "CLEARING" or CurrentWeather == "OVERCAST" then
            local q = math.random(1, 6)
            if q == 1 then
                if CurrentWeather == "CLEARING" then
                    CurrentWeather = "FOGGY"
                else
                    CurrentWeather = "RAIN"
                end
            elseif q == 2 then
                CurrentWeather = "CLOUDS"
            elseif q == 3 then
                CurrentWeather = "CLEAR"
            elseif q == 4 then
                CurrentWeather = "EXTRASUNNY"
            elseif q == 5 then
                CurrentWeather = "SMOG"
            else
                CurrentWeather = "FOGGY"
            end
        elseif CurrentWeather == "THUNDER" or CurrentWeather == "RAIN" then
            CurrentWeather = "CLEARING"
        elseif CurrentWeather == "SMOG" or CurrentWeather == "FOGGY" then
            CurrentWeather = "CLEAR"
        end
        TriggerEvent("LaGgIs.syncWeather")
    end
end
