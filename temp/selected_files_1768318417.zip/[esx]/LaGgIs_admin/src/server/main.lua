ESX = nil
if Config.ESX_Legacy then
    ESX = exports[Config.ES_EXTENDED_FOLDER_NAME]:getSharedObject()
else
    TriggerEvent(
        Config.ESXLibrary,
        function(a)
            ESX = a
        end
    )
end
local b, c = {}, {}
AddEventHandler(
    "onResourceStart",
    function()
        if Config.ESX_Legacy and not Config.Ox_Inventory then
            MySQL.ready(
                function()
                    MySQL.query(
                        "SELECT name, label FROM items",
                        {},
                        function(d)
                            b = d
                        end
                    )
                    MySQL.query(
                        'SELECT * FROM jobs ORDER BY name <>  "unemployed", name',
                        {},
                        function(d)
                            for e = 1, #d, 1 do
                                MySQL.query(
                                    "SELECT grade, label FROM job_grades WHERE job_name = @job",
                                    {["@job"] = d[e].name},
                                    function(f)
                                        table.insert(c, {name = d[e].name, label = d[e].label, ranks = f})
                                    end
                                )
                            end
                        end
                    )
                end
            )
        elseif Config.Ox_Inventory then
            b = exports.Ox_Inventory:Items()
            MySQL.query(
                'SELECT * FROM jobs ORDER BY name <>  "unemployed", name',
                {},
                function(d)
                    for e = 1, #d, 1 do
                        MySQL.query(
                            "SELECT grade, label FROM job_grades WHERE job_name = @job",
                            {["@job"] = d[e].name},
                            function(f)
                                table.insert(c, {name = d[e].name, label = d[e].label, ranks = f})
                            end
                        )
                    end
                end
            )
        else
            MySQL.ready(
                function()
                    MySQL.Async.fetchAll(
                        "SELECT name, label FROM items",
                        {},
                        function(d)
                            b = d
                        end
                    )
                    MySQL.Async.fetchAll(
                        'SELECT * FROM jobs ORDER BY name <>  "unemployed", name',
                        {},
                        function(d)
                            for e = 1, #d, 1 do
                                MySQL.Async.fetchAll(
                                    "SELECT grade, label FROM job_grades WHERE job_name = @job",
                                    {["@job"] = d[e].name},
                                    function(f)
                                        table.insert(c, {name = d[e].name, label = d[e].label, ranks = f})
                                    end
                                )
                            end
                        end
                    )
                end
            )
        end
    end
)
UnbanIgrac = function(license)
    if Config.ESX_Legacy then
        MySQL.update(
            "DELETE FROM LaGgIs_admin WHERE license = @license",
            {["license"] = license},
            function(g)
                print("Player is unbanned. License: " .. license)
            end
        )
    else
        MySQL.Async.execute(
            "DELETE FROM LaGgIs_admin WHERE license = @license",
            {["license"] = license},
            function(g)
                print("Player is unbanned. License: " .. license)
            end
        )
    end
end
ESX.RegisterServerCallback(
    "LaGgIs.isAllowedCB()",
    function(source, h)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        if j then
            for k, l in pairs(Config.AdminGroups) do
                if j.getGroup() == l then
                    h("success")
                end
            end
        end
    end
)
ESX.RegisterServerCallback(
    "LaGgIs.isAllowedCoordsCB()",
    function(source, h)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Tools_Coords == true then
                    h(true)
                else
                    h(false)
                end
            end
        end
    end
)
ESX.RegisterServerCallback(
    "LaGgIs.isAllowedIdsCB()",
    function(source, h)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Tools_IDS == true then
                    h(true)
                else
                    h(false)
                end
            end
        end
    end
)
ESX.RegisterServerCallback(
    "LaGgIs.isAllowedNoclipCB()",
    function(source, h)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Tools_Noclip == true then
                    h(true)
                else
                    h(false)
                end
            end
        end
    end
)
ESX.RegisterServerCallback(
    "LaGgIs.isAllowedAnnounceCB()",
    function(source, h, m, n)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Tools_Announce == true then
                    TriggerClientEvent("LaGgIs.announceE", -1, m, n)
                    h(true)
                end
            end
        end
    end
)
ESX.RegisterServerCallback(
    "LaGgIs.isAllowedSpectateCB()",
    function(source, h, o)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Can_Spectate == true then
                    if ESX.GetPlayerFromId(o) == nil then
                        j.showNotification(Translate["error_3"])
                        return
                    else
                        TriggerClientEvent("LaGgIs.StartSpec", i, o)
                        h(true)
                    end
                end
            end
        end
    end
)
isPlayerAdmin = function(j)
    for k, l in ipairs(Config.AdminGroups) do
        if j.getGroup() == l then
            return true
        end
    end
    return false
end
AddEventHandler(
    "playerConnecting",
    function(p, q, r)
        if Config.ESX_Legacy then
            local s = source
            local t
            for k, l in ipairs(GetPlayerIdentifiers(s)) do
                if string.match(l, Config.Main_Identifier) then
                    t = l
                    break
                end
            end
            r.defer()
            r.update("⚡SCANNING⚡")
            MySQL.query(
                "SELECT * FROM LaGgIs_admin WHERE license = @license",
                {["@license"] = t},
                function(d)
                    if d[1] then
                        if d[1].time ~= 0 then
                            if d[1].time < os.time() then
                                UnbanIgrac(d[1].license)
                                r.done()
                                return
                            end
                            local u = math.floor((d[1].time - os.time()) / 60)
                            r.done(
                                "[⚡LaGgIs-ADMINSYSTEM] You are temporarily banned for " ..
                                    u .. " mins Reason: " .. d[1].reason
                            )
                        else
                            r.done(
                                "[⚡LaGgIs-ADMINSYSTEM] You have been permanently banned for the reason: " ..
                                    d[1].reason
                            )
                        end
                    else
                        r.done()
                    end
                end
            )
        else
            local s = source
            local t
            for k, l in ipairs(GetPlayerIdentifiers(s)) do
                if string.match(l, Config.Main_Identifier) then
                    t = l
                    break
                end
            end
            r.defer()
            r.update("⚡SCANNING⚡")
            MySQL.Async.fetchAll(
                "SELECT * FROM LaGgIs_admin WHERE license = @license",
                {["@license"] = t},
                function(d)
                    if d[1] then
                        if d[1].time ~= 0 then
                            if d[1].time < os.time() then
                                UnbanIgrac(d[1].license)
                                r.done()
                                return
                            end
                            local u = math.floor((d[1].time - os.time()) / 60)
                            r.done(
                                "[⚡LaGgIs-ADMINSYSTEM] You are temporarily banned for " ..
                                    u .. " mins Reason: " .. d[1].reason
                            )
                        else
                            r.done(
                                "[⚡LaGgIs-ADMINSYSTEM] You have been permanently banned for the reason: " ..
                                    d[1].reason
                            )
                        end
                    else
                        r.done()
                    end
                end
            )
        end
    end
)
ESX.RegisterServerCallback(
    "LaGgIs.getPlayers",
    function(source, h)
        local v = {}
        local w = ESX.GetPlayers()
        for e = 1, #w, 1 do
            local j = ESX.GetPlayerFromId(w[e])
            v[e] = {
                identifier = j.getIdentifier(),
                playerid = w[e],
                group = j.getGroup(),
                rpname = j.getName(),
                cash = j.getMoney(),
                job = j.job.name,
                bank = j.getAccount("bank").money,
                black = j.getAccount("black_money").money,
                name = GetPlayerName(w[e]),
                ip = GetPlayerEndpoint(w[e])
            }
        end
        h(v)
    end
)
ESX.RegisterServerCallback(
    "LaGgIs.fEtchItems",
    function(source, h)
        h(b)
    end
)
SpawnVehicle = function(model, coords, heading,id, cb)
	if type(model) == 'string' then model = GetHashKey(model) end
	CreateThread(function()
		local entity = Citizen.InvokeNative(`CREATE_AUTOMOBILE`, model, coords.x, coords.y, coords.z, heading)
		while not DoesEntityExist(entity) do Wait(50) end
        if cb then
		    cb(entity)
        end
	end)
end
ESX.RegisterServerCallback(
    "LaGgIs.getBanList",
    function(source, h)
        if Config.ESX_Legacy then
            MySQL.query(
                "SELECT * FROM LaGgIs_admin",
                {},
                function(d)
                    for e = 1, #d, 1 do
                        if d[e].time == 0 then
                            d[e].time = 0
                        else
                            d[e].time = math.floor((d[e].time - os.time()) / 60)
                        end
                    end
                    h(d)
                end
            )
        else
            MySQL.Async.fetchAll(
                "SELECT * FROM LaGgIs_admin",
                {},
                function(d)
                    for e = 1, #d, 1 do
                        d[e].time = math.floor((d[e].time - os.time()) / 60)
                    end
                    h(d)
                end
            )
        end
    end
)
ESX.RegisterServerCallback(
    "LaGgIs.fEtchJobs",
    function(source, h)
        h(c)
    end
)
local x, y, z = true, false, false
RegisterNetEvent("LaGgIs.ActionTriggered")
AddEventHandler(
    "LaGgIs.ActionTriggered",
    function(A, B, u, C)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        local D = ESX.GetPlayerFromId(B)
        if A == "kick" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Can_Kick == true then
                        DropPlayer(B, Config.KickMessage)
                        if j then
                            j.showNotification(Translate["msg3"] .. B .. "~s~.")
                        end
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "goto" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Goto_Player == true then
                        local E = D.getCoords()
                        local F = j.getCoords()
                        j.setCoords(E)
                        j.showNotification(Translate["msg4"] .. B .. "~s~.")
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "bring" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Bring_Player == true then
                        local E = D.getCoords()
                        local F = j.getCoords()
                        D.setCoords(F)
                        j.showNotification(Translate["msg5"] .. B .. "~s~.")
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "kill" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Kill_Player == true then
                        j.showNotification(Translate["msg6"] .. B .. Translate["msg7"])
                        TriggerClientEvent("LaGgIs.killPlayer", B)
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "visibility" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Visibility == true then
                        if x then
                            x = false
                            j.showNotification(Translate["msg6"] .. B .. Translate["msg8"])
                        else
                            x = true
                            j.showNotification(Translate["msg6"] .. B .. Translate["msg9"])
                        end
                        TriggerClientEvent("LaGgIs.visibility", B)
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "godmode" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Godmode_Player == true then
                        if y then
                            y = false
                            j.showNotification(Translate["msg6"] .. B .. Translate["msg10"])
                        else
                            y = true
                            j.showNotification(Translate["msg6"] .. B .. Translate["msg11"])
                        end
                        TriggerClientEvent("LaGgIs.sEtgodmode", B)
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "revive" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Revive_Player == true then
                        D.triggerEvent(Config.AmbulanceJobTrigger)
                        j.showNotification(Translate["msg6"] .. B .. Translate["msg12"])
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "heal" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Heal_Player == true then
                        TriggerClientEvent("LaGgIs.hEalPlayer", B)
                        j.showNotification(Translate["msg6"] .. B .. Translate["msg13"])
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "freeze" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Freeze_Player == true then
                        if z then
                            z = false
                            j.showNotification(Translate["msg6"] .. B .. Translate["msg14"])
                        else
                            z = true
                            j.showNotification(Translate["msg6"] .. B .. Translate["msg15"])
                        end
                        TriggerClientEvent("LaGgIs.frEeze", B)
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.ActionTriggeredTeleport")
AddEventHandler(
    "LaGgIs.ActionTriggeredTeleport",
    function(B, G)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        local D = ESX.GetPlayerFromId(B)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Teleport_Player == true then
                    j.showNotification(Translate["msg6"] .. B .. Translate["msg16"])
                    D.setCoords(G)
                else
                    j.showNotification(Translate["error_2"])
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.ActionTriggeredSetMoney")
AddEventHandler(
    "LaGgIs.ActionTriggeredSetMoney",
    function(B, A, H)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        local I = GetPlayerName(i)
        local J = GetPlayerName(B)
        local D = ESX.GetPlayerFromId(B)
        local K = D.getIdentifier()
        local L = tonumber(H)
        if A == "money" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Set_Cash == true then
                        D.addMoney(L)
                        j.showNotification("You added: " .. L .. Translate["msg17"] .. B .. ".")
                        local M = "SET CASH"
                        hed = Translate["discord1"]
                        color = "#af0d0d"
                        local N = tonumber(color:gsub("#", ""), 16)
                        discordLog(
                            "**Admin ID:** " ..
                                i ..
                                    "\n " ..
                                        "**Admin Name:** " ..
                                            I ..
                                                "\n " ..
                                                    "**Action:** " ..
                                                        M ..
                                                            "\n " ..
                                                                "**Amount:**" ..
                                                                    L ..
                                                                        "$\n **Target ID:** " ..
                                                                            B ..
                                                                                "\n **Target Name:** " ..
                                                                                    J ..
                                                                                        "\n **Target Identifier:** " ..
                                                                                            K,
                            N,
                            "SetMoney"
                        )
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "bank" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Set_Bank == true then
                        D.addAccountMoney("bank", L)
                        j.showNotification("You added: " .. L .. Translate["msg17"] .. B .. ".")
                        local M = "SET BANK MONEY"
                        hed = Translate["discord1"]
                        color = "#af0d0d"
                        local N = tonumber(color:gsub("#", ""), 16)
                        discordLog(
                            "**Admin ID:** " ..
                                i ..
                                    "\n " ..
                                        "**Admin Name:** " ..
                                            I ..
                                                "\n " ..
                                                    "**Action:** " ..
                                                        M ..
                                                            "\n " ..
                                                                "**Amount:**" ..
                                                                    L ..
                                                                        "$\n **Target ID:** " ..
                                                                            B ..
                                                                                "\n **Target Name:** " ..
                                                                                    J ..
                                                                                        "\n **Target Identifier:** " ..
                                                                                            K,
                            N,
                            "SetMoney"
                        )
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        elseif A == "black" then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Set_Dirty == true then
                        D.addAccountMoney("black_money", L)
                        j.showNotification("You added: " .. L .. Translate["msg17"] .. B .. ".")
                        local M = "SET DIRTY MONEY"
                        hed = Translate["discord1"]
                        color = "#af0d0d"
                        local N = tonumber(color:gsub("#", ""), 16)
                        discordLog(
                            "**Admin ID:** " ..
                                i ..
                                    "\n " ..
                                        "**Admin Name:** " ..
                                            I ..
                                                "\n " ..
                                                    "**Action:** " ..
                                                        M ..
                                                            "\n " ..
                                                                "**Amount:**" ..
                                                                    L ..
                                                                        "$\n **Target ID:** " ..
                                                                            B ..
                                                                                "\n **Target Name:** " ..
                                                                                    J ..
                                                                                        "\n **Target Identifier:** " ..
                                                                                            K,
                            N,
                            "SetMoney"
                        )
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.ActionTriggeredSpawnCar")
AddEventHandler(
    "LaGgIs.ActionTriggeredSpawnCar",
    function(B, O)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        local D = ESX.GetPlayerFromId(B)
        local E = D.getCoords()
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Spawn_Car == true then
                    SpawnVehicle(O, E, 0)
                    j.showNotification(Translate["msg18"])
                else
                    j.showNotification(Translate["error_2"])
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.ActionTriggeredBanPlayer")
AddEventHandler(
    "LaGgIs.ActionTriggeredBanPlayer",
    function(P, C, u)
        local i = source
        local Q = ESX.GetPlayerFromId(i)
        local I = GetPlayerName(i)
        local j = ESX.GetPlayerFromId(P)
        for k, l in pairs(Config.Permissions) do
            if k == Q.getGroup() then
                if l.Can_Ban == true then
                    local t
                    if u ~= 0 then
                        local R = u * 60
                        u = os.time() + R
                    else
                        u = 0
                    end
                    for k, l in ipairs(GetPlayerIdentifiers(P)) do
                        if string.match(l, Config.Main_Identifier) then
                            t = l
                            break
                        end
                    end
                    if Config.ESX_Legacy then
                        MySQL.update(
                            "INSERT INTO LaGgIs_admin (license, name, time, reason) VALUES (@license, @name, @time, @reason)",
                            {["license"] = t, ["name"] = GetPlayerName(P), ["time"] = u, ["reason"] = C},
                            function(g)
                                DropPlayer(P, C)
                                Q.showNotification(
                                    Translate["msg6"] .. P .. " has been banned with reason: " .. C .. "."
                                )
                            end
                        )
                    else
                        MySQL.Async.execute(
                            "INSERT INTO LaGgIs_admin (license, name, time, reason) VALUES (@license, @name, @time, @reason)",
                            {["license"] = j.getIdentifier(), ["name"] = GetPlayerName(P), ["time"] = u, ["reason"] = C},
                            function(g)
                                DropPlayer(P, C)
                                Q.showNotification(
                                    Translate["msg6"] .. P .. " has been banned with reason: " .. C .. "."
                                )
                            end
                        )
                    end
                    local M = "BAN"
                    hed = Translate["discord5"]
                    color = "#af0d0d"
                    local N = tonumber(color:gsub("#", ""), 16)
                    discordLog(
                        "**Admin ID:** " ..
                            i ..
                                "\n " ..
                                    "**Admin Name:** " ..
                                        I .. "\n " .. "**Action:** " .. M .. "\n " .. "**Banned License:** " .. t,
                        N,
                        "BanPlayer"
                    )
                else
                    Q.showNotification(Translate["error_2"])
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.addWEapon")
AddEventHandler(
    "LaGgIs.addWEapon",
    function(B, S)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        local D = ESX.GetPlayerFromId(B)
        local I = GetPlayerName(i)
        local J = GetPlayerName(B)
        local K = D.getIdentifier()
        if not Config.Ox_Inventory then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Give_Weapon == true then
                        D.addWeapon(S, 255)
                        j.showNotification(Translate["msg19"] .. S .. Translate["msg20"] .. B .. ".")
                        local M = "WEAPONS"
                        hed = Translate["discord2"]
                        color = "#af0d0d"
                        local N = tonumber(color:gsub("#", ""), 16)
                        discordLog(
                            "**Admin ID:** " ..
                                i ..
                                    "\n " ..
                                        "**Admin Name:** " ..
                                            I ..
                                                "\n " ..
                                                    "**Action:** " ..
                                                        M ..
                                                            "\n " ..
                                                                "**Weapon:**" ..
                                                                    S ..
                                                                        "\n **Target ID:** " ..
                                                                            B ..
                                                                                "\n **Target Name:** " ..
                                                                                    J ..
                                                                                        "\n **Target Identifier:** " ..
                                                                                            K,
                            N,
                            "SetWeapon"
                        )
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        else
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Give_Weapon == true then
                        exports.Ox_Inventory:AddItem(1, S, 1, nil, nil, nil)
                        j.showNotification(Translate["msg19"] .. S .. Translate["msg20"] .. B .. ".")
                        local M = "WEAPONS"
                        hed = Translate["discord2"]
                        color = "#af0d0d"
                        local N = tonumber(color:gsub("#", ""), 16)
                        discordLog(
                            "**Admin ID:** " ..
                                i ..
                                    "\n " ..
                                        "**Admin Name:** " ..
                                            I ..
                                                "\n " ..
                                                    "**Action:** " ..
                                                        M ..
                                                            "\n " ..
                                                                "**Weapon:**" ..
                                                                    S ..
                                                                        "\n **Target ID:** " ..
                                                                            B ..
                                                                                "\n **Target Name:** " ..
                                                                                    J ..
                                                                                        "\n **Target Identifier:** " ..
                                                                                            K,
                            N,
                            "SetWeapon"
                        )
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.additEm")
AddEventHandler(
    "LaGgIs.additEm",
    function(B, T)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        local D = ESX.GetPlayerFromId(B)
        local I = GetPlayerName(i)
        local J = GetPlayerName(B)
        local K = D.getIdentifier()
        if not Config.Ox_Inventory then
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Give_Items == true then
                        D.addInventoryItem(T, 1)
                        j.showNotification(Translate["msg19"] .. T .. Translate["msg20"] .. B .. ".")
                        local M = "ITEMS"
                        hed = Translate["discord3"]
                        color = "#af0d0d"
                        local N = tonumber(color:gsub("#", ""), 16)
                        discordLog(
                            "**Admin ID:** " ..
                                i ..
                                    "\n " ..
                                        "**Admin Name:** " ..
                                            I ..
                                                "\n " ..
                                                    "**Action:** " ..
                                                        M ..
                                                            "\n " ..
                                                                "**Item:**" ..
                                                                    T ..
                                                                        "\n **Amount:** 1x\n **Target ID:** " ..
                                                                            B ..
                                                                                "\n **Target Name:** " ..
                                                                                    J ..
                                                                                        "\n **Target Identifier:** " ..
                                                                                            K,
                            N,
                            "SetItem"
                        )
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        else
            for k, l in pairs(Config.Permissions) do
                if k == j.getGroup() then
                    if l.Give_Items == true then
                        exports.Ox_Inventory:AddItem(1, T, 1, nil, nil, nil)
                        j.showNotification(Translate["msg19"] .. T .. Translate["msg20"] .. B .. ".")
                        local M = "ITEMS"
                        hed = Translate["discord3"]
                        color = "#af0d0d"
                        local N = tonumber(color:gsub("#", ""), 16)
                        discordLog(
                            "**Admin ID:** " ..
                                i ..
                                    "\n " ..
                                        "**Admin Name:** " ..
                                            I ..
                                                "\n " ..
                                                    "**Action:** " ..
                                                        M ..
                                                            "\n " ..
                                                                "**Item:**" ..
                                                                    T ..
                                                                        "\n **Amount:** 1x\n **Target ID:** " ..
                                                                            B ..
                                                                                "\n **Target Name:** " ..
                                                                                    J ..
                                                                                        "\n **Target Identifier:** " ..
                                                                                            K,
                            N,
                            "SetItem"
                        )
                    else
                        j.showNotification(Translate["error_2"])
                    end
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.addjob")
AddEventHandler(
    "LaGgIs.addjob",
    function(B, U)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        local D = ESX.GetPlayerFromId(B)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Set_Job == true then
                    D.setJob(U, 0)
                    j.showNotification(Translate["msg21"] .. U .. Translate["msg20"] .. B .. ".")
                else
                    j.showNotification(Translate["error_2"])
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.unBanPlayEr")
AddEventHandler(
    "LaGgIs.unBanPlayEr",
    function(B, V)
        local i = source
        local j = ESX.GetPlayerFromId(i)
        local I = GetPlayerName(i)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.Can_Unban == true then
                    if Config.ESX_Legacy then
                        MySQL.update(
                            "DELETE FROM LaGgIs_admin WHERE license = @license",
                            {["license"] = V},
                            function(g)
                            end
                        )
                        j.showNotification(Translate["msg22"])
                        TriggerClientEvent("LaGgIs.PlayerUnbaned", j.source)
                    else
                        MySQL.Async.execute(
                            "DELETE FROM LaGgIs_admin WHERE license = @license",
                            {["license"] = license},
                            function(g)
                            end
                        )
                        j.showNotification(Translate["msg22"])
                        TriggerClientEvent("LaGgIs.PlayerUnbaned", j.source)
                    end
                    local M = "UNBAN"
                    hed = Translate["discord4"]
                    color = "#af0d0d"
                    local N = tonumber(color:gsub("#", ""), 16)
                    discordLog(
                        "**Admin ID:** " ..
                            i ..
                                "\n " ..
                                    "**Admin Name:** " ..
                                        I .. "\n " .. "**Action:** " .. M .. "\n " .. "**Unbanned License:**" .. V,
                        N,
                        "UnbanPlayer"
                    )
                else
                    j.showNotification(Translate["error_2"])
                end
            end
        end
    end
)
RegisterNetEvent("LaGgIs.tryToTPM")
AddEventHandler(
    "LaGgIs.tryToTPM",
    function()
        local i = source
        local j = ESX.GetPlayerFromId(i)
        for k, l in pairs(Config.Permissions) do
            if k == j.getGroup() then
                if l.TPM == true then
                    TriggerClientEvent("LaGgIs.tpm", j.source)
                else
                    j.showNotification(Translate["error_2"])
                end
            end
        end
    end
)
local hed
discordLog = function(W, color, X)
    PerformHttpRequest(
        Config.WEBHOOKS[X],
        function(Y, Z, _)
        end,
        "POST",
        json.encode(
            {
                username = Config.BOT_NAME,
                embeds = {
                    {
                        ["color"] = color,
                        ["author"] = {["name"] = hed, ["icon_url"] = Config.BOT_IMAGE},
                        ["description"] = "" .. W .. "",
                        ["footer"] = {["text"] = "© LaGgIs development - " .. os.date("%x %X %p"), ["icon_url"] = ""}
                    }
                },
                avatar_url = ""
            }
        ),
        {["Content-Type"] = "application/json"}
    )
end


