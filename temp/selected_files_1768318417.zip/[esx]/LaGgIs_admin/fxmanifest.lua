fx_version "adamant"

game "gta5"

author ""

lua54 'yes'

client_scripts {
    'settings/config.lua',
    'settings/translate.lua',
    'src/client/*.lua'
}

server_scripts {
    --"@oxmysql/lib/MySQL.lua",
    '@mysql-async/lib/MySQL.lua',  --> If you are not using ESX Legacy uncomment this and comment line above
    'settings/*.lua',
    'src/server/*.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

escrow_ignore {
    'fxmanifest.lua',
    'settings/config.lua',
    'settings/translate.lua',
    'src/server/main.lua',
    'src/server/weather.lua',
    'src/client/functions.lua',
    'src/client/main.lua',
    'src/client/spectate.lua',
    'src/client/tools.lua',
    'src/client/weather.lua'
  }
dependency '/assetpacks'