Strings = {
    -- Text UI strings --
    clothing_menu = '[E] - Byt kläder',
    barber_menu = '[E] - Byt hår/ansikte',
    tattoo_menu = '[E] - Ändra tatueringar',

    -- Notifications --
    success = 'framgångsrikt',
    success_desc = 'Du har framgångsrikt betalat $%s för ett nytt utseende!',

    no_funds = 'Saknar Pengar',
    no_funds_desc = 'Du har inte tillräckligt med pengar på banken för detta',

    -- Menus --

    -- Main clothing shop menu
    clothing_shop_title = 'Butiksmeny',
    change_clothing_title = 'Byt kläder',
    change_clothing_desc = 'Bläddra bland tillgängliga kläder',
    browse_outfits_title = 'Bläddra bland outfits',
    browse_outfits_desc = 'Bläddra bland sparade kläderna',
    save_outfit_title = 'Spara kläderna',
    save_outfit_info = 'Namn på Kläderna',
    save_outfit_desc = 'Spara dom senaste kläderna',
    delete_outfit_title = 'Ta bort kläderna',
    delete_outfit_desc = 'Ta bort sparade kläder',

    -- Browse/Delete outfits & Wardrobe
    wardrobe_title = 'Garderob',
    delete_outfits_title = 'Ta bort kläderna',
    go_back_title = '< Tillbaks',
    go_back_desc = 'Inga sparade kläder!',

    -- Other
    skin_command_help = 'Change Skin',
    skin_command_arg_help = 'Player ID'
}
