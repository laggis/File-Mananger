Config = {}

Config.rpRadio = false -- Enable if you are using rp-radio
Config.LegacyFuel = false -- Enable if you are using LegacyFuel
Config.Speed = "kmh" -- Use mph or kmh only
