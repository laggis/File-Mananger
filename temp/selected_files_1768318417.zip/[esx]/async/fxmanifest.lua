fx_version 'cerulean'
game 'gta5'

author 'ESX-Framework'
description 'asynchronous Tasks'
lua54 'yes'
shared_script 'async.lua'
